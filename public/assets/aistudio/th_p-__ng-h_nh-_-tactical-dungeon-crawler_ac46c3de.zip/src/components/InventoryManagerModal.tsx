import React, { useState } from 'react';
import { GearItem, SlotType, Unit } from '../types/game';
import { SLOT_NAMES, RARITY_COLORS } from '../game/constants';
import { X, Backpack, Coins, Filter } from 'lucide-react';

interface InventoryManagerModalProps {
  inventory: GearItem[];
  heroes: Unit[];
  gold: number;
  onClose: () => void;
  onSellItem: (itemId: string) => void;
  onEquipItem: (heroId: string, item: GearItem) => void;
}

export const InventoryManagerModal: React.FC<InventoryManagerModalProps> = ({
  inventory,
  heroes,
  gold,
  onClose,
  onSellItem,
  onEquipItem,
}) => {
  const [filterSlot, setFilterSlot] = useState<string>('all');
  const [selectedHeroId, setSelectedHeroId] = useState<string>(heroes[0]?.id || '');

  const filteredItems = inventory.filter((item) => {
    if (filterSlot === 'all') return true;
    return item.slot === filterSlot;
  });

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-4xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <Backpack className="w-5 h-5 text-emerald-400" />
            <div>
              <h2 className="text-base font-bold text-slate-100 uppercase tracking-wide">
                Hành Trang ({inventory.length} Món)
              </h2>
              <p className="text-xs text-slate-400">
                Kiểm tra vũ khí và trang bị nhặt được từ quái; bán để lấy vàng hoặc trang bị ngay
              </p>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <div className="flex items-center gap-1.5 font-mono text-amber-400 font-bold text-sm bg-amber-950/40 px-3 py-1 rounded-lg border border-amber-800/60">
              <Coins className="w-4 h-4" />
              <span>{gold} ◈</span>
            </div>
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-slate-100 hover:bg-slate-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Filters and Target Hero Selector */}
        <div className="p-3 bg-slate-950/40 border-b border-slate-800 flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-1.5">
            <Filter className="w-3.5 h-3.5 text-slate-400" />
            <span className="text-slate-400 font-medium">Lọc:</span>
            {['all', 'weapon', 'shield', 'armor', 'ring'].map((slot) => (
              <button
                key={slot}
                onClick={() => setFilterSlot(slot)}
                className={`px-2.5 py-1 rounded-md font-mono text-xs transition-colors ${
                  filterSlot === slot
                    ? 'bg-emerald-950 text-emerald-300 font-bold border border-emerald-800'
                    : 'text-slate-400 hover:text-slate-200 bg-slate-900 border border-slate-800'
                }`}
              >
                {slot === 'all' ? 'Tất cả' : SLOT_NAMES[slot as SlotType]}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-2 font-mono text-xs">
            <span className="text-slate-400">Mục tiêu trang bị:</span>
            <select
              value={selectedHeroId}
              onChange={(e) => setSelectedHeroId(e.target.value)}
              className="bg-slate-900 border border-slate-700 text-slate-200 px-2 py-1 rounded-lg focus:outline-none focus:border-emerald-500"
            >
              {heroes.map((h) => (
                <option key={h.id} value={h.id}>
                  {h.name} ({h.role.split('·')[0].trim()})
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Item Grid */}
        <div className="flex-1 overflow-y-auto p-4">
          {filteredItems.length === 0 ? (
            <div className="text-center py-16 text-slate-500">
              <Backpack className="w-12 h-12 mx-auto mb-3 opacity-30" />
              <p className="text-sm">Túi đồ hiện không có món nào thuộc nhóm này.</p>
              <p className="text-xs text-slate-600 mt-1">Đánh bại quái vật trên tháp để thu thập trang bị hiếm.</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
              {filteredItems.map((item) => {
                const canEquip = true;

                return (
                  <div
                    key={item.id}
                    className="p-3 rounded-xl bg-slate-950/60 border border-slate-800 hover:border-slate-700 transition-all flex flex-col justify-between"
                  >
                    <div>
                      <div className="flex items-start justify-between gap-2 mb-2">
                        <div className="flex items-center gap-2">
                          <span className="text-2xl">{item.icon}</span>
                          <div>
                            <div className="font-bold text-xs text-slate-100 flex items-center gap-1.5">
                              <span>{item.name}</span>
                              <span
                                className="text-[10px] font-mono"
                                style={{ color: RARITY_COLORS[item.rarity - 1] }}
                              >
                                {'★'.repeat(item.rarity)}
                              </span>
                            </div>
                            <div className="text-[10px] text-slate-400 font-mono">
                              {SLOT_NAMES[item.slot]} · Tầng {item.floor}
                            </div>
                          </div>
                        </div>
                      </div>

                      <div className="p-2 rounded bg-slate-900/80 border border-slate-800/80 text-[11px] font-mono space-y-0.5 mb-3 text-slate-300">
                        {Object.entries(item.stats).map(([k, v]) => (
                          <div key={k} className="flex justify-between">
                            <span className="text-slate-500 uppercase">{k}:</span>
                            <span className="text-emerald-400 font-semibold">
                              +{String(v).includes('.') ? Math.round(Number(v) * 100) + '%' : v}
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div className="flex items-center gap-2 pt-2 border-t border-slate-800/60">
                      <button
                        onClick={() => onEquipItem(selectedHeroId, item)}
                        className="flex-1 py-1.5 rounded-lg text-xs font-semibold bg-emerald-600 hover:bg-emerald-500 text-white transition-colors"
                      >
                        Trang bị
                      </button>

                      <button
                        onClick={() => onSellItem(item.id)}
                        className="px-2.5 py-1.5 rounded-lg bg-amber-950/60 hover:bg-amber-900/60 text-amber-300 border border-amber-800/60 text-xs font-mono transition-colors"
                        title="Bán nhận vàng"
                      >
                        Bán +{item.sellPrice} ◈
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
