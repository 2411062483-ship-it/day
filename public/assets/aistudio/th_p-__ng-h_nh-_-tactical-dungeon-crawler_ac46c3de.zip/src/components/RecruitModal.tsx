import React from 'react';
import { Unit } from '../types/game';
import { CLASS_NAMES } from '../game/constants';
import { UserPlus, Sparkles } from 'lucide-react';

interface RecruitModalProps {
  candidate: Unit | null;
  onAccept: () => void;
  onDecline: () => void;
}

export const RecruitModal: React.FC<RecruitModalProps> = ({
  candidate,
  onAccept,
  onDecline,
}) => {
  if (!candidate) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-emerald-500/50 rounded-2xl w-full max-w-md p-6 shadow-2xl flex flex-col items-center text-center relative overflow-hidden">
        {/* Glow backdrop */}
        <div className="absolute -top-24 -left-24 w-48 h-48 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-24 -right-24 w-48 h-48 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="w-12 h-12 rounded-full bg-emerald-950/80 border border-emerald-600/50 flex items-center justify-center mb-4 text-emerald-400">
          <UserPlus className="w-6 h-6" />
        </div>

        <span className="text-xs font-mono uppercase tracking-widest text-emerald-400 mb-1 flex items-center gap-1">
          <Sparkles className="w-3.5 h-3.5" /> Gặp Gỡ Trên Đường Leo Tháp
        </span>

        <h2 className="text-2xl font-black text-slate-100 font-cinzel tracking-wide mb-1">
          {candidate.name}
        </h2>

        <p className="text-xs text-amber-300 font-mono mb-4">
          {CLASS_NAMES[candidate.id]} · {candidate.role}
        </p>

        {/* Character Portrait preview */}
        <div
          className="w-16 h-16 rounded-2xl flex items-center justify-center text-2xl font-bold shadow-xl mb-4 border border-white/20"
          style={{ backgroundColor: candidate.color, color: '#090d0b' }}
        >
          {candidate.glyph}
        </div>

        {/* Stat badges */}
        <div className="grid grid-cols-4 gap-2 w-full font-mono text-xs mb-5">
          <div className="bg-slate-950/70 p-2 rounded-lg border border-slate-800">
            <span className="text-[10px] text-slate-500 block">HP</span>
            <span className="font-bold text-emerald-400">{candidate.maxHp}</span>
          </div>
          <div className="bg-slate-950/70 p-2 rounded-lg border border-slate-800">
            <span className="text-[10px] text-slate-500 block">MP</span>
            <span className="font-bold text-sky-400">{candidate.maxMp}</span>
          </div>
          <div className="bg-slate-950/70 p-2 rounded-lg border border-slate-800">
            <span className="text-[10px] text-slate-500 block">ATK</span>
            <span className="font-bold text-amber-400">{candidate.atk}</span>
          </div>
          <div className="bg-slate-950/70 p-2 rounded-lg border border-slate-800">
            <span className="text-[10px] text-slate-500 block">SPD</span>
            <span className="font-bold text-slate-200">{candidate.spd}</span>
          </div>
        </div>

        <p className="text-xs text-slate-300 leading-relaxed mb-6 font-mono">
          Một người bạn đồng hành tiềm năng muốn gia nhập hành trình chinh phục tháp cổ cùng bạn.
          Bạn có muốn kết nạp vào đội hình ngay không?
        </p>

        <div className="flex items-center gap-3 w-full">
          <button
            onClick={onAccept}
            className="flex-1 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-bold text-xs uppercase tracking-wider transition-all shadow-lg shadow-emerald-950/50"
          >
            Mời Vào Đội
          </button>
          <button
            onClick={onDecline}
            className="flex-1 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold transition-colors"
          >
            Để Dịp Khác
          </button>
        </div>
      </div>
    </div>
  );
};
