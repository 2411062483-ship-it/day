import React, { useEffect } from 'react';
import confetti from 'canvas-confetti';
import { Trophy, Skull, ArrowRight, RotateCcw } from 'lucide-react';
import { GearItem } from '../types/game';
import { RARITY_COLORS } from '../game/constants';

interface GameOverModalProps {
  isVictory: boolean;
  floor: number;
  isBoss: boolean;
  lootFound: GearItem[];
  goldEarned: number;
  onContinue: () => void;
  onRetry: () => void;
}

export const GameOverModal: React.FC<GameOverModalProps> = ({
  isVictory,
  floor,
  isBoss,
  lootFound,
  goldEarned,
  onContinue,
  onRetry,
}) => {
  useEffect(() => {
    if (isVictory) {
      try {
        confetti({
          particleCount: 70,
          spread: 60,
          origin: { y: 0.6 },
        });
      } catch {}
    }
  }, [isVictory]);

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-md p-6 shadow-2xl flex flex-col items-center text-center relative overflow-hidden">
        {/* Glow backdrop */}
        <div
          className={`absolute -top-24 -left-24 w-48 h-48 rounded-full blur-3xl pointer-events-none ${
            isVictory ? 'bg-emerald-500/15' : 'bg-rose-500/15'
          }`}
        />

        <div
          className={`w-14 h-14 rounded-full flex items-center justify-center mb-4 ${
            isVictory
              ? 'bg-emerald-950/80 border border-emerald-600/50 text-emerald-400'
              : 'bg-rose-950/80 border border-rose-600/50 text-rose-400'
          }`}
        >
          {isVictory ? <Trophy className="w-7 h-7" /> : <Skull className="w-7 h-7" />}
        </div>

        <span
          className={`text-xs font-mono uppercase tracking-widest mb-1 ${
            isVictory ? 'text-emerald-400' : 'text-rose-400'
          }`}
        >
          {isVictory ? (isBoss ? 'BOSS ĐÃ BỊ HẠ GỤC!' : 'CĂN PHÒNG ĐÃ DỌN SẠCH') : 'ĐỘI HÌNH THẤT THỦ'}
        </span>

        <h2 className="text-2xl font-black text-slate-100 font-cinzel tracking-wide mb-2">
          {isVictory ? `VƯỢT QUA TẦNG ${floor}` : `GỤC NGÃ TẠI TẦNG ${floor}`}
        </h2>

        <p className="text-xs text-slate-400 font-mono mb-4 leading-relaxed">
          {isVictory
            ? 'Toàn bộ kẻ địch đã bị đánh bại. Lối đi lên tầng tiếp theo đã rộng mở cho đội hình.'
            : 'Tất cả đồng đội đã không còn sức chiến đấu. Hãy điều chỉnh lại chiến thuật hoặc trang bị.'}
        </p>

        {/* Victory Rewards Summary */}
        {isVictory && (
          <div className="w-full bg-slate-950/60 border border-slate-800 rounded-xl p-3 mb-5 text-left text-xs font-mono">
            <div className="flex justify-between pb-2 border-b border-slate-800/80">
              <span className="text-slate-400">Vàng thu thập:</span>
              <span className="font-bold text-amber-300">+{goldEarned} ◈</span>
            </div>

            <div className="pt-2">
              <span className="text-slate-400 block mb-1">Chiến lợi phẩm ({lootFound.length}):</span>
              {lootFound.length > 0 ? (
                <div className="space-y-1">
                  {lootFound.slice(0, 3).map((item) => (
                    <div
                      key={item.id}
                      className="flex items-center justify-between text-[11px] p-1.5 rounded bg-slate-900 border border-slate-800"
                    >
                      <span className="flex items-center gap-1.5 text-slate-200">
                        <span>{item.icon}</span>
                        <span>{item.name}</span>
                      </span>
                      <span
                        className="text-[10px]"
                        style={{ color: RARITY_COLORS[item.rarity - 1] }}
                      >
                        {'★'.repeat(item.rarity)}
                      </span>
                    </div>
                  ))}
                </div>
              ) : (
                <span className="text-slate-600 italic">Không có trang bị rơi trong phòng này.</span>
              )}
            </div>
          </div>
        )}

        {/* Action Buttons */}
        <div className="flex items-center gap-3 w-full">
          {isVictory ? (
            <button
              onClick={onContinue}
              className="w-full py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-bold text-xs uppercase tracking-wider transition-all shadow-lg shadow-emerald-950/50 flex items-center justify-center gap-2"
            >
              <span>Tiếp Tục Lên Tầng {floor + 1}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          ) : (
            <button
              onClick={onRetry}
              className="w-full py-2.5 rounded-xl bg-gradient-to-r from-rose-600 to-amber-600 hover:from-rose-500 hover:to-amber-500 text-white font-bold text-xs uppercase tracking-wider transition-all shadow-lg flex items-center justify-center gap-2"
            >
              <RotateCcw className="w-4 h-4" />
              <span>Chơi Lại Căn Phòng Này</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
