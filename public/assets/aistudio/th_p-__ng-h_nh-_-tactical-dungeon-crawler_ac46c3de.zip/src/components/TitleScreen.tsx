import React, { useState } from 'react';
import { BASE_HEROES, GEAR_CATALOG, CLASS_NAMES } from '../game/constants';
import { Sword, Play, ArrowRight, Shield, BookOpen, Settings, Check } from 'lucide-react';

interface TitleScreenProps {
  hasSave: boolean;
  saveFloor: number;
  onContinue: () => void;
  onStartNewRun: (starterIds: string[], starterWeapons: Record<string, string>) => void;
}

export const TitleScreen: React.FC<TitleScreenProps> = ({
  hasSave,
  saveFloor,
  onContinue,
  onStartNewRun,
}) => {
  const [view, setView] = useState<'title' | 'setup' | 'rules'>('title');
  const [selectedStarters, setSelectedStarters] = useState<string[]>(['swordsman', 'tank']);
  const [starterWeapons, setStarterWeapons] = useState<Record<string, string>>({
    swordsman: 'Kiếm Lò Rèn',
    tank: 'Kiếm Khiên Gác',
    archer: 'Cung Lá Bạc',
    mage: 'Trượng Sao Rơi',
    cleric: 'Chuông Nguyện Ước',
  });

  const weaponOptions = GEAR_CATALOG.filter((item) => item.slot === 'weapon');

  const toggleStarter = (id: string) => {
    if (selectedStarters.includes(id)) {
      if (selectedStarters.length > 1) {
        setSelectedStarters(selectedStarters.filter((item) => item !== id));
      }
    } else {
      if (selectedStarters.length < 2) {
        setSelectedStarters([...selectedStarters, id]);
      } else {
        // Replace second hero
        setSelectedStarters([selectedStarters[0], id]);
      }
    }
  };

  const handleEnterTower = () => {
    if (selectedStarters.length === 2) {
      onStartNewRun(selectedStarters, starterWeapons);
    }
  };

  return (
    <div className="relative min-h-screen bg-slate-950 flex flex-col items-center justify-center p-4 select-none overflow-hidden text-slate-100">
      {/* Background ambient lighting */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-emerald-600/10 rounded-full blur-[140px] pointer-events-none" />
      <div className="absolute bottom-10 left-10 w-96 h-96 bg-amber-600/10 rounded-full blur-[120px] pointer-events-none" />

      {/* VIEW: TITLE SCREEN */}
      {view === 'title' && (
        <div className="max-w-2xl w-full flex flex-col items-center text-center z-10 space-y-6">
          {/* Logo Badge */}
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-950/80 border border-emerald-700/50 text-emerald-400 text-xs font-mono uppercase tracking-widest shadow-lg">
            <Sword className="w-3.5 h-3.5" />
            <span>Biên Niên Sử Leo Tháp · Tactical RPG</span>
          </div>

          {/* Epic Title */}
          <div>
            <h1 className="text-5xl sm:text-6xl font-black font-cinzel tracking-wider text-transparent bg-clip-text bg-gradient-to-b from-white via-slate-200 to-emerald-400 drop-shadow-sm">
              THÁP ĐỒNG HÀNH
            </h1>
            <p className="mt-3 text-slate-400 text-sm font-mono max-w-lg mx-auto leading-relaxed">
              Dẫn dắt các chiến binh vượt qua các tầng tháp biến chuyển liên tục.
              Tự do điều khiển hoặc kích hoạt AI tự động chiến thuật!
            </p>
          </div>

          {/* Action Menu */}
          <div className="w-full max-w-sm space-y-3 pt-2">
            <button
              onClick={() => setView('setup')}
              className="w-full py-3.5 px-6 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black text-sm uppercase tracking-wider transition-all shadow-xl shadow-emerald-950/60 flex items-center justify-center gap-2.5 group"
            >
              <Play className="w-4 h-4 fill-current transition-transform group-hover:scale-110" />
              <span>Chơi Mới (Bắt Đầu)</span>
            </button>

            {hasSave && (
              <button
                onClick={onContinue}
                className="w-full py-3 px-6 rounded-xl bg-slate-900 hover:bg-slate-800 border border-emerald-600/60 hover:border-emerald-500 text-emerald-300 font-bold text-sm uppercase tracking-wider transition-all flex items-center justify-between"
              >
                <span>Tiếp Tục Hành Trình</span>
                <span className="text-xs font-mono text-slate-400 bg-slate-950 px-2 py-0.5 rounded">
                  Tầng {saveFloor}
                </span>
              </button>
            )}

            <button
              onClick={() => setView('rules')}
              className="w-full py-2.5 px-4 rounded-xl bg-slate-900/60 hover:bg-slate-800/60 border border-slate-800 text-slate-400 hover:text-slate-200 text-xs font-mono transition-all flex items-center justify-center gap-2"
            >
              <BookOpen className="w-3.5 h-3.5" />
              <span>Luật Chơi & Hướng Dẫn</span>
            </button>
          </div>

          {/* Footer note */}
          <div className="text-[11px] font-mono text-slate-600 pt-6">
            Hỗ trợ chế độ Tự động (Autobattle) & Thủ công (Manual Turn-based) · HTML5 Canvas
          </div>
        </div>
      )}

      {/* VIEW: SETUP SCREEN (Pick 2 Starters) */}
      {view === 'setup' && (
        <div className="max-w-4xl w-full z-10 flex flex-col space-y-6">
          <div className="flex items-center justify-between border-b border-slate-800 pb-4">
            <div>
              <h2 className="text-2xl font-bold font-cinzel text-slate-100">
                Chọn Hai Người Mở Đường
              </h2>
              <p className="text-xs text-slate-400 font-mono mt-1">
                Chọn chính xác 2 người đồng hành đầu tiên để bước vào tầng 01 của tháp.
              </p>
            </div>

            <button
              onClick={() => setView('title')}
              className="px-3 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-slate-200 text-xs font-mono border border-slate-800"
            >
              ← Quay lại
            </button>
          </div>

          {/* Hero Selection Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3">
            {BASE_HEROES.map((hero) => {
              const isSelected = selectedStarters.includes(hero.id);
              return (
                <div
                  key={hero.id}
                  onClick={() => toggleStarter(hero.id)}
                  className={`p-3.5 rounded-xl border cursor-pointer transition-all flex flex-col justify-between ${
                    isSelected
                      ? 'bg-slate-800/90 border-emerald-500 ring-2 ring-emerald-500/30 shadow-lg'
                      : 'bg-slate-900/40 border-slate-800/80 hover:bg-slate-800/40'
                  }`}
                >
                  <div>
                    <div className="flex items-center justify-between mb-3">
                      <div
                        className="w-10 h-10 rounded-lg flex items-center justify-center font-bold text-base shadow"
                        style={{ backgroundColor: hero.color, color: '#090d0b' }}
                      >
                        {hero.glyph}
                      </div>

                      <div
                        className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold transition-all ${
                          isSelected
                            ? 'bg-emerald-500 text-slate-950'
                            : 'border border-slate-700 text-slate-600'
                        }`}
                      >
                        {isSelected ? <Check className="w-3.5 h-3.5" /> : '+'}
                      </div>
                    </div>

                    <div className="font-bold text-sm text-slate-100 mb-0.5">{hero.name}</div>
                    <div className="text-[10px] text-emerald-400 font-mono mb-2">
                      {CLASS_NAMES[hero.id]}
                    </div>
                    <div className="text-[10px] text-slate-400 font-mono leading-tight">
                      {hero.role}
                    </div>
                  </div>

                  <div className="pt-3 mt-3 border-t border-slate-800/60 font-mono text-[10px] text-slate-400 space-y-0.5">
                    <div className="flex justify-between">
                      <span>HP:</span> <span className="text-emerald-400 font-bold">{hero.maxHp}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>ATK:</span> <span className="text-amber-400 font-bold">{hero.atk}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>SPD:</span> <span className="text-slate-200 font-bold">{hero.spd}</span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Weapon loadout for chosen heroes */}
          <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-4 flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="flex flex-wrap items-center gap-4 text-xs font-mono">
              <span className="text-slate-400 font-semibold">Trang bị khởi đầu:</span>
              {selectedStarters.map((id) => {
                const hero = BASE_HEROES.find((h) => h.id === id);
                if (!hero) return null;
                return (
                  <div key={id} className="flex items-center gap-2">
                    <span className="text-slate-300 font-bold">{hero.name}:</span>
                    <select
                      value={starterWeapons[id] || weaponOptions[0]?.name}
                      onChange={(e) =>
                        setStarterWeapons({
                          ...starterWeapons,
                          [id]: e.target.value,
                        })
                      }
                      className="bg-slate-950 border border-slate-700 text-emerald-300 px-2 py-1 rounded focus:outline-none focus:border-emerald-500"
                    >
                      {weaponOptions.map((w) => (
                        <option key={w.name} value={w.name}>
                          {w.icon} {w.name}
                        </option>
                      ))}
                    </select>
                  </div>
                );
              })}
            </div>

            <button
              onClick={handleEnterTower}
              disabled={selectedStarters.length !== 2}
              className={`py-3 px-8 rounded-xl font-bold text-xs uppercase tracking-wider transition-all shadow-lg flex items-center gap-2 ${
                selectedStarters.length === 2
                  ? 'bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 shadow-emerald-950/60'
                  : 'bg-slate-800 text-slate-500 cursor-not-allowed'
              }`}
            >
              <span>Vào Tháp</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* VIEW: RULES & GUIDE */}
      {view === 'rules' && (
        <div className="max-w-2xl w-full z-10 bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-2xl flex flex-col space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h2 className="text-lg font-bold font-cinzel text-slate-100 flex items-center gap-2">
              <BookOpen className="w-4 h-4 text-emerald-400" />
              <span>Hướng Dẫn & Cơ Chế Leo Tháp</span>
            </h2>
            <button
              onClick={() => setView('title')}
              className="text-xs font-mono text-slate-400 hover:text-slate-100"
            >
              [Đóng]
            </button>
          </div>

          <div className="space-y-3 text-xs font-mono text-slate-300 leading-relaxed overflow-y-auto max-h-[60vh] pr-2">
            <div className="p-3 rounded-lg bg-slate-950/60 border border-slate-800">
              <span className="text-emerald-400 font-bold block mb-1">1. Đội Hình & Lớp Nhân Vật</span>
              <p className="text-slate-400">
                • <b>Kiếm Sĩ (Bảo)</b>: Sát thương cận chiến mạnh, kỹ năng Chém Mạnh.<br />
                • <b>Hộ Vệ (Đạt)</b>: Đỡ đòn trâu bò, HP và DEF cao nhất, kỹ năng Khiên Xung Kích choáng địch.<br />
                • <b>Cung Thủ (Linh)</b>: Tầm bắn xa (3 ô), cần Hộ Vệ còn sống để bảo vệ.<br />
                • <b>Pháp Sư (Miên)</b>: Sát thương phép diện rộng, kỹ năng Hỏa Cầu.<br />
                • <b>Tu Sĩ (An)</b>: Hồi máu đồng đội bằng Ánh Bình Minh hoặc trừng phạt bằng Thánh Quang.
              </p>
            </div>

            <div className="p-3 rounded-lg bg-slate-950/60 border border-slate-800">
              <span className="text-amber-400 font-bold block mb-1">2. Địa Hình & Cạm Bẫy</span>
              <p className="text-slate-400">
                • <b>Cầu gỗ</b>: Cho phép vượt qua sông cạn hoặc vực thẳm.<br />
                • <b>Dung nham</b>: Gây 4 sát thương bỏng khi bước qua.<br />
                • <b>Bẫy chông</b>: Gây 5 sát thương khi kích hoạt.<br />
                • <b>Cổng dịch chuyển</b>: Bước vào để dịch chuyển tức thời sang đầu bên kia!
              </p>
            </div>

            <div className="p-3 rounded-lg bg-slate-950/60 border border-slate-800">
              <span className="text-sky-400 font-bold block mb-1">3. Đại Trùm MinoChoco (Xà Linh Thượng Cổ)</span>
              <p className="text-slate-400">
                • Trùm có các chiêu thức báo trước (Telegraph màu đỏ/tím).<br />
                • <b>Vả quanh</b>: Quét toàn bộ ô xung quanh trùm.<br />
                • <b>Gầm hãm</b>: Làm suy yếu toàn đội, giảm ATK/MATK trong 2 vòng.<br />
                • <b>Cắn độc</b>: Cắn mục tiêu và đầu độc rút máu qua từng lượt.
              </p>
            </div>
          </div>

          <button
            onClick={() => setView('title')}
            className="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-xs transition-colors"
          >
            Đã Hiểu, Quay Lại Menu
          </button>
        </div>
      )}
    </div>
  );
};
