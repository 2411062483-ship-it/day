import React, { useState, useRef, useEffect } from 'react';
import { CombatLogEntry } from '../types/game';
import { ScrollText, Trash2 } from 'lucide-react';

interface CombatLogProps {
  logs: CombatLogEntry[];
  onClear: () => void;
}

export const CombatLog: React.FC<CombatLogProps> = ({ logs, onClear }) => {
  const [filter, setFilter] = useState<'all' | 'combat' | 'item'>('all');
  const scrollRef = useRef<HTMLDivElement | null>(null);

  // Auto scroll to top when new log appears
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = 0;
    }
  }, [logs]);

  const filteredLogs = logs.filter((log) => {
    if (filter === 'all') return true;
    if (filter === 'combat') return log.type === 'enemy' || log.type === 'good' || log.type === 'skill';
    if (filter === 'item') return log.type === 'item';
    return true;
  });

  return (
    <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-3 shadow-xl flex flex-col h-[210px]">
      <div className="flex items-center justify-between pb-2 border-b border-slate-800 text-xs">
        <div className="flex items-center gap-1.5 text-slate-300 font-semibold uppercase tracking-wider text-[11px]">
          <ScrollText className="w-3.5 h-3.5 text-emerald-400" />
          <span>Nhật Ký Chiến Đấu</span>
        </div>

        <div className="flex items-center gap-1">
          <button
            onClick={() => setFilter('all')}
            className={`px-2 py-0.5 rounded text-[10px] font-mono transition-colors ${
              filter === 'all' ? 'bg-emerald-950 text-emerald-300 font-bold border border-emerald-800' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Tất cả
          </button>
          <button
            onClick={() => setFilter('combat')}
            className={`px-2 py-0.5 rounded text-[10px] font-mono transition-colors ${
              filter === 'combat' ? 'bg-emerald-950 text-emerald-300 font-bold border border-emerald-800' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Trận đánh
          </button>
          <button
            onClick={() => setFilter('item')}
            className={`px-2 py-0.5 rounded text-[10px] font-mono transition-colors ${
              filter === 'item' ? 'bg-emerald-950 text-emerald-300 font-bold border border-emerald-800' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Vật phẩm
          </button>
          <button
            onClick={onClear}
            className="p-1 text-slate-500 hover:text-rose-400 transition-colors ml-1"
            title="Xóa nhật ký"
          >
            <Trash2 className="w-3 h-3" />
          </button>
        </div>
      </div>

      <div
        ref={scrollRef}
        className="flex-1 overflow-y-auto space-y-1.5 pt-2 pr-1 text-xs font-mono scrollbar-thin scrollbar-thumb-slate-800"
      >
        {filteredLogs.length === 0 ? (
          <div className="text-slate-500 italic text-center py-6">Chưa có sự kiện nào.</div>
        ) : (
          filteredLogs.map((entry) => (
            <div
              key={entry.id}
              className={`p-1.5 rounded border transition-colors leading-relaxed ${
                entry.type === 'good'
                  ? 'bg-emerald-950/30 border-emerald-800/40 text-emerald-300'
                  : entry.type === 'enemy'
                  ? 'bg-rose-950/30 border-rose-800/40 text-rose-300'
                  : entry.type === 'item'
                  ? 'bg-amber-950/30 border-amber-800/40 text-amber-300'
                  : entry.type === 'skill'
                  ? 'bg-indigo-950/30 border-indigo-800/40 text-indigo-300'
                  : 'bg-slate-950/40 border-slate-800/50 text-slate-300'
              }`}
            >
              <span className="text-[10px] text-slate-500 mr-1.5">[{entry.time}]</span>
              <span dangerouslySetInnerHTML={{ __html: entry.message }} />
            </div>
          ))
        )}
      </div>
    </div>
  );
};
