import React from 'react';
import { Unit, GearItem, EffectiveStats } from '../types/game';
import { CLASS_NAMES, SLOT_NAMES, WEAPON_FAMILIES, WEAPON_XP_PER_RANK } from '../game/constants';
import { Shield, Sparkles, Coins, Backpack } from 'lucide-react';

interface PartySidebarProps {
  heroes: Unit[];
  selectedHeroId: string | null;
  activeId: string | null;
  equipped: Record<string, Record<string, GearItem>>;
  gold: number;
  inventoryCount: number;
  onSelectHero: (id: string) => void;
  getEffectiveStats: (unit: Unit) => EffectiveStats;
  onOpenInventory: () => void;
  onOpenTeam: () => void;
}

export const PartySidebar: React.FC<PartySidebarProps> = ({
  heroes,
  selectedHeroId,
  activeId,
  equipped,
  gold,
  inventoryCount,
  onSelectHero,
  getEffectiveStats,
  onOpenInventory,
  onOpenTeam,
}) => {
  const selectedUnit = heroes.find((h) => h.id === selectedHeroId) || heroes[0];
  const eff = selectedUnit ? getEffectiveStats(selectedUnit) : null;

  return (
    <div className="flex flex-col gap-3.5">
      {/* Gold & Inventory Status Banner */}
      <div className="grid grid-cols-2 gap-2">
        <button
          onClick={onOpenInventory}
          className="bg-slate-900/90 hover:bg-slate-800/90 border border-slate-800 hover:border-amber-600/50 p-2.5 rounded-xl transition-all flex items-center justify-between text-left group"
        >
          <div className="flex items-center gap-2">
            <Coins className="w-4 h-4 text-amber-400" />
            <span className="text-xs text-slate-400 group-hover:text-amber-300">Vàng</span>
          </div>
          <span className="font-mono font-bold text-amber-300 text-sm">{gold} ◈</span>
        </button>

        <button
          onClick={onOpenInventory}
          className="bg-slate-900/90 hover:bg-slate-800/90 border border-slate-800 hover:border-emerald-600/50 p-2.5 rounded-xl transition-all flex items-center justify-between text-left group"
        >
          <div className="flex items-center gap-2">
            <Backpack className="w-4 h-4 text-emerald-400" />
            <span className="text-xs text-slate-400 group-hover:text-emerald-300">Túi Đồ</span>
          </div>
          <span className="font-mono font-bold text-emerald-300 text-sm">{inventoryCount} món</span>
        </button>
      </div>

      {/* Hero Party List */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-3 shadow-xl">
        <div className="flex items-center justify-between pb-2 mb-2 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <Shield className="w-3.5 h-3.5 text-emerald-400" />
            <span className="text-xs font-bold uppercase tracking-wider text-slate-300">Đội Thám Hiểm</span>
          </div>
          <button
            onClick={onOpenTeam}
            className="text-[11px] font-mono text-emerald-400 hover:text-emerald-300 underline"
          >
            Quản lý trang bị →
          </button>
        </div>

        <div className="space-y-2">
          {heroes.map((hero) => {
            const isSelected = hero.id === selectedHeroId;
            const isActive = hero.id === activeId;
            const isFallen = hero.hp <= 0;
            const heroEff = getEffectiveStats(hero);
            const hpPct = Math.max(0, Math.min(100, (hero.hp / heroEff.hp) * 100));
            const mpPct = heroEff.mp ? Math.max(0, Math.min(100, (hero.mp / heroEff.mp) * 100)) : 0;

            return (
              <div
                key={hero.id}
                onClick={() => onSelectHero(hero.id)}
                className={`p-2.5 rounded-lg border cursor-pointer transition-all ${
                  isSelected
                    ? 'bg-slate-800/90 border-emerald-500/80 shadow-md ring-1 ring-emerald-500/30'
                    : 'bg-slate-950/40 border-slate-800/80 hover:bg-slate-800/50 hover:border-slate-700'
                } ${isFallen ? 'opacity-40 grayscale' : ''}`}
              >
                <div className="flex items-center justify-between mb-1.5">
                  <div className="flex items-center gap-2">
                    <div
                      className="w-6 h-6 rounded flex items-center justify-center text-xs font-bold shadow-inner"
                      style={{ backgroundColor: hero.color, color: '#090d0b' }}
                    >
                      {hero.glyph}
                    </div>
                    <div>
                      <span className="font-semibold text-xs text-slate-200">{hero.name}</span>
                      <span className="text-[10px] text-slate-400 font-mono ml-1.5">
                        {CLASS_NAMES[hero.id]}
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center gap-1.5">
                    {isActive && (
                      <span className="px-1.5 py-0.5 rounded text-[9px] font-mono bg-emerald-950 text-emerald-300 border border-emerald-800 animate-pulse">
                        Đang Lượt
                      </span>
                    )}
                    <span className="text-[10px] font-mono text-amber-400 font-semibold">
                      LV {hero.level}
                    </span>
                  </div>
                </div>

                {/* HP Track */}
                <div className="space-y-1">
                  <div className="flex justify-between text-[9px] font-mono text-slate-400">
                    <span>HP {hero.hp}/{heroEff.hp}</span>
                    <span>MP {hero.mp}/{heroEff.mp}</span>
                  </div>
                  <div className="w-full h-1.5 bg-slate-950 rounded-full overflow-hidden">
                    <div
                      className={`h-full transition-all duration-300 ${
                        hpPct < 30 ? 'bg-rose-500' : 'bg-emerald-500'
                      }`}
                      style={{ width: `${hpPct}%` }}
                    />
                  </div>
                  {heroEff.mp > 0 && (
                    <div className="w-full h-1 bg-slate-950 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-sky-500 transition-all duration-300"
                        style={{ width: `${mpPct}%` }}
                      />
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Selected Unit Deep Inspector */}
      {selectedUnit && eff && (
        <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-3 shadow-xl text-xs">
          <div className="flex items-center justify-between pb-2 border-b border-slate-800 mb-2.5">
            <div className="flex items-center gap-2">
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              <span className="font-bold uppercase tracking-wider text-slate-300">
                Chi Tiết: {selectedUnit.name}
              </span>
            </div>
            <span className="text-[10px] font-mono text-slate-400">
              EXP {selectedUnit.exp}/40
            </span>
          </div>

          {/* Core Stat Grid */}
          <div className="grid grid-cols-4 gap-1.5 text-center font-mono text-[11px] mb-3">
            <div className="bg-slate-950/60 border border-slate-800/80 p-1.5 rounded">
              <div className="text-[9px] text-slate-500">ATK</div>
              <div className="font-bold text-amber-300">{eff.atk}</div>
            </div>
            <div className="bg-slate-950/60 border border-slate-800/80 p-1.5 rounded">
              <div className="text-[9px] text-slate-500">MATK</div>
              <div className="font-bold text-sky-300">{eff.matk}</div>
            </div>
            <div className="bg-slate-950/60 border border-slate-800/80 p-1.5 rounded">
              <div className="text-[9px] text-slate-500">DEF</div>
              <div className="font-bold text-emerald-300">{eff.def}</div>
            </div>
            <div className="bg-slate-950/60 border border-slate-800/80 p-1.5 rounded">
              <div className="text-[9px] text-slate-500">SPD</div>
              <div className="font-bold text-slate-200">{eff.spd}</div>
            </div>
          </div>

          {/* Equipped gear summary */}
          <div className="space-y-1 mb-2.5">
            {Object.entries(SLOT_NAMES).map(([slotKey, slotName]) => {
              const item = equipped[selectedUnit.id]?.[slotKey];
              return (
                <div
                  key={slotKey}
                  className="flex items-center justify-between text-[10px] font-mono py-1 px-1.5 rounded bg-slate-950/30 border border-slate-800/40"
                >
                  <span className="text-slate-500">{slotName}:</span>
                  <span className={item ? 'text-emerald-300 font-semibold' : 'text-slate-600'}>
                    {item ? `${item.icon} ${item.name}` : 'Trống'}
                  </span>
                </div>
              );
            })}
          </div>

          {/* Weapon Mastery Ranks */}
          <div className="text-[10px] font-mono text-slate-400 bg-slate-950/40 p-2 rounded border border-slate-800/60">
            <div className="text-slate-500 uppercase tracking-wider text-[9px] mb-1">
              Độ thuần thục vũ khí:
            </div>
            {selectedUnit.weaponMastery && Object.keys(selectedUnit.weaponMastery).length > 0 ? (
              <div className="flex flex-wrap gap-1.5">
                {Object.entries(selectedUnit.weaponMastery).map(([fam, xp]) => {
                  const rank = Math.floor(xp / WEAPON_XP_PER_RANK);
                  const currentXp = xp % WEAPON_XP_PER_RANK;
                  const label = WEAPON_FAMILIES[fam as keyof typeof WEAPON_FAMILIES]?.label || fam;
                  return (
                    <span
                      key={fam}
                      className="px-1.5 py-0.5 rounded bg-slate-800 text-amber-300 border border-slate-700 text-[10px]"
                    >
                      {label} Bậc {rank} ({currentXp}/{WEAPON_XP_PER_RANK})
                    </span>
                  );
                })}
              </div>
            ) : (
              <span className="text-slate-600 italic">Chưa tích lũy kinh nghiệm vũ khí.</span>
            )}
          </div>

          {/* Passive Ability */}
          {selectedUnit.passiveName && (
            <div className="mt-2.5 text-[10px] font-mono bg-emerald-950/40 p-2 rounded-lg border border-emerald-800/60">
              <div className="text-emerald-400 font-bold uppercase tracking-wider text-[10px] mb-0.5 flex items-center gap-1">
                <span>✦ NỘI TẠI:</span>
                <span className="text-amber-300">{selectedUnit.passiveName}</span>
              </div>
              <div className="text-slate-300 leading-relaxed text-[10px]">{selectedUnit.passiveDesc}</div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
