import React from 'react';
import { GearItem } from '../types/game';
import { SLOT_NAMES, RARITY_COLORS } from '../game/constants';
import { X, Store, Coins, ShoppingBag } from 'lucide-react';

interface ShopModalProps {
  stock: GearItem[];
  gold: number;
  floor: number;
  onClose: () => void;
  onBuyItem: (item: GearItem) => void;
}

export const ShopModal: React.FC<ShopModalProps> = ({
  stock,
  gold,
  floor,
  onClose,
  onBuyItem,
}) => {
  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-4xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <Store className="w-5 h-5 text-amber-400" />
            <div>
              <h2 className="text-base font-bold text-slate-100 uppercase tracking-wide">
                Cửa Tiệm Huyền Bí · Tầng {floor}
              </h2>
              <p className="text-xs text-slate-400">
                Thương gia lang thang cung cấp vũ khí và bảo vật quý giá
              </p>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <div className="flex items-center gap-1.5 font-mono text-amber-400 font-bold text-sm bg-amber-950/40 px-3 py-1 rounded-lg border border-amber-800/60">
              <Coins className="w-4 h-4" />
              <span>{gold} ◈</span>
            </div>
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-slate-100 hover:bg-slate-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Stock Grid */}
        <div className="flex-1 overflow-y-auto p-4">
          {stock.length === 0 ? (
            <div className="text-center py-16 text-slate-500">
              <ShoppingBag className="w-12 h-12 mx-auto mb-3 opacity-30" />
              <p className="text-sm">Thương gia đã bán hết sạch hàng trong đợt này!</p>
              <p className="text-xs text-slate-600 mt-1">Hàng mới sẽ được nhập thêm khi tiến lên tầng tiếp theo.</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
              {stock.map((item) => {
                const price = item.price || Math.round(item.sellPrice * 1.6);
                const canAfford = gold >= price;

                return (
                  <div
                    key={item.id}
                    className="p-3.5 rounded-xl bg-slate-950/60 border border-slate-800 hover:border-slate-700 transition-all flex flex-col justify-between"
                  >
                    <div>
                      <div className="flex items-start justify-between gap-2 mb-2">
                        <div className="flex items-center gap-2.5">
                          <span className="text-2xl">{item.icon}</span>
                          <div>
                            <div className="font-bold text-xs text-slate-100 flex items-center gap-1.5">
                              <span>{item.name}</span>
                              <span
                                className="text-[10px] font-mono"
                                style={{ color: RARITY_COLORS[item.rarity - 1] }}
                              >
                                {'★'.repeat(item.rarity)}
                              </span>
                            </div>
                            <div className="text-[10px] text-slate-400 font-mono">
                              {SLOT_NAMES[item.slot]} · Cấp {item.floor}
                            </div>
                          </div>
                        </div>
                      </div>

                      <div className="p-2 rounded bg-slate-900/80 border border-slate-800/80 text-[11px] font-mono space-y-0.5 mb-3 text-slate-300">
                        {Object.entries(item.stats).map(([k, v]) => (
                          <div key={k} className="flex justify-between">
                            <span className="text-slate-500 uppercase">{k}:</span>
                            <span className="text-emerald-400 font-semibold">
                              +{String(v).includes('.') ? Math.round(Number(v) * 100) + '%' : v}
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div className="flex items-center justify-between gap-2 pt-2 border-t border-slate-800/60">
                      <span className="font-mono font-bold text-amber-300 text-xs">
                        {price} ◈
                      </span>

                      <button
                        onClick={() => onBuyItem(item)}
                        disabled={!canAfford}
                        className={`px-4 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
                          canAfford
                            ? 'bg-amber-600 hover:bg-amber-500 text-slate-950 font-bold'
                            : 'bg-slate-800 text-slate-500 cursor-not-allowed'
                        }`}
                      >
                        {canAfford ? 'Mua ngay' : 'Không đủ vàng'}
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
