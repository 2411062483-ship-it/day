import React, { useEffect, useRef, useCallback } from 'react';
import { GRID_COLS, GRID_ROWS, EXIT_DOOR } from '../game/constants';
import { Unit, TerrainTile, BossTelegraph, VisualEffect, EffectiveStats } from '../types/game';

interface BattleCanvasProps {
  units: Unit[];
  walls: Set<string>;
  terrainMap: Map<string, TerrainTile>;
  triggeredTraps: Set<string>;
  bossTelegraph: BossTelegraph[];
  visualEffects: VisualEffect[];
  activeId: string | null;
  selectedId: string | null;
  moveTiles: { x: number; y: number }[];
  targetTiles: { x: number; y: number }[];
  phase: string;
  onTileClick: (x: number, y: number) => void;
  getEffectiveStats: (unit: Unit) => EffectiveStats;
  screenShake: number;
}

export const BattleCanvas: React.FC<BattleCanvasProps> = ({
  units,
  walls,
  terrainMap,
  triggeredTraps,
  bossTelegraph,
  visualEffects,
  activeId,
  selectedId,
  moveTiles,
  targetTiles,
  phase,
  onTileClick,
  getEffectiveStats,
  screenShake,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);

  const draw = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const rect = canvas.getBoundingClientRect();
    if (!rect.width || !rect.height) return;

    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const width = Math.floor(rect.width * dpr);
    const height = Math.floor(rect.height * dpr);

    if (canvas.width !== width || canvas.height !== height) {
      canvas.width = width;
      canvas.height = height;
    }

    ctx.save();
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.clearRect(0, 0, width, height);

    // Screen shake translation
    if (screenShake > 0) {
      const shakeX = (Math.random() - 0.5) * screenShake * dpr;
      const shakeY = (Math.random() - 0.5) * screenShake * dpr;
      ctx.translate(shakeX, shakeY);
    }

    const cellW = width / GRID_COLS;
    const cellH = height / GRID_ROWS;
    const now = performance.now();

    // 1. Draw base floor tiles (Detailed Cobblestone Dungeon Floor)
    for (let y = 0; y < GRID_ROWS; y++) {
      for (let x = 0; x < GRID_COLS; x++) {
        const px = x * cellW;
        const py = y * cellH;
        const alt = (x + y) % 2 === 0;

        // Base tile tone
        ctx.fillStyle = alt ? '#18211b' : '#141c16';
        ctx.fillRect(px, py, cellW, cellH);

        // 4-slab cobblestone pattern within each tile
        const halfW = cellW / 2;
        const halfH = cellH / 2;
        const pavers = [
          { x: px + 1, y: py + 1, w: halfW - 2, h: halfH - 2, tone: ((x * 3 + y * 5) % 3) },
          { x: px + halfW + 1, y: py + 1, w: halfW - 2, h: halfH - 2, tone: ((x * 5 + y * 2) % 3) },
          { x: px + 1, y: py + halfH + 1, w: halfW - 2, h: halfH - 2, tone: ((x * 2 + y * 7) % 3) },
          { x: px + halfW + 1, y: py + halfH + 1, w: halfW - 2, h: halfH - 2, tone: ((x * 7 + y * 3) % 3) },
        ];

        pavers.forEach((p) => {
          ctx.fillStyle = p.tone === 0 ? 'rgba(255,255,255,0.02)' : p.tone === 1 ? 'rgba(0,0,0,0.18)' : 'rgba(34, 197, 94, 0.015)';
          ctx.fillRect(p.x, p.y, p.w, p.h);
          // Highlight edge
          ctx.fillStyle = 'rgba(255, 255, 255, 0.035)';
          ctx.fillRect(p.x, p.y, p.w, 1);
          ctx.fillRect(p.x, p.y, 1, p.h);
        });

        // Grid border
        ctx.strokeStyle = 'rgba(40, 56, 45, 0.45)';
        ctx.lineWidth = 1;
        ctx.strokeRect(px + 0.5, py + 0.5, cellW, cellH);
      }
    }

    // 1b. Central Arcane Ancient Rune Circle (Dungeon Ritual Floor)
    const centerFloorX = (GRID_COLS / 2) * cellW;
    const centerFloorY = (GRID_ROWS / 2) * cellH;
    const runeRadius = Math.min(cellW, cellH) * 1.8;
    const pulseAlpha = 0.12 + Math.sin(now / 800) * 0.05;

    ctx.save();
    ctx.strokeStyle = `rgba(52, 211, 153, ${pulseAlpha})`;
    ctx.lineWidth = 1.5 * dpr;
    ctx.beginPath();
    ctx.arc(centerFloorX, centerFloorY, runeRadius, 0, Math.PI * 2);
    ctx.stroke();

    ctx.strokeStyle = `rgba(167, 139, 250, ${pulseAlpha * 0.8})`;
    ctx.setLineDash([4 * dpr, 6 * dpr]);
    ctx.beginPath();
    ctx.arc(centerFloorX, centerFloorY, runeRadius * 0.75, 0, Math.PI * 2);
    ctx.stroke();
    ctx.setLineDash([]);

    // 4 cardinal runic nodes
    for (let i = 0; i < 4; i++) {
      const ang = (i * Math.PI) / 2 + now / 4000;
      const rx = centerFloorX + Math.cos(ang) * runeRadius;
      const ry = centerFloorY + Math.sin(ang) * runeRadius;
      ctx.fillStyle = `rgba(52, 211, 153, ${pulseAlpha * 1.5})`;
      ctx.beginPath();
      ctx.arc(rx, ry, 3 * dpr, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.restore();

    // 2. Draw terrain tiles with vivid dungeon effects
    for (const [key, tile] of terrainMap.entries()) {
      const [x, y] = key.split(',').map(Number);
      const px = x * cellW;
      const py = y * cellH;

      if (tile.type === 'water') {
        const wave = Math.sin(now / 350 + x * 0.7 + y) * 3;
        ctx.fillStyle = '#082f49';
        ctx.fillRect(px + 1, py + 1, cellW - 2, cellH - 2);
        // Water ripples & specular
        ctx.fillStyle = 'rgba(56, 189, 248, 0.45)';
        ctx.fillRect(px + cellW * 0.1, py + cellH * 0.28 + wave, cellW * 0.5, 2 * dpr);
        ctx.fillStyle = 'rgba(125, 211, 252, 0.35)';
        ctx.fillRect(px + cellW * 0.45, py + cellH * 0.62 - wave, cellW * 0.45, 2 * dpr);
        // Water border reflection
        ctx.strokeStyle = 'rgba(56, 189, 248, 0.3)';
        ctx.lineWidth = 1 * dpr;
        ctx.strokeRect(px + 1, py + 1, cellW - 2, cellH - 2);
      } else if (tile.type === 'abyss') {
        // Deep infinite starry abyss
        ctx.fillStyle = '#05070f';
        ctx.fillRect(px + 1, py + 1, cellW - 2, cellH - 2);
        // Abyssal crag crack
        ctx.strokeStyle = 'rgba(99, 102, 241, 0.35)';
        ctx.lineWidth = 2 * dpr;
        ctx.beginPath();
        ctx.moveTo(px + cellW * 0.2, py + cellH * 0.15);
        ctx.lineTo(px + cellW * 0.55, py + cellH * 0.5);
        ctx.lineTo(px + cellW * 0.35, py + cellH * 0.85);
        ctx.stroke();
        // Void particles / stardust
        const starTime = (now / 1000 + x * 3 + y * 7) % 1;
        ctx.fillStyle = `rgba(168, 85, 247, ${0.4 + starTime * 0.4})`;
        ctx.beginPath();
        ctx.arc(px + cellW * 0.6, py + cellH * 0.35, 1.8 * dpr, 0, Math.PI * 2);
        ctx.fill();
      } else if (tile.type === 'bridge') {
        // Sturdy aged wooden suspension bridge
        ctx.fillStyle = '#3b1c09';
        ctx.fillRect(px + 2, py + cellH * 0.12, cellW - 4, cellH * 0.76);
        ctx.fillStyle = '#78350f';
        for (let i = 1; i <= 4; i++) {
          ctx.fillRect(px + (cellW * i) / 5, py + cellH * 0.15, 3 * dpr, cellH * 0.7);
        }
        // Iron nails & ropes
        ctx.fillStyle = '#d97706';
        ctx.fillRect(px + 3, py + cellH * 0.14, cellW - 6, 2 * dpr);
        ctx.fillRect(px + 3, py + cellH * 0.82, cellW - 6, 2 * dpr);
        ctx.strokeStyle = '#92400e';
        ctx.lineWidth = 1 * dpr;
        ctx.strokeRect(px + 2, py + cellH * 0.12, cellW - 4, cellH * 0.76);
      } else if (tile.type === 'lava') {
        // Bubbling molten lava
        const pulse = Math.sin(now / 280 + x * 2 + y) * 0.25 + 0.75;
        ctx.fillStyle = '#450a0a';
        ctx.fillRect(px + 1, py + 1, cellW - 2, cellH - 2);
        ctx.fillStyle = `rgba(239, 68, 68, ${pulse})`;
        ctx.fillRect(px + cellW * 0.1, py + cellH * 0.2, cellW * 0.8, cellH * 0.6);
        ctx.fillStyle = '#f97316';
        ctx.fillRect(px + cellW * 0.25, py + cellH * 0.35, cellW * 0.5, cellH * 0.3);
        // Molten gold bubble
        const bubbleY = py + cellH * 0.5 + Math.sin(now / 200 + x * 4) * 4;
        ctx.fillStyle = '#fef08a';
        ctx.beginPath();
        ctx.arc(px + cellW * 0.5, bubbleY, 3 * dpr, 0, Math.PI * 2);
        ctx.fill();
      } else if (tile.type === 'trap') {
        const triggered = triggeredTraps.has(key);
        ctx.fillStyle = triggered ? '#292524' : '#44403c';
        ctx.fillRect(px + cellW * 0.15, py + cellH * 0.15, cellW * 0.7, cellH * 0.7);
        ctx.strokeStyle = triggered ? '#78716c' : '#f59e0b';
        ctx.lineWidth = 2 * dpr;
        ctx.beginPath();
        ctx.moveTo(px + cellW * 0.25, py + cellH * 0.25);
        ctx.lineTo(px + cellW * 0.75, py + cellH * 0.75);
        ctx.moveTo(px + cellW * 0.75, py + cellH * 0.25);
        ctx.lineTo(px + cellW * 0.25, py + cellH * 0.75);
        ctx.stroke();
      } else if (tile.type === 'portal') {
        const angle = (now / 500) % (Math.PI * 2);
        ctx.fillStyle = '#1e1b4b';
        ctx.fillRect(px + cellW * 0.08, py + cellH * 0.08, cellW * 0.84, cellH * 0.84);
        ctx.strokeStyle = '#a855f7';
        ctx.lineWidth = 2.5 * dpr;
        ctx.beginPath();
        ctx.ellipse(px + cellW / 2, py + cellH / 2, cellW * 0.32, cellH * 0.38, angle, 0, Math.PI * 2);
        ctx.stroke();
        ctx.fillStyle = '#e9d5ff';
        ctx.beginPath();
        ctx.arc(px + cellW / 2, py + cellH / 2, 4.5 * dpr, 0, Math.PI * 2);
        ctx.fill();
      }
    }

    // 3. Highlight Move Tiles (Cyan glowing area)
    for (const tile of moveTiles) {
      const px = tile.x * cellW;
      const py = tile.y * cellH;
      ctx.fillStyle = 'rgba(45, 212, 191, 0.28)';
      ctx.fillRect(px + 2, py + 2, cellW - 4, cellH - 4);
      ctx.strokeStyle = '#2dd4bf';
      ctx.lineWidth = 2 * dpr;
      ctx.strokeRect(px + 3, py + 3, cellW - 6, cellH - 6);
    }

    // 4. Highlight Target Tiles (Golden glowing crosshairs)
    for (const tile of targetTiles) {
      const px = tile.x * cellW;
      const py = tile.y * cellH;
      ctx.fillStyle = 'rgba(234, 179, 8, 0.32)';
      ctx.fillRect(px + 2, py + 2, cellW - 4, cellH - 4);
      ctx.strokeStyle = '#facc15';
      ctx.lineWidth = 2.5 * dpr;
      ctx.strokeRect(px + 4, py + 4, cellW - 8, cellH - 8);
    }

    // 5. Draw Walls with ancient brickwork and glowing torch sconces
    for (const wall of walls) {
      const [x, y] = wall.split(',').map(Number);
      const px = x * cellW;
      const py = y * cellH;

      ctx.fillStyle = '#1e2922';
      ctx.fillRect(px + 2, py + 2, cellW - 4, cellH - 4);

      // Top parapet / coping stone
      ctx.fillStyle = '#334138';
      ctx.fillRect(px + 4, py + 4, cellW - 8, cellH * 0.28);
      ctx.fillStyle = 'rgba(255, 255, 255, 0.08)';
      ctx.fillRect(px + 4, py + 4, cellW - 8, 1.5 * dpr);

      // Lower carved stone bricks
      ctx.fillStyle = '#26342b';
      ctx.fillRect(px + 4, py + cellH * 0.32, cellW - 8, cellH * 0.62);

      // Brick mortar line
      ctx.strokeStyle = '#151d18';
      ctx.lineWidth = 1 * dpr;
      ctx.beginPath();
      ctx.moveTo(px + 4, py + cellH * 0.62);
      ctx.lineTo(px + cellW - 4, py + cellH * 0.62);
      ctx.stroke();

      ctx.strokeStyle = '#475549';
      ctx.lineWidth = 1.5 * dpr;
      ctx.strokeRect(px + 2, py + 2, cellW - 4, cellH - 4);

      // Torch sconce on select wall blocks (hash deterministic)
      if ((x * 11 + y * 17) % 7 === 0) {
        const torchX = px + cellW / 2;
        const torchY = py + cellH * 0.45;
        const flicker = Math.sin(now / 120 + x * 5) * 1.5;

        // Ambient radial light on surrounding floor
        const glow = ctx.createRadialGradient(torchX, torchY, 4, torchX, torchY, cellW * 1.4);
        glow.addColorStop(0, 'rgba(251, 146, 60, 0.25)');
        glow.addColorStop(0.5, 'rgba(245, 158, 11, 0.1)');
        glow.addColorStop(1, 'rgba(0, 0, 0, 0)');
        ctx.fillStyle = glow;
        ctx.beginPath();
        ctx.arc(torchX, torchY, cellW * 1.4, 0, Math.PI * 2);
        ctx.fill();

        // Iron bracket
        ctx.fillStyle = '#1c1917';
        ctx.fillRect(torchX - 2 * dpr, torchY, 4 * dpr, 6 * dpr);
        // Flame glow & core
        ctx.fillStyle = '#f97316';
        ctx.beginPath();
        ctx.arc(torchX, torchY - 2 * dpr + flicker, 4.5 * dpr, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = '#fef08a';
        ctx.beginPath();
        ctx.arc(torchX, torchY - 3 * dpr + flicker, 2.5 * dpr, 0, Math.PI * 2);
        ctx.fill();
      }
    }

    // 6. Draw Exit Door
    const exitPx = EXIT_DOOR.x * cellW;
    const exitPy = EXIT_DOOR.y * cellH;
    const isOpen = phase === 'exiting';

    ctx.fillStyle = isOpen ? 'rgba(251, 191, 36, 0.35)' : '#1e2420';
    ctx.fillRect(exitPx + cellW * 0.15, exitPy + cellH * 0.1, cellW * 0.75, cellH * 0.85);

    ctx.strokeStyle = isOpen ? '#fbbf24' : '#78716c';
    ctx.lineWidth = 3 * dpr;
    ctx.strokeRect(exitPx + cellW * 0.2, exitPy + cellH * 0.15, cellW * 0.65, cellH * 0.8);

    ctx.fillStyle = isOpen ? '#fef08a' : '#44403c';
    ctx.fillRect(exitPx + cellW * 0.3, exitPy + cellH * 0.28, cellW * 0.45, cellH * 0.65);

    if (isOpen) {
      // Golden glow beacon
      ctx.fillStyle = 'rgba(251, 191, 36, 0.4)';
      ctx.fillRect(exitPx, exitPy, cellW, cellH);
      ctx.fillStyle = '#fef08a';
      ctx.font = `bold ${Math.max(9, Math.floor(cellH * 0.14))}px 'DM Mono', monospace`;
      ctx.textAlign = 'center';
      ctx.fillText('LỐI RA', exitPx + cellW / 2, exitPy + cellH * 0.95);
    }

    // 7. Boss Telegraphs (Warning Danger Zones)
    if (bossTelegraph.length > 0) {
      const pulse = 0.65 + Math.sin(now / 150) * 0.25;
      for (const t of bossTelegraph) {
        const px = t.x * cellW;
        const py = t.y * cellH;
        ctx.fillStyle =
          t.type === 'roar'
            ? `rgba(168, 85, 247, ${pulse * 0.4})`
            : `rgba(239, 68, 68, ${pulse * 0.45})`;
        ctx.fillRect(px + 2, py + 2, cellW - 4, cellH - 4);

        ctx.strokeStyle = t.type === 'roar' ? '#c084fc' : '#ef4444';
        ctx.lineWidth = 3 * dpr;
        ctx.strokeRect(px + 4, py + 4, cellW - 8, cellH - 8);

        ctx.fillStyle = '#fef2f2';
        ctx.font = `bold ${Math.max(10, Math.floor(cellH * 0.14))}px 'DM Mono', monospace`;
        ctx.textAlign = 'center';
        const label = t.type === 'slap' ? 'VẢ QUANH' : t.type === 'bite' ? 'CẮN ĐỘC' : 'GẦM HÃM';
        ctx.fillText(label, px + cellW / 2, py + cellH * 0.3);
      }
    }

    // 8. Draw Units
    const livingUnits = units.filter((u) => u.hp > 0 && !u.inTransit);
    for (const unit of livingUnits) {
      let drawX = unit.x;
      let drawY = unit.y;

      if (unit.animation) {
        const elapsed = now - unit.animation.start;
        const progress = Math.min(1, elapsed / unit.animation.duration);
        drawX = unit.animation.fromX + (unit.animation.toX - unit.animation.fromX) * progress;
        drawY = unit.animation.fromY + (unit.animation.toY - unit.animation.fromY) * progress;
        if (progress >= 1) {
          unit.animation = null;
        }
      }

      const px = drawX * cellW;
      const py = drawY * cellH;
      const centerX = px + cellW / 2;
      const centerY = py + cellH / 2;

      // Active / Selected aura
      if (unit.id === activeId) {
        ctx.strokeStyle = '#a3e635';
        ctx.lineWidth = 2.5 * dpr;
        ctx.strokeRect(px + 3, py + 3, cellW - 6, cellH - 6);
        ctx.fillStyle = '#a3e635';
        ctx.fillRect(px + cellW / 2 - 4 * dpr, py + 2, 8 * dpr, 4 * dpr);
      }
      if (unit.id === selectedId && unit.id !== activeId) {
        ctx.strokeStyle = '#38bdf8';
        ctx.lineWidth = 2 * dpr;
        ctx.setLineDash([4 * dpr, 4 * dpr]);
        ctx.strokeRect(px + 4, py + 4, cellW - 8, cellH - 8);
        ctx.setLineDash([]);
      }

      // Draw MinoChoco Ancient Serpent Boss
      if (unit.species === 'snake') {
        const t = now / 400;
        // Toxic miasma aura
        const auraGrad = ctx.createRadialGradient(centerX, centerY, cellW * 0.2, centerX, centerY, cellW * 0.65);
        auraGrad.addColorStop(0, 'rgba(16, 185, 129, 0.25)');
        auraGrad.addColorStop(0.6, 'rgba(5, 150, 105, 0.12)');
        auraGrad.addColorStop(1, 'rgba(5, 150, 105, 0)');
        ctx.fillStyle = auraGrad;
        ctx.beginPath();
        ctx.arc(centerX, centerY, cellW * 0.65, 0, Math.PI * 2);
        ctx.fill();

        // 10 Segments of the Ancient Jade Serpent
        const spine = [
          { x: 0.15, y: 0.8 },
          { x: 0.3, y: 0.78 },
          { x: 0.48, y: 0.82 },
          { x: 0.65, y: 0.75 },
          { x: 0.76, y: 0.58 },
          { x: 0.62, y: 0.46 },
          { x: 0.42, y: 0.48 },
          { x: 0.32, y: 0.38 },
          { x: 0.44, y: 0.26 },
          { x: 0.62, y: 0.26 },
        ];

        // Draw body scales
        spine.forEach((pt, i) => {
          const sway = Math.sin(t + i * 0.4) * (cellW * 0.035);
          const segX = px + cellW * pt.x + sway;
          const segY = py + cellH * pt.y;
          const radius = (cellW * (0.16 + (i / spine.length) * 0.12)) / 2;

          // Outer dark emerald scale
          ctx.fillStyle = i % 2 === 0 ? '#044e39' : '#065f46';
          ctx.beginPath();
          ctx.arc(segX, segY, radius, 0, Math.PI * 2);
          ctx.fill();

          // Golden scale rim highlight
          ctx.strokeStyle = '#d97706';
          ctx.lineWidth = 1.5 * dpr;
          ctx.stroke();

          // Inner iridescent highlight
          ctx.fillStyle = '#10b981';
          ctx.beginPath();
          ctx.arc(segX - radius * 0.2, segY - radius * 0.2, radius * 0.4, 0, Math.PI * 2);
          ctx.fill();
        });

        // Serpent Head Center (pos 9)
        const headX = px + cellW * 0.62 + Math.sin(t + 4) * (cellW * 0.035);
        const headY = py + cellH * 0.26;

        // Flared Cobra Hood
        ctx.fillStyle = '#047857';
        ctx.beginPath();
        ctx.ellipse(headX - cellW * 0.08, headY, cellW * 0.2, cellH * 0.26, 0.2, 0, Math.PI * 2);
        ctx.fill();
        ctx.strokeStyle = '#f59e0b';
        ctx.lineWidth = 2 * dpr;
        ctx.stroke();

        // Hood mystic rune pattern
        ctx.fillStyle = '#fbbf24';
        ctx.beginPath();
        ctx.arc(headX - cellW * 0.1, headY - cellH * 0.05, 3 * dpr, 0, Math.PI * 2);
        ctx.arc(headX - cellW * 0.1, headY + cellH * 0.05, 3 * dpr, 0, Math.PI * 2);
        ctx.fill();

        // Head Crest / Crown
        ctx.fillStyle = '#f59e0b';
        ctx.beginPath();
        ctx.moveTo(headX + cellW * 0.05, headY - cellH * 0.16);
        ctx.lineTo(headX + cellW * 0.15, headY - cellH * 0.25);
        ctx.lineTo(headX + cellW * 0.12, headY - cellH * 0.1);
        ctx.lineTo(headX + cellW * 0.22, headY - cellH * 0.18);
        ctx.lineTo(headX + cellW * 0.14, headY - cellH * 0.02);
        ctx.closePath();
        ctx.fill();

        // Main Viper Head
        ctx.fillStyle = '#10b981';
        ctx.beginPath();
        ctx.ellipse(headX, headY, cellW * 0.18, cellH * 0.14, 0.1, 0, Math.PI * 2);
        ctx.fill();

        // Glowing Ruby-Amber Eyes
        ctx.fillStyle = '#ef4444';
        ctx.shadowColor = '#ef4444';
        ctx.shadowBlur = 8 * dpr;
        ctx.beginPath();
        ctx.ellipse(headX + cellW * 0.06, headY - cellH * 0.04, 3.5 * dpr, 5 * dpr, 0.2, 0, Math.PI * 2);
        ctx.fill();
        ctx.shadowBlur = 0;

        // Slit Pupil
        ctx.fillStyle = '#0f172a';
        ctx.fillRect(headX + cellW * 0.06 - 0.5 * dpr, headY - cellH * 0.04 - 4 * dpr, 1.2 * dpr, 8 * dpr);

        // Venomous Fangs dripping poison
        ctx.fillStyle = '#ffffff';
        ctx.beginPath();
        ctx.moveTo(headX + cellW * 0.14, headY + cellH * 0.02);
        ctx.lineTo(headX + cellW * 0.16, headY + cellH * 0.12);
        ctx.lineTo(headX + cellW * 0.18, headY + cellH * 0.02);
        ctx.fill();

        // Poison droplet
        const dropProgress = (t * 2) % 1;
        ctx.fillStyle = '#34d399';
        ctx.beginPath();
        ctx.arc(headX + cellW * 0.16, headY + cellH * (0.12 + dropProgress * 0.1), 2 * dpr, 0, Math.PI * 2);
        ctx.fill();

        // Flickering bifurcated tongue
        if (Math.sin(t * 5) > 0.3) {
          ctx.strokeStyle = '#f43f5e';
          ctx.lineWidth = 1.8 * dpr;
          ctx.beginPath();
          ctx.moveTo(headX + cellW * 0.18, headY + cellH * 0.04);
          ctx.lineTo(headX + cellW * 0.28, headY + cellH * 0.04);
          ctx.lineTo(headX + cellW * 0.32, headY);
          ctx.moveTo(headX + cellW * 0.28, headY + cellH * 0.04);
          ctx.lineTo(headX + cellW * 0.32, headY + cellH * 0.08);
          ctx.stroke();
        }
      } else if (unit.species === 'kraken') {
        // Mutated Kraken / Abyssal Cephalopod
        const t = now / 350;
        // Shadow
        ctx.fillStyle = 'rgba(0, 0, 0, 0.45)';
        ctx.beginPath();
        ctx.ellipse(centerX, py + cellH * 0.85, cellW * 0.35, cellH * 0.08, 0, 0, Math.PI * 2);
        ctx.fill();

        // 6 Waving purple tentacles
        const tentacleAngles = [-1.3, -0.8, -0.3, 0.3, 0.8, 1.3];
        tentacleAngles.forEach((ang, idx) => {
          const wave = Math.sin(t + idx * 0.8) * 0.2;
          ctx.strokeStyle = '#7e22ce';
          ctx.lineWidth = 4 * dpr;
          ctx.lineCap = 'round';
          ctx.beginPath();
          ctx.moveTo(centerX, centerY + cellH * 0.1);
          const midX = centerX + Math.cos(ang + wave) * (cellW * 0.3);
          const midY = centerY + cellH * 0.2 + Math.sin(ang + wave) * (cellH * 0.25);
          const tipX = centerX + Math.cos(ang + wave * 1.5) * (cellW * 0.45);
          const tipY = centerY + cellH * 0.3 + Math.sin(ang + wave * 1.5) * (cellH * 0.38);
          ctx.quadraticCurveTo(midX, midY, tipX, tipY);
          ctx.stroke();

          // Glowing suction cups
          ctx.fillStyle = '#38bdf8';
          ctx.beginPath();
          ctx.arc(midX, midY, 2 * dpr, 0, Math.PI * 2);
          ctx.fill();
        });

        // Bulbous head
        ctx.fillStyle = '#a855f7';
        ctx.beginPath();
        ctx.ellipse(centerX, centerY - cellH * 0.05, cellW * 0.24, cellH * 0.22, 0, 0, Math.PI * 2);
        ctx.fill();
        ctx.strokeStyle = '#c084fc';
        ctx.lineWidth = 1.5 * dpr;
        ctx.stroke();

        // Giant glowing cyan eye
        ctx.fillStyle = '#38bdf8';
        ctx.shadowColor = '#38bdf8';
        ctx.shadowBlur = 8 * dpr;
        ctx.beginPath();
        ctx.arc(centerX, centerY - cellH * 0.05, 6 * dpr, 0, Math.PI * 2);
        ctx.fill();
        ctx.shadowBlur = 0;

        // Eye slit
        ctx.fillStyle = '#0f172a';
        ctx.fillRect(centerX - 4 * dpr, centerY - cellH * 0.05 - 1 * dpr, 8 * dpr, 2 * dpr);
      } else if (unit.species === 'cerberus') {
        // 3-Headed Hellhound
        const t = now / 300;
        // Shadow
        ctx.fillStyle = 'rgba(0, 0, 0, 0.45)';
        ctx.beginPath();
        ctx.ellipse(centerX, py + cellH * 0.85, cellW * 0.32, cellH * 0.08, 0, 0, Math.PI * 2);
        ctx.fill();

        // Dark demonic body
        ctx.fillStyle = '#450a0a';
        ctx.beginPath();
        ctx.ellipse(centerX, centerY + cellH * 0.15, cellW * 0.28, cellH * 0.2, 0, 0, Math.PI * 2);
        ctx.fill();
        ctx.strokeStyle = '#b91c1c';
        ctx.lineWidth = 1.5 * dpr;
        ctx.stroke();

        // Three distinct heads: Left, Center, Right
        const heads = [
          { offsetX: -cellW * 0.16, offsetY: -cellH * 0.15, scale: 0.14 },
          { offsetX: 0, offsetY: -cellH * 0.22, scale: 0.16 },
          { offsetX: cellW * 0.16, offsetY: -cellH * 0.15, scale: 0.14 },
        ];

        heads.forEach((h, idx) => {
          const hX = centerX + h.offsetX;
          const hY = centerY + h.offsetY + Math.sin(t + idx * 1.5) * (cellH * 0.02);

          // Head shape
          ctx.fillStyle = '#ef4444';
          ctx.beginPath();
          ctx.arc(hX, hY, cellW * h.scale, 0, Math.PI * 2);
          ctx.fill();

          // Ears
          ctx.fillStyle = '#991b1b';
          ctx.beginPath();
          ctx.moveTo(hX - cellW * 0.08, hY - cellH * 0.1);
          ctx.lineTo(hX - cellW * 0.04, hY - cellH * 0.2);
          ctx.lineTo(hX, hY - cellH * 0.1);
          ctx.fill();

          // Burning Yellow Eyes
          ctx.fillStyle = '#fef08a';
          ctx.shadowColor = '#facc15';
          ctx.shadowBlur = 6 * dpr;
          ctx.beginPath();
          ctx.arc(hX - 3 * dpr, hY - 2 * dpr, 2.2 * dpr, 0, Math.PI * 2);
          ctx.arc(hX + 3 * dpr, hY - 2 * dpr, 2.2 * dpr, 0, Math.PI * 2);
          ctx.fill();
          ctx.shadowBlur = 0;

          // Snarl Fangs
          ctx.fillStyle = '#ffffff';
          ctx.beginPath();
          ctx.moveTo(hX - 3 * dpr, hY + 3 * dpr);
          ctx.lineTo(hX - 2 * dpr, hY + 7 * dpr);
          ctx.lineTo(hX - 1 * dpr, hY + 3 * dpr);
          ctx.moveTo(hX + 1 * dpr, hY + 3 * dpr);
          ctx.lineTo(hX + 2 * dpr, hY + 7 * dpr);
          ctx.lineTo(hX + 3 * dpr, hY + 3 * dpr);
          ctx.fill();
        });
      } else if (unit.species === 'bird') {
        // Corrupted Mutant Bird (Roc)
        const t = now / 250;
        const hover = Math.sin(t) * (cellH * 0.06);

        // Shadow with altitude scale
        ctx.fillStyle = 'rgba(0, 0, 0, 0.35)';
        ctx.beginPath();
        ctx.ellipse(centerX, py + cellH * 0.88, cellW * 0.22, cellH * 0.06, 0, 0, Math.PI * 2);
        ctx.fill();

        const birdY = centerY + hover;
        const wingFlap = Math.sin(t * 2) * (cellH * 0.15);

        // Left Wing
        ctx.fillStyle = '#0891b2';
        ctx.beginPath();
        ctx.moveTo(centerX - cellW * 0.08, birdY);
        ctx.quadraticCurveTo(centerX - cellW * 0.35, birdY - cellH * 0.25 + wingFlap, centerX - cellW * 0.42, birdY - cellH * 0.05 + wingFlap);
        ctx.lineTo(centerX - cellW * 0.15, birdY + cellH * 0.1);
        ctx.closePath();
        ctx.fill();

        // Right Wing
        ctx.beginPath();
        ctx.moveTo(centerX + cellW * 0.08, birdY);
        ctx.quadraticCurveTo(centerX + cellW * 0.35, birdY - cellH * 0.25 + wingFlap, centerX + cellW * 0.42, birdY - cellH * 0.05 + wingFlap);
        ctx.lineTo(centerX + cellW * 0.15, birdY + cellH * 0.1);
        ctx.closePath();
        ctx.fill();

        // Bird Body
        ctx.fillStyle = '#06b6d4';
        ctx.beginPath();
        ctx.ellipse(centerX, birdY, cellW * 0.14, cellH * 0.18, 0, 0, Math.PI * 2);
        ctx.fill();

        // Head & Sharp Beak
        ctx.fillStyle = '#0e7490';
        ctx.beginPath();
        ctx.arc(centerX, birdY - cellH * 0.15, cellW * 0.1, 0, Math.PI * 2);
        ctx.fill();

        // Glowing cyan eye
        ctx.fillStyle = '#facc15';
        ctx.beginPath();
        ctx.arc(centerX + cellW * 0.04, birdY - cellH * 0.17, 2.5 * dpr, 0, Math.PI * 2);
        ctx.fill();

        // Razor Golden Beak
        ctx.fillStyle = '#fbbf24';
        ctx.beginPath();
        ctx.moveTo(centerX + cellW * 0.08, birdY - cellH * 0.18);
        ctx.lineTo(centerX + cellW * 0.2, birdY - cellH * 0.14);
        ctx.lineTo(centerX + cellW * 0.08, birdY - cellH * 0.12);
        ctx.closePath();
        ctx.fill();
      } else if (unit.species === 'beholder') {
        // Floating Beholder Orb with 5 Eye Stalks
        const t = now / 300;
        const hover = Math.sin(t) * (cellH * 0.05);
        ctx.fillStyle = 'rgba(0, 0, 0, 0.4)';
        ctx.beginPath();
        ctx.ellipse(centerX, py + cellH * 0.88, cellW * 0.25, cellH * 0.07, 0, 0, Math.PI * 2);
        ctx.fill();

        const beholderY = centerY + hover;

        // 5 Eye Stalks waving around
        const stalkAngles = [-2.2, -1.6, -1.0, -0.4, 0.2];
        stalkAngles.forEach((ang, idx) => {
          const sway = Math.sin(t * 1.5 + idx) * 0.15;
          const stalkX = centerX + Math.cos(ang + sway) * (cellW * 0.28);
          const stalkY = beholderY + Math.sin(ang + sway) * (cellH * 0.25);
          ctx.strokeStyle = '#7c3aed';
          ctx.lineWidth = 3 * dpr;
          ctx.beginPath();
          ctx.moveTo(centerX, beholderY);
          ctx.lineTo(stalkX, stalkY);
          ctx.stroke();

          // Small stalk eye
          ctx.fillStyle = '#f43f5e';
          ctx.beginPath();
          ctx.arc(stalkX, stalkY, 3 * dpr, 0, Math.PI * 2);
          ctx.fill();
        });

        // Main Beholder Body
        ctx.fillStyle = '#6d28d9';
        ctx.beginPath();
        ctx.arc(centerX, beholderY, cellW * 0.22, 0, Math.PI * 2);
        ctx.fill();
        ctx.strokeStyle = '#a78bfa';
        ctx.lineWidth = 2 * dpr;
        ctx.stroke();

        // Giant Central Cyclops Eye
        ctx.fillStyle = '#fef08a';
        ctx.shadowColor = '#facc15';
        ctx.shadowBlur = 10 * dpr;
        ctx.beginPath();
        ctx.arc(centerX, beholderY, cellW * 0.1, 0, Math.PI * 2);
        ctx.fill();
        ctx.shadowBlur = 0;

        // Vertical Slit Pupil
        ctx.fillStyle = '#0f172a';
        ctx.beginPath();
        ctx.ellipse(centerX, beholderY, 2.5 * dpr, cellH * 0.08, 0, 0, Math.PI * 2);
        ctx.fill();
      } else if (unit.species === 'treant') {
        // Corrupted Treant Bark Golem
        const t = now / 400;
        ctx.fillStyle = 'rgba(0, 0, 0, 0.45)';
        ctx.beginPath();
        ctx.ellipse(centerX, py + cellH * 0.88, cellW * 0.3, cellH * 0.08, 0, 0, Math.PI * 2);
        ctx.fill();

        // Ancient Oak Body Trunk
        ctx.fillStyle = '#14532d';
        ctx.beginPath();
        ctx.moveTo(centerX - cellW * 0.22, py + cellH * 0.35);
        ctx.lineTo(centerX + cellW * 0.22, py + cellH * 0.35);
        ctx.lineTo(centerX + cellW * 0.26, py + cellH * 0.8);
        ctx.lineTo(centerX - cellW * 0.26, py + cellH * 0.8);
        ctx.closePath();
        ctx.fill();
        ctx.strokeStyle = '#22c55e';
        ctx.lineWidth = 2 * dpr;
        ctx.stroke();

        // Vine arms
        const armSway = Math.sin(t) * (cellH * 0.05);
        ctx.strokeStyle = '#15803d';
        ctx.lineWidth = 4 * dpr;
        ctx.beginPath();
        ctx.moveTo(centerX - cellW * 0.2, py + cellH * 0.4);
        ctx.lineTo(centerX - cellW * 0.35, py + cellH * 0.6 + armSway);
        ctx.moveTo(centerX + cellW * 0.2, py + cellH * 0.4);
        ctx.lineTo(centerX + cellW * 0.35, py + cellH * 0.6 - armSway);
        ctx.stroke();

        // Glowing Amber Knot Eyes
        ctx.fillStyle = '#fbbf24';
        ctx.beginPath();
        ctx.arc(centerX - 5 * dpr, py + cellH * 0.45, 2.5 * dpr, 0, Math.PI * 2);
        ctx.arc(centerX + 5 * dpr, py + cellH * 0.45, 2.5 * dpr, 0, Math.PI * 2);
        ctx.fill();
      } else if (unit.species === 'banshee') {
        // Ethereal Ghost Banshee
        const t = now / 300;
        const floatY = centerY + Math.sin(t) * (cellH * 0.06);

        // Spectral glowing mist
        ctx.fillStyle = 'rgba(56, 189, 248, 0.15)';
        ctx.beginPath();
        ctx.arc(centerX, floatY, cellW * 0.32, 0, Math.PI * 2);
        ctx.fill();

        // Tattered ethereal robe
        ctx.fillStyle = 'rgba(186, 230, 253, 0.75)';
        ctx.beginPath();
        ctx.moveTo(centerX - cellW * 0.16, floatY - cellH * 0.15);
        ctx.lineTo(centerX + cellW * 0.16, floatY - cellH * 0.15);
        ctx.lineTo(centerX + cellW * 0.22, floatY + cellH * 0.25);
        ctx.lineTo(centerX + Math.sin(t * 3) * 5, floatY + cellH * 0.35);
        ctx.lineTo(centerX - cellW * 0.22, floatY + cellH * 0.25);
        ctx.closePath();
        ctx.fill();

        // Spectral Head & glowing cyan eyes
        ctx.fillStyle = '#e0f2fe';
        ctx.beginPath();
        ctx.arc(centerX, floatY - cellH * 0.18, cellW * 0.12, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = '#38bdf8';
        ctx.shadowColor = '#38bdf8';
        ctx.shadowBlur = 8 * dpr;
        ctx.beginPath();
        ctx.arc(centerX - 3 * dpr, floatY - cellH * 0.18, 2 * dpr, 0, Math.PI * 2);
        ctx.arc(centerX + 3 * dpr, floatY - cellH * 0.18, 2 * dpr, 0, Math.PI * 2);
        ctx.fill();
        ctx.shadowBlur = 0;
      } else if (unit.species === 'mimic') {
        // Greedy Mimic Chest
        const t = now / 300;
        ctx.fillStyle = 'rgba(0, 0, 0, 0.45)';
        ctx.beginPath();
        ctx.ellipse(centerX, py + cellH * 0.85, cellW * 0.3, cellH * 0.08, 0, 0, Math.PI * 2);
        ctx.fill();

        // Wooden Chest Bottom
        ctx.fillStyle = '#78350f';
        ctx.fillRect(centerX - cellW * 0.25, centerY, cellW * 0.5, cellH * 0.28);
        ctx.strokeStyle = '#f59e0b';
        ctx.lineWidth = 2 * dpr;
        ctx.strokeRect(centerX - cellW * 0.25, centerY, cellW * 0.5, cellH * 0.28);

        // Open Chest Lid with chomp animation
        const chomp = Math.abs(Math.sin(t * 2)) * (cellH * 0.1);
        ctx.fillStyle = '#92400e';
        ctx.fillRect(centerX - cellW * 0.26, centerY - cellH * 0.15 - chomp, cellW * 0.52, cellH * 0.16);
        ctx.strokeRect(centerX - cellW * 0.26, centerY - cellH * 0.15 - chomp, cellW * 0.52, cellH * 0.16);

        // Razor Sharp Teeth
        ctx.fillStyle = '#ffffff';
        for (let i = 0; i < 4; i++) {
          ctx.beginPath();
          ctx.moveTo(centerX - cellW * 0.2 + cellW * 0.1 * i, centerY);
          ctx.lineTo(centerX - cellW * 0.15 + cellW * 0.1 * i, centerY - 6 * dpr);
          ctx.lineTo(centerX - cellW * 0.1 + cellW * 0.1 * i, centerY);
          ctx.fill();
        }

        // Red Slurping Tongue
        ctx.fillStyle = '#ef4444';
        ctx.beginPath();
        ctx.ellipse(centerX, centerY + 3 * dpr, 6 * dpr, 8 * dpr, 0, 0, Math.PI * 2);
        ctx.fill();
      } else {
        // Humanoid / Monster Unit Rendering
        // Shadow
        ctx.fillStyle = 'rgba(0, 0, 0, 0.45)';
        ctx.beginPath();
        ctx.ellipse(centerX, py + cellH * 0.85, cellW * 0.28, cellH * 0.08, 0, 0, Math.PI * 2);
        ctx.fill();

        // Cloak / Armor Body
        ctx.fillStyle = unit.color;
        ctx.beginPath();
        ctx.moveTo(centerX - cellW * 0.22, py + cellH * 0.4);
        ctx.lineTo(centerX + cellW * 0.22, py + cellH * 0.4);
        ctx.lineTo(centerX + cellW * 0.26, py + cellH * 0.72);
        ctx.lineTo(centerX, py + cellH * 0.8);
        ctx.lineTo(centerX - cellW * 0.26, py + cellH * 0.72);
        ctx.closePath();
        ctx.fill();

        // Face & Head
        ctx.fillStyle = unit.kind === 'hero' ? '#fed7aa' : '#cbd5e1';
        ctx.beginPath();
        ctx.arc(centerX, py + cellH * 0.3, cellW * 0.16, 0, Math.PI * 2);
        ctx.fill();

        // Hair / Helmet
        ctx.fillStyle = unit.kind === 'enemy' ? '#475569' : '#451a03';
        ctx.beginPath();
        ctx.arc(centerX, py + cellH * 0.26, cellW * 0.17, Math.PI, Math.PI * 2);
        ctx.fill();

        // Glyph in chest
        ctx.fillStyle = '#ffffff';
        ctx.font = `bold ${Math.max(10, Math.floor(cellH * 0.16))}px 'DM Mono', monospace`;
        ctx.textAlign = 'center';
        ctx.fillText(unit.glyph, centerX, py + cellH * 0.65);
      }

      // Unit Health Bar
      const eff = getEffectiveStats(unit);
      const barW = unit.boss ? cellW * 0.88 : cellW * 0.72;
      const barH = (unit.boss ? 6 : 5) * dpr;
      const bx = centerX - barW / 2;
      const by = py + cellH * 0.07;

      ctx.fillStyle = '#0f172a';
      ctx.fillRect(bx, by, barW, barH);

      const hpPercent = Math.max(0, Math.min(1, unit.hp / eff.hp));
      ctx.fillStyle =
        unit.kind === 'hero'
          ? hpPercent < 0.3
            ? '#ef4444'
            : '#22c55e'
          : '#f87171';
      ctx.fillRect(bx, by, barW * hpPercent, barH);

      // Guard / Shield overlay on health bar
      if (unit.guard > 0) {
        ctx.strokeStyle = '#38bdf8';
        ctx.lineWidth = 1.5 * dpr;
        ctx.strokeRect(bx - 1, by - 1, barW + 2, barH + 2);
      }

      // Unit Name and Level
      ctx.fillStyle = unit.kind === 'hero' ? '#f1f5f9' : '#fecaca';
      ctx.font = `bold ${Math.max(9, Math.floor(cellH * 0.12))}px 'DM Mono', monospace`;
      ctx.textAlign = 'center';
      ctx.fillText(unit.name, centerX, py + cellH * 0.96);

      // Status Badges (Stun, Poison, Burn, Blind)
      let badgeX = centerX - cellW * 0.3;
      if (unit.stun && unit.stun > 0) {
        ctx.fillStyle = '#facc15';
        ctx.beginPath();
        ctx.arc(badgeX, py + cellH * 0.25, 4 * dpr, 0, Math.PI * 2);
        ctx.fill();
        badgeX += 9 * dpr;
      }
      if (unit.poisonTicks && unit.poisonTicks > 0) {
        ctx.fillStyle = '#a855f7';
        ctx.beginPath();
        ctx.arc(badgeX, py + cellH * 0.25, 4 * dpr, 0, Math.PI * 2);
        ctx.fill();
        badgeX += 9 * dpr;
      }
      if (unit.burnTicks && unit.burnTicks > 0) {
        ctx.fillStyle = '#f97316';
        ctx.beginPath();
        ctx.arc(badgeX, py + cellH * 0.25, 4 * dpr, 0, Math.PI * 2);
        ctx.fill();
        badgeX += 9 * dpr;
      }
      if (unit.blindTicks && unit.blindTicks > 0) {
        ctx.fillStyle = '#64748b';
        ctx.beginPath();
        ctx.arc(badgeX, py + cellH * 0.25, 4 * dpr, 0, Math.PI * 2);
        ctx.fill();
      }
    }

    // 9. Combat Visual Effects & Floating Text
    for (const fx of visualEffects) {
      const elapsed = now - fx.start;
      if (elapsed > fx.duration) continue;

      const progress = Math.min(1, elapsed / fx.duration);
      const startX = (fx.fromX + 0.5) * cellW;
      const startY = (fx.fromY + 0.5) * cellH;
      const targetX = (fx.toX + 0.5) * cellW;
      const targetY = (fx.toY + 0.5) * cellH;

      ctx.save();

      // Custom effect animations
      if (fx.type === 'tentacle') {
        // Giant purple tentacle lash down
        const sweep = Math.sin(progress * Math.PI);
        ctx.strokeStyle = '#a855f7';
        ctx.lineWidth = 6 * dpr;
        ctx.lineCap = 'round';
        ctx.beginPath();
        ctx.moveTo(startX, startY - cellH * 0.4);
        ctx.quadraticCurveTo(targetX + cellW * 0.2 * sweep, targetY - cellH * 0.3, targetX, targetY);
        ctx.stroke();
      } else if (fx.type === 'claw3') {
        // 3 Fiery claw slash lines
        ctx.strokeStyle = '#ef4444';
        ctx.lineWidth = 2.5 * dpr;
        [-10, 0, 10].forEach((offset) => {
          ctx.beginPath();
          ctx.moveTo(targetX - 16 * dpr + offset, targetY - 16 * dpr);
          ctx.lineTo(targetX + 16 * dpr + offset, targetY + 16 * dpr);
          ctx.stroke();
        });
      } else if (fx.type === 'feather') {
        // Swirling razor feather blades
        const spin = progress * Math.PI * 4;
        ctx.fillStyle = '#06b6d4';
        for (let a = 0; a < 4; a++) {
          const fxX = targetX + Math.cos(spin + (a * Math.PI) / 2) * (cellW * 0.25 * (1 - progress));
          const fxY = targetY + Math.sin(spin + (a * Math.PI) / 2) * (cellH * 0.25 * (1 - progress));
          ctx.beginPath();
          ctx.arc(fxX, fxY, 3.5 * dpr, 0, Math.PI * 2);
          ctx.fill();
        }
      } else if (fx.type === 'eye_ray') {
        // Prismatic Beholder disintegrator beam with orbital energy rings
        ctx.strokeStyle = '#c084fc';
        ctx.lineWidth = 5 * dpr;
        ctx.shadowColor = '#a855f7';
        ctx.shadowBlur = 12 * dpr;
        ctx.beginPath();
        ctx.moveTo(startX, startY);
        ctx.lineTo(targetX, targetY);
        ctx.stroke();
        // Inner white laser core
        ctx.strokeStyle = '#ffffff';
        ctx.lineWidth = 2 * dpr;
        ctx.beginPath();
        ctx.moveTo(startX, startY);
        ctx.lineTo(targetX, targetY);
        ctx.stroke();
        ctx.shadowBlur = 0;
      } else if (fx.type === 'entangle') {
        // Creeping emerald root vines on target tile
        const vineSweep = Math.sin(progress * Math.PI);
        ctx.strokeStyle = '#15803d';
        ctx.lineWidth = 3.5 * dpr;
        ctx.beginPath();
        ctx.arc(targetX, targetY, cellW * 0.3 * (0.5 + vineSweep * 0.5), 0, Math.PI * 1.5);
        ctx.stroke();
        ctx.strokeStyle = '#22c55e';
        ctx.lineWidth = 2 * dpr;
        ctx.beginPath();
        ctx.arc(targetX, targetY, cellW * 0.2, Math.PI * 0.5, Math.PI * 2);
        ctx.stroke();
      } else if (fx.type === 'wail') {
        // Expanding spectral ultrasonic scream rings
        const ringRadius = progress * cellW * 0.9;
        ctx.strokeStyle = `rgba(103, 232, 249, ${1 - progress})`;
        ctx.lineWidth = 3 * dpr;
        ctx.beginPath();
        ctx.arc(startX, startY, ringRadius, 0, Math.PI * 2);
        ctx.stroke();
        ctx.strokeStyle = `rgba(165, 243, 252, ${(1 - progress) * 0.6})`;
        ctx.lineWidth = 1.5 * dpr;
        ctx.beginPath();
        ctx.arc(startX, startY, ringRadius * 0.6, 0, Math.PI * 2);
        ctx.stroke();
      } else {
        // Standard projectile / laser beam
        const curX = startX + (targetX - startX) * progress;
        const curY = startY + (targetY - startY) * progress;

        ctx.strokeStyle = fx.color;
        ctx.fillStyle = fx.color;
        ctx.lineWidth = 3 * dpr;
        ctx.beginPath();
        ctx.moveTo(startX, startY);
        ctx.lineTo(curX, curY);
        ctx.stroke();

        ctx.shadowColor = fx.color;
        ctx.shadowBlur = 10 * dpr;
        ctx.beginPath();
        ctx.arc(curX, curY, (fx.type === 'fire' ? 8 : 5) * dpr, 0, Math.PI * 2);
        ctx.fill();
        ctx.shadowBlur = 0;
      }

      // Expanding impact blast ring
      if (progress > 0.5) {
        const ringProg = (progress - 0.5) / 0.5;
        ctx.strokeStyle = fx.color;
        ctx.lineWidth = 2 * dpr;
        ctx.beginPath();
        ctx.arc(targetX, targetY, ringProg * cellW * 0.45, 0, Math.PI * 2);
        ctx.stroke();
      }

      // Floating Text / Passive Alerts (e.g. ✦ KIẾM KHÍ!, 🔥 THIÊU ĐỐT!)
      if (fx.floatingText) {
        const floatY = targetY - cellH * (0.35 + progress * 0.35);
        ctx.fillStyle = '#0f172a';
        ctx.fillRect(targetX - 45 * dpr, floatY - 9 * dpr, 90 * dpr, 16 * dpr);
        ctx.strokeStyle = fx.color;
        ctx.lineWidth = 1 * dpr;
        ctx.strokeRect(targetX - 45 * dpr, floatY - 9 * dpr, 90 * dpr, 16 * dpr);

        ctx.fillStyle = fx.color;
        ctx.font = `bold ${Math.max(10, Math.floor(cellH * 0.16))}px 'DM Mono', monospace`;
        ctx.textAlign = 'center';
        ctx.fillText(fx.floatingText, targetX, floatY + 3 * dpr);
      }

      // Floating Damage Number
      if (fx.damage !== 0) {
        const floatY = targetY - cellH * (0.15 + progress * 0.28);
        ctx.fillStyle = fx.damage < 0 ? '#4ade80' : fx.isCrit ? '#fbbf24' : '#ffffff';
        ctx.font = `bold ${Math.max(12, Math.floor(cellH * (fx.isCrit ? 0.26 : 0.2)))}px 'DM Mono', monospace`;
        ctx.textAlign = 'center';
        const text = fx.damage < 0 ? `+${Math.abs(fx.damage)}` : `-${fx.damage}`;
        ctx.fillText(text, targetX, floatY);
      }

      ctx.restore();
    }

    ctx.restore();
  }, [
    units,
    walls,
    terrainMap,
    triggeredTraps,
    bossTelegraph,
    visualEffects,
    activeId,
    selectedId,
    moveTiles,
    targetTiles,
    phase,
    getEffectiveStats,
    screenShake,
  ]);

  // Animation frame loop
  useEffect(() => {
    let animationId: number;
    const loop = () => {
      draw();
      animationId = requestAnimationFrame(loop);
    };
    animationId = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(animationId);
  }, [draw]);

  // Handle canvas click and touch for web & mobile browsers
  const handlePointerDown = (clientX: number, clientY: number) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const clickX = clientX - rect.left;
    const clickY = clientY - rect.top;

    const tileX = Math.floor((clickX / rect.width) * GRID_COLS);
    const tileY = Math.floor((clickY / rect.height) * GRID_ROWS);

    if (tileX >= 0 && tileX < GRID_COLS && tileY >= 0 && tileY < GRID_ROWS) {
      onTileClick(tileX, tileY);
    }
  };

  const handleClick = (e: React.MouseEvent<HTMLCanvasElement>) => {
    handlePointerDown(e.clientX, e.clientY);
  };

  const handleTouchEnd = (e: React.TouchEvent<HTMLCanvasElement>) => {
    if (e.changedTouches.length > 0) {
      const touch = e.changedTouches[0];
      handlePointerDown(touch.clientX, touch.clientY);
    }
  };

  return (
    <div ref={containerRef} className="relative w-full aspect-[1.78] max-h-[560px] bg-slate-950 rounded-xl overflow-hidden shadow-2xl border border-emerald-950/40 select-none">
      <canvas
        ref={canvasRef}
        onClick={handleClick}
        onTouchEnd={handleTouchEnd}
        className="w-full h-full block cursor-pointer touch-none"
      />
    </div>
  );
};
