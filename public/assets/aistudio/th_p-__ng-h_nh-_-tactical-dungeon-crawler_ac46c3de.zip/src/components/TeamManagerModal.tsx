import React, { useState } from 'react';
import { Unit, GearItem, SlotType, EffectiveStats } from '../types/game';
import { CLASS_NAMES, SLOT_NAMES, RARITY_COLORS } from '../game/constants';
import { X, Shield, ArrowRight } from 'lucide-react';

interface TeamManagerModalProps {
  heroes: Unit[];
  equipped: Record<string, Record<string, GearItem>>;
  inventory: GearItem[];
  gold: number;
  onClose: () => void;
  onEquip: (unitId: string, item: GearItem) => void;
  onUnequip: (unitId: string, slot: SlotType) => void;
  getEffectiveStats: (unit: Unit) => EffectiveStats;
}

export const TeamManagerModal: React.FC<TeamManagerModalProps> = ({
  heroes,
  equipped,
  inventory,
  gold,
  onClose,
  onEquip,
  onUnequip,
  getEffectiveStats,
}) => {
  const [selectedHeroId, setSelectedHeroId] = useState<string>(heroes[0]?.id || '');
  const activeHero = heroes.find((h) => h.id === selectedHeroId) || heroes[0];
  const eff = activeHero ? getEffectiveStats(activeHero) : null;

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-4xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Modal Header */}
        <div className="flex items-center justify-between p-4 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <Shield className="w-5 h-5 text-emerald-400" />
            <div>
              <h2 className="text-base font-bold text-slate-100 uppercase tracking-wide">
                Đội Hình & Quản Lý Trang Bị
              </h2>
              <p className="text-xs text-slate-400">
                Thay đổi vũ khí, khiên, giáp và nhẫn bảo hộ cho từng chiến binh
              </p>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <span className="font-mono text-amber-400 font-bold text-sm">{gold} ◈</span>
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-slate-100 hover:bg-slate-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-4 grid grid-cols-1 md:grid-cols-3 gap-4">
          {/* Hero Selection Column */}
          <div className="space-y-2">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider block mb-2">
              Chọn Chiến Binh
            </span>
            {heroes.map((hero) => {
              const isSelected = hero.id === selectedHeroId;
              const heroEff = getEffectiveStats(hero);
              return (
                <div
                  key={hero.id}
                  onClick={() => setSelectedHeroId(hero.id)}
                  className={`p-3 rounded-xl border cursor-pointer transition-all flex items-center justify-between ${
                    isSelected
                      ? 'bg-slate-800 border-emerald-500 shadow-md'
                      : 'bg-slate-950/40 border-slate-800 hover:bg-slate-800/40'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div
                      className="w-8 h-8 rounded-lg flex items-center justify-center font-bold text-sm shadow"
                      style={{ backgroundColor: hero.color, color: '#090d0b' }}
                    >
                      {hero.glyph}
                    </div>
                    <div>
                      <div className="font-bold text-sm text-slate-200">{hero.name}</div>
                      <div className="text-[11px] text-slate-400 font-mono">
                        {CLASS_NAMES[hero.id]} · LV {hero.level}
                      </div>
                    </div>
                  </div>
                  <div className="text-right font-mono text-xs">
                    <div className="text-emerald-400 font-semibold">
                      HP {hero.hp}/{heroEff.hp}
                    </div>
                    <div className="text-slate-500 text-[10px]">
                      ATK {heroEff.atk} · DEF {heroEff.def}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Equipped Slots & Available Items (2 Columns) */}
          <div className="md:col-span-2 space-y-4">
            {activeHero && eff && (
              <>
                {/* Hero Stat Overview */}
                <div className="bg-slate-950/60 border border-slate-800/80 rounded-xl p-3 flex items-center justify-around font-mono text-xs">
                  <div>
                    <span className="text-slate-500 block text-[10px]">MÁU TỐI ĐA</span>
                    <span className="font-bold text-emerald-400 text-sm">{eff.hp}</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block text-[10px]">NĂNG LƯỢNG (MP)</span>
                    <span className="font-bold text-sky-400 text-sm">{eff.mp}</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block text-[10px]">VẬT CÔNG (ATK)</span>
                    <span className="font-bold text-amber-400 text-sm">{eff.atk}</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block text-[10px]">PHÉP CÔNG (MATK)</span>
                    <span className="font-bold text-indigo-400 text-sm">{eff.matk}</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block text-[10px]">PHÒNG THỦ (DEF)</span>
                    <span className="font-bold text-emerald-300 text-sm">{eff.def}</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block text-[10px]">TỐC ĐỘ (SPD)</span>
                    <span className="font-bold text-slate-200 text-sm">{eff.spd}</span>
                  </div>
                </div>

                {/* Slots */}
                <div className="space-y-3">
                  {(['weapon', 'shield', 'armor', 'ring'] as SlotType[]).map((slotKey) => {
                    const currentItem = equipped[activeHero.id]?.[slotKey];
                    // Available matching items in inventory (Classless: any hero can equip any item)
                    const candidateItems = inventory.filter((item) => item.slot === slotKey);

                    return (
                      <div
                        key={slotKey}
                        className="bg-slate-950/40 border border-slate-800/80 rounded-xl p-3 flex flex-col gap-2"
                      >
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-bold text-slate-400 uppercase tracking-wider font-mono">
                            {SLOT_NAMES[slotKey]}
                          </span>

                          {currentItem && (
                            <button
                              onClick={() => onUnequip(activeHero.id, slotKey)}
                              className="text-[11px] font-mono text-rose-400 hover:text-rose-300 transition-colors"
                            >
                              Tháo bỏ [x]
                            </button>
                          )}
                        </div>

                        {/* Current Item Card */}
                        {currentItem ? (
                          <div className="flex items-center justify-between p-2.5 rounded-lg bg-slate-900 border border-slate-700/60">
                            <div className="flex items-center gap-2.5">
                              <span className="text-lg">{currentItem.icon}</span>
                              <div>
                                <div className="font-semibold text-xs text-slate-200 flex items-center gap-1.5">
                                  <span>{currentItem.name}</span>
                                  <span
                                    className="text-[10px] font-mono"
                                    style={{ color: RARITY_COLORS[currentItem.rarity - 1] }}
                                  >
                                    {'★'.repeat(currentItem.rarity)}
                                  </span>
                                </div>
                                <div className="text-[10px] font-mono text-slate-400">
                                  {Object.entries(currentItem.stats)
                                    .map(([k, v]) => `${k.toUpperCase()} +${String(v).includes('.') ? Math.round(Number(v) * 100) + '%' : v}`)
                                    .join(' · ')}
                                </div>
                              </div>
                            </div>
                            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-800">
                              Đang Mang
                            </span>
                          </div>
                        ) : (
                          <div className="text-xs text-slate-500 italic p-2 rounded bg-slate-950/40 border border-slate-800/40">
                            Chưa trang bị vật phẩm nào ở vị trí này.
                          </div>
                        )}

                        {/* Inventory Options for this slot */}
                        {candidateItems.length > 0 && (
                          <div className="pt-2 border-t border-slate-800/50">
                            <span className="text-[10px] font-mono text-slate-400 block mb-1.5">
                              Vật phẩm trong túi có thể trang bị ({candidateItems.length}):
                            </span>
                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                              {candidateItems.map((item) => (
                                <button
                                  key={item.id}
                                  onClick={() => onEquip(activeHero.id, item)}
                                  className="p-2 rounded-lg bg-slate-900/80 hover:bg-slate-800 border border-slate-800 hover:border-emerald-600/60 transition-all text-left flex items-center justify-between group"
                                >
                                  <div className="flex items-center gap-2">
                                    <span className="text-base">{item.icon}</span>
                                    <div>
                                      <div className="text-xs font-medium text-slate-200 group-hover:text-emerald-300">
                                        {item.name}
                                      </div>
                                      <div className="text-[9px] font-mono text-slate-400">
                                        {Object.entries(item.stats)
                                          .map(([k, v]) => `${k.toUpperCase()} +${String(v).includes('.') ? Math.round(Number(v) * 100) + '%' : v}`)
                                          .join(' ')}
                                      </div>
                                    </div>
                                  </div>
                                  <ArrowRight className="w-3.5 h-3.5 text-slate-500 group-hover:text-emerald-400 transition-transform group-hover:translate-x-0.5" />
                                </button>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
