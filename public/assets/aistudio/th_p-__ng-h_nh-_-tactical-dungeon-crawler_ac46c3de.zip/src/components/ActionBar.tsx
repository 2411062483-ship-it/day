import React from 'react';
import { Play, Pause, RotateCcw, Volume2, VolumeX, Swords, Shield, Zap, FastForward, UserCheck, Bot } from 'lucide-react';
import { Unit, ControlMode, EffectiveStats } from '../types/game';

interface ActionBarProps {
  phase: string;
  paused: boolean;
  activeUnit: Unit | null;
  controlMode: ControlMode;
  speed: number;
  isMuted: boolean;
  onTogglePlay: () => void;
  onToggleSpeed: () => void;
  onRestartRoom: () => void;
  onToggleMute: () => void;
  onToggleControlMode: () => void;
  onManualAttack: () => void;
  onManualSkill: () => void;
  onManualDefend: () => void;
  onManualEndTurn: () => void;
  getEffectiveStats: (unit: Unit) => EffectiveStats;
}

export const ActionBar: React.FC<ActionBarProps> = ({
  phase,
  paused,
  activeUnit,
  controlMode,
  speed,
  isMuted,
  onTogglePlay,
  onToggleSpeed,
  onRestartRoom,
  onToggleMute,
  onToggleControlMode,
  onManualAttack,
  onManualSkill,
  onManualDefend,
  onManualEndTurn,
  getEffectiveStats,
}) => {
  const isHeroTurn = activeUnit?.kind === 'hero' && !activeUnit.acted && phase === 'playing';
  const eff = activeUnit ? getEffectiveStats(activeUnit) : null;

  return (
    <div className="bg-slate-900/90 backdrop-blur border border-slate-800 rounded-xl p-3.5 shadow-xl flex flex-col gap-3">
      {/* Top status bar of action bar */}
      <div className="flex items-center justify-between border-b border-slate-800/80 pb-2.5">
        <div className="flex items-center gap-2">
          {activeUnit ? (
            <div className="flex items-center gap-2">
              <span
                className="w-2.5 h-2.5 rounded-full animate-pulse"
                style={{ backgroundColor: activeUnit.kind === 'hero' ? '#4ade80' : '#f87171' }}
              />
              <span className="font-semibold text-slate-200 text-sm">{activeUnit.name}</span>
              <span className="text-xs text-slate-400 font-mono">
                SPD {eff?.spd || activeUnit.spd} · MP {activeUnit.mp}/{eff?.mp || activeUnit.maxMp}
              </span>
            </div>
          ) : (
            <div className="flex items-center gap-2 text-slate-400 text-sm">
              <span className="w-2 h-2 rounded-full bg-slate-600" />
              <span>Chờ lệnh bắt đầu trận đấu</span>
            </div>
          )}
        </div>

        {/* Global Controls */}
        <div className="flex items-center gap-1.5">
          {/* Mode switch */}
          <button
            onClick={onToggleControlMode}
            className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-medium transition-all ${
              controlMode === 'auto'
                ? 'bg-emerald-950/60 text-emerald-300 border border-emerald-700/60'
                : 'bg-amber-950/60 text-amber-300 border border-amber-700/60'
            }`}
            title="Đổi giữa Tự động (AI) và Thủ công (Người chơi điều khiển)"
          >
            {controlMode === 'auto' ? <Bot className="w-3.5 h-3.5" /> : <UserCheck className="w-3.5 h-3.5" />}
            <span>{controlMode === 'auto' ? 'Tự Động' : 'Thủ Công'}</span>
          </button>

          {/* Speed button */}
          <button
            onClick={onToggleSpeed}
            className="flex items-center gap-1 px-2 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-mono transition-colors border border-slate-700"
            title="Đổi tốc độ trận đấu"
          >
            <FastForward className="w-3.5 h-3.5 text-emerald-400" />
            <span>{speed}×</span>
          </button>

          {/* Mute button */}
          <button
            onClick={onToggleMute}
            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs transition-colors border border-slate-700"
            title={isMuted ? 'Bật âm thanh' : 'Tắt âm thanh'}
          >
            {isMuted ? <VolumeX className="w-3.5 h-3.5 text-rose-400" /> : <Volume2 className="w-3.5 h-3.5 text-emerald-400" />}
          </button>

          {/* Restart room button */}
          <button
            onClick={onRestartRoom}
            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs transition-colors border border-slate-700"
            title="Chơi lại căn phòng này"
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Main Action Buttons */}
      <div className="flex flex-wrap items-center justify-between gap-2">
        {/* Play / Pause Primary CTA */}
        <button
          onClick={onTogglePlay}
          disabled={phase === 'won' || phase === 'lost'}
          className={`flex-1 min-w-[140px] flex items-center justify-center gap-2 px-4 py-2 rounded-lg font-bold text-xs uppercase tracking-wider transition-all shadow-md ${
            phase === 'ready'
              ? 'bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black'
              : paused
              ? 'bg-emerald-600 hover:bg-emerald-500 text-white'
              : 'bg-slate-800 hover:bg-slate-700 text-amber-300 border border-amber-600/50'
          }`}
        >
          {phase === 'ready' ? (
            <>
              <Play className="w-4 h-4 fill-current" />
              <span>BẮT ĐẦU TRẬN ĐẤU</span>
            </>
          ) : paused ? (
            <>
              <Play className="w-4 h-4 fill-current" />
              <span>TIẾP TỤC</span>
            </>
          ) : (
            <>
              <Pause className="w-4 h-4" />
              <span>TẠM DỪNG</span>
            </>
          )}
        </button>

        {/* Manual Skill & Action Bar (when in manual mode during player's turn) */}
        {controlMode === 'manual' && isHeroTurn && (
          <div className="flex items-center gap-1.5 flex-1">
            <button
              onClick={onManualAttack}
              className="flex-1 flex items-center justify-center gap-1 px-3 py-2 rounded-lg bg-amber-600/20 hover:bg-amber-600/30 text-amber-300 border border-amber-500/40 text-xs font-semibold transition-colors"
            >
              <Swords className="w-3.5 h-3.5" />
              <span>Đánh</span>
            </button>

            <button
              onClick={onManualSkill}
              className="flex-1 flex items-center justify-center gap-1 px-3 py-2 rounded-lg bg-indigo-600/20 hover:bg-indigo-600/30 text-indigo-300 border border-indigo-500/40 text-xs font-semibold transition-colors"
            >
              <Zap className="w-3.5 h-3.5" />
              <span>Kỹ năng</span>
            </button>

            <button
              onClick={onManualDefend}
              className="flex-1 flex items-center justify-center gap-1 px-3 py-2 rounded-lg bg-sky-600/20 hover:bg-sky-600/30 text-sky-300 border border-sky-500/40 text-xs font-semibold transition-colors"
            >
              <Shield className="w-3.5 h-3.5" />
              <span>Thủ</span>
            </button>

            <button
              onClick={onManualEndTurn}
              className="px-3 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 text-xs font-semibold transition-colors"
            >
              Qua lượt
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
