export type UnitKind = 'hero' | 'enemy';

export interface WeaponStats {
  atk?: number;
  matk?: number;
  def?: number;
  spd?: number;
  range?: number;
  move?: number;
  mp?: number;
  hp?: number;
  hpPct?: number;
  atkPct?: number;
  matkPct?: number;
}

export type SlotType = 'weapon' | 'shield' | 'armor' | 'ring';
export type WeaponFamily = 'sword' | 'axe' | 'staff' | 'tome' | 'bell' | 'bow' | 'crossbow' | 'dagger' | 'spear' | 'hammer';

export interface GearTemplate {
  name: string;
  type: SlotType;
  slot: SlotType;
  family?: WeaponFamily;
  icon: string;
  classIds: string[];
  stats: WeaponStats;
}

export interface GearItem {
  id: string;
  name: string;
  type: SlotType;
  slot: SlotType;
  family?: WeaponFamily | null;
  icon: string;
  classIds: string[];
  stats: WeaponStats;
  rarity: number; // 1 to 5
  floor: number;
  sellPrice: number;
  price?: number; // When displayed in shop
}

export interface Unit {
  id: string;
  name: string;
  role: string;
  kind: UnitKind;
  glyph: string;
  color: string;
  x: number;
  y: number;
  hp: number;
  maxHp: number;
  mp: number;
  maxMp: number;
  atk: number;
  matk: number;
  def: number;
  spd: number;
  range: number;
  move: number;
  level: number;
  exp: number;
  acted: boolean;
  moved: boolean;
  guard: number;
  inTransit?: boolean;
  species?: 'human' | 'snake' | 'kraken' | 'cerberus' | 'bird' | 'golem' | 'slime' | 'beholder' | 'treant' | 'banshee' | 'mimic' | 'ash-archer';
  ability?: string;
  passiveName?: string;
  passiveDesc?: string;
  boss?: boolean;
  bossCycle?: number;
  pendingBossSkill?: {
    type: 'slap' | 'roar' | 'bite';
    targetId?: string;
  } | null;
  cooldown?: number;
  stun?: number;
  poisonTicks?: number;
  burnTicks?: number;
  blindTicks?: number;
  weakenTicks?: number;
  entangledTicks?: number;
  rageMode?: boolean;
  swordKiStacks?: number;
  weaponMastery?: Record<string, number>;
  animation?: {
    fromX: number;
    fromY: number;
    toX: number;
    toY: number;
    start: number;
    duration: number;
  } | null;
}

export interface EffectiveStats {
  hp: number;
  mp: number;
  atk: number;
  matk: number;
  def: number;
  spd: number;
  range: number;
  move: number;
  hpPct: number;
  atkPct: number;
  matkPct: number;
}

export interface TerrainTile {
  type: 'water' | 'abyss' | 'bridge' | 'lava' | 'trap' | 'portal';
}

export interface BossTelegraph {
  x: number;
  y: number;
  type: 'slap' | 'roar' | 'bite';
}

export interface VisualEffect {
  id?: string;
  fromX: number;
  fromY: number;
  toX: number;
  toY: number;
  type: 'strike' | 'arrow' | 'fire' | 'bash' | 'spell' | 'enemy' | 'heal' | 'bite' | 'tentacle' | 'claw3' | 'feather' | 'eye_ray' | 'entangle' | 'wail';
  damage: number;
  floatingText?: string;
  isCrit?: boolean;
  color: string;
  start: number;
  duration: number;
}

export interface CombatLogEntry {
  id: string;
  message: string;
  type: 'normal' | 'good' | 'enemy' | 'item' | 'skill';
  time: string;
}

export type GamePhase = 'title' | 'setup' | 'ready' | 'playing' | 'exiting' | 'won' | 'lost' | 'recruit';
export type ControlMode = 'auto' | 'manual';
