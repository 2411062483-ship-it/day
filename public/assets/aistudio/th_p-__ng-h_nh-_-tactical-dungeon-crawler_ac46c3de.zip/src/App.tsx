import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  Unit,
  GearItem,
  GearTemplate,
  TerrainTile,
  BossTelegraph,
  VisualEffect,
  CombatLogEntry,
  GamePhase,
  ControlMode,
  EffectiveStats,
  SlotType,
} from './types/game';
import {
  BASE_HEROES,
  GEAR_CATALOG,
  ENEMY_CATALOG,
  BOSS_TEMPLATES,
  TERRAIN_PRESETS,
  WALL_LAYOUTS,
  GRID_COLS,
  GRID_ROWS,
  EXIT_DOOR,
  PLAYBACK_SPEEDS,
  WEAPON_FAMILIES,
  WEAPON_XP_PER_RANK,
  WEAPON_XP_PER_HIT,
  CLASS_NAMES,
  SLOT_NAMES,
} from './game/constants';
import {
  manhattan,
  isOccupied,
  clearShot,
  getReachableTiles,
  findPathToAttackRange,
  findShortestStep,
  ensureMapConnectivity,
  Point,
} from './game/pathfinding';
import { sound } from './audio/sound';
import { BattleCanvas } from './components/BattleCanvas';
import { ActionBar } from './components/ActionBar';
import { PartySidebar } from './components/PartySidebar';
import { CombatLog } from './components/CombatLog';
import { TitleScreen } from './components/TitleScreen';
import { TeamManagerModal } from './components/TeamManagerModal';
import { InventoryManagerModal } from './components/InventoryManagerModal';
import { ShopModal } from './components/ShopModal';
import { RecruitModal } from './components/RecruitModal';
import { GameOverModal } from './components/GameOverModal';
import { Shield, Sparkles, Store, Backpack, Crown, HelpCircle, Maximize, Minimize } from 'lucide-react';

const SAVE_KEY = 'tower_companions_save_v4';

export default function App() {
  // Screen & Phase
  const [phase, setPhase] = useState<GamePhase>('title');
  const [controlMode, setControlMode] = useState<ControlMode>('auto');
  const [floor, setFloor] = useState<number>(1);
  const [round, setRound] = useState<number>(1);
  const [floorBoss, setFloorBoss] = useState<boolean>(false);
  const [hasSave, setHasSave] = useState<boolean>(false);
  const [saveFloor, setSaveFloor] = useState<number>(1);

  // Party & Inventory
  const [partyIds, setPartyIds] = useState<string[]>(['swordsman', 'tank']);
  const [heroRoster, setHeroRoster] = useState<Unit[]>(() =>
    BASE_HEROES.map((h) => ({ ...h, weaponMastery: {} }))
  );
  const [equipped, setEquipped] = useState<Record<string, Record<string, GearItem>>>({});
  const [inventory, setInventory] = useState<GearItem[]>([]);
  const [gold, setGold] = useState<number>(30);
  const [shopStock, setShopStock] = useState<GearItem[]>([]);

  // Room Board State
  const [units, setUnits] = useState<Unit[]>([]);
  const [walls, setWalls] = useState<Set<string>>(new Set());
  const [terrainMap, setTerrainMap] = useState<Map<string, TerrainTile>>(new Map());
  const [portalPoints, setPortalPoints] = useState<Point[]>([]);
  const [triggeredTraps, setTriggeredTraps] = useState<Set<string>>(new Set());
  const [bossTelegraph, setBossTelegraph] = useState<BossTelegraph[]>([]);

  // Turn management
  const [activeId, setActiveId] = useState<string | null>(null);
  const [selectedHeroId, setSelectedHeroId] = useState<string | null>('swordsman');
  const [selectedId, setSelectedId] = useState<string | null>('swordsman');
  const [order, setOrder] = useState<Unit[]>([]);
  const [turnIndex, setTurnIndex] = useState<number>(0);
  const [paused, setPaused] = useState<boolean>(false);
  const [speedIndex, setSpeedIndex] = useState<number>(0);
  const [isMuted, setIsMuted] = useState<boolean>(sound.getMuted());

  // Interactive targeting
  const [moveTiles, setMoveTiles] = useState<Point[]>([]);
  const [targetTiles, setTargetTiles] = useState<Point[]>([]);
  const [targetingAction, setTargetingAction] = useState<'attack' | 'skill' | null>(null);

  // FX & Logs
  const [visualEffects, setVisualEffects] = useState<VisualEffect[]>([]);
  const [screenShake, setScreenShake] = useState<number>(0);
  const [logs, setLogs] = useState<CombatLogEntry[]>([]);

  // Modals
  const [teamModalOpen, setTeamModalOpen] = useState<boolean>(false);
  const [inventoryModalOpen, setInventoryModalOpen] = useState<boolean>(false);
  const [shopModalOpen, setShopModalOpen] = useState<boolean>(false);
  const [recruitCandidate, setRecruitCandidate] = useState<Unit | null>(null);
  const [gameOverResult, setGameOverResult] = useState<'won' | 'lost' | null>(null);
  const [floorLootFound, setFloorLootFound] = useState<GearItem[]>([]);
  const [floorGoldEarned, setFloorGoldEarned] = useState<number>(0);
  const [isFullscreen, setIsFullscreen] = useState<boolean>(false);

  const toggleFullscreen = () => {
    try {
      if (!document.fullscreenElement) {
        document.documentElement.requestFullscreen?.().catch(() => {});
        setIsFullscreen(true);
      } else {
        document.exitFullscreen?.().catch(() => {});
        setIsFullscreen(false);
      }
    } catch {}
  };

  // Room generation token to cancel stale timeouts
  const roomGenRef = useRef<number>(0);

  // Helper to add combat log
  const addLog = useCallback(
    (message: string, type: 'normal' | 'good' | 'enemy' | 'item' | 'skill' = 'normal') => {
      const now = new Date();
      const timeStr = `${String(now.getMinutes()).padStart(2, '0')}:${String(now.getSeconds()).padStart(2, '0')}`;
      setLogs((prev) => [
        { id: `log-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`, message, type, time: timeStr },
        ...prev.slice(0, 40),
      ]);
    },
    []
  );

  // Trigger floating visual effect on canvas
  const triggerEffect = useCallback(
    (
      attacker: Point,
      target: Point,
      type: 'strike' | 'arrow' | 'fire' | 'bash' | 'spell' | 'enemy' | 'heal' | 'bite' | 'tentacle' | 'claw3' | 'feather' | 'eye_ray' | 'entangle' | 'wail',
      damage: number,
      isCrit: boolean = false,
      floatingText?: string
    ) => {
      const colorMap: Record<string, string> = {
        strike: '#fde047',
        arrow: '#4ade80',
        fire: '#f97316',
        bash: '#f59e0b',
        spell: '#c084fc',
        enemy: '#f87171',
        heal: '#22c55e',
        bite: '#10b981',
        tentacle: '#a855f7',
        claw3: '#ef4444',
        feather: '#06b6d4',
        eye_ray: '#c084fc',
        entangle: '#22c55e',
        wail: '#67e8f9',
      };
      setVisualEffects((prev) => [
        ...prev,
        {
          id: `fx-${Date.now()}-${Math.random()}`,
          fromX: attacker.x,
          fromY: attacker.y,
          toX: target.x,
          toY: target.y,
          type,
          damage,
          floatingText,
          isCrit,
          color: colorMap[type] || '#ffffff',
          start: performance.now(),
          duration: 550,
        },
      ]);
    },
    []
  );

  // Calculate effective stats including gear & mastery & passives
  const getEffectiveStats = useCallback(
    (unit: Unit): EffectiveStats => {
      const result: EffectiveStats = {
        hp: unit.maxHp,
        mp: unit.maxMp,
        atk: unit.atk,
        matk: unit.matk,
        def: unit.def,
        spd: unit.spd,
        range: unit.range,
        move: unit.move,
        hpPct: 0,
        atkPct: 0,
        matkPct: 0,
      };

      const unitEquip = equipped[unit.id];
      const weapon = unitEquip?.weapon;

      if (unit.kind === 'hero') {
        if (weapon?.family) {
          if (weapon.family === 'bow' || weapon.family === 'crossbow') {
            result.range = 3;
          } else if (weapon.family === 'staff' || weapon.family === 'tome') {
            result.range = 3;
          } else if (weapon.family === 'spear' || weapon.family === 'bell') {
            result.range = 2;
          } else {
            result.range = 1;
          }
        } else {
          if (unit.id === 'swordsman' || unit.id === 'tank') result.range = 1;
          else if (unit.id === 'archer' || unit.id === 'mage') result.range = 3;
          else if (unit.id === 'cleric') result.range = 2;
        }

        // Shield wearer bonus
        if (unitEquip?.shield) {
          result.def += 2;
          result.hp += 6;
        }
      }

      // Sword Ki stacks from Swordsman passive
      if (unit.swordKiStacks) {
        result.atk += unit.swordKiStacks;
      }
      // Hellhound Rage mode passive
      if (unit.rageMode) {
        result.atk += 4;
        result.spd += 2;
      }
      // Blind effect from Kraken
      if (unit.blindTicks && unit.blindTicks > 0) {
        result.range = Math.max(1, result.range - 1);
        result.spd = Math.max(1, result.spd - 2);
      }

      if (unitEquip) {
        for (const item of Object.values(unitEquip)) {
          if (!item?.stats) continue;
          for (const [k, val] of Object.entries(item.stats)) {
            const num = Number(val) || 0;
            if (k === 'hpPct') result.hpPct += num;
            else if (k === 'atkPct') result.atkPct += num;
            else if (k === 'matkPct') result.matkPct += num;
            else if (k in result) {
              (result as unknown as Record<string, number>)[k] += num;
            }
          }
        }
      }

      // Weapon mastery bonus
      if (weapon?.family && WEAPON_FAMILIES[weapon.family]) {
        const masteryXp = unit.weaponMastery?.[weapon.family] || 0;
        const rank = Math.floor(masteryXp / WEAPON_XP_PER_RANK);
        const statsBonus = WEAPON_FAMILIES[weapon.family].stats;
        for (const [k, v] of Object.entries(statsBonus)) {
          if (k in result) {
            (result as unknown as Record<string, number>)[k] += v * rank;
          }
        }
      }

      result.hp = Math.round(result.hp * (1 + result.hpPct));
      result.atk = Math.max(1, Math.round(result.atk * (1 + result.atkPct)) - (unit.weakenTicks ? 2 : 0));
      result.matk = Math.max(0, Math.round(result.matk * (1 + result.matkPct)) - (unit.weakenTicks ? 2 : 0));

      return result;
    },
    [equipped]
  );

  // Weapon item generator
  const createGear = useCallback((template: GearTemplate, rarity: number = 1, atFloor: number = 1): GearItem => {
    const stats = { ...template.stats };
    const floorBonus = Math.floor(Math.max(0, atFloor - 1) / 3);

    for (const [key, val] of Object.entries(stats)) {
      if (key.endsWith('Pct')) {
        stats[key as keyof typeof stats] = Math.min(
          0.2,
          (val || 0) + (rarity - 1) * 0.02 + Math.floor(Math.max(0, atFloor - 1) / 5) * 0.01
        );
      } else {
        stats[key as keyof typeof stats] = (val || 0) + floorBonus + (rarity - 1);
      }
    }

    return {
      id: `gear-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
      name: template.name,
      type: template.type,
      slot: template.slot,
      family: template.family || null,
      icon: template.icon,
      classIds: [...template.classIds],
      stats,
      rarity,
      floor: atFloor,
      sellPrice: Math.max(4, Math.round((6 + rarity * 5 + atFloor * 1.5) * (template.type === 'ring' ? 1.3 : 1))),
    };
  }, []);

  // Generate rotating shop items
  const generateShopStock = useCallback(
    (currentFloor: number): GearItem[] => {
      return Array.from({ length: 6 }, () => {
        const template = GEAR_CATALOG[Math.floor(Math.random() * GEAR_CATALOG.length)];
        const rarity = Math.random() < 0.7 ? 1 : Math.random() < 0.9 ? 2 : 3;
        const item = createGear(template, rarity, currentFloor);
        item.price = Math.round(item.sellPrice * 1.7);
        return item;
      });
    },
    [createGear]
  );

  // Gain weapon mastery on hit
  const gainWeaponMastery = useCallback(
    (unit: Unit) => {
      const weapon = equipped[unit.id]?.weapon;
      if (!weapon?.family || unit.kind !== 'hero') return;

      const currentXp = unit.weaponMastery?.[weapon.family] || 0;
      const beforeRank = Math.floor(currentXp / WEAPON_XP_PER_RANK);
      const nextXp = currentXp + WEAPON_XP_PER_HIT;
      const afterRank = Math.floor(nextXp / WEAPON_XP_PER_RANK);

      const updatedMastery = { ...(unit.weaponMastery || {}), [weapon.family]: nextXp };
      unit.weaponMastery = updatedMastery;

      setHeroRoster((prev) =>
        prev.map((h) => (h.id === unit.id ? { ...h, weaponMastery: updatedMastery } : h))
      );

      if (afterRank > beforeRank) {
        sound.playLevelUp();
        addLog(
          `<b>${unit.name}</b> đã nâng bậc thuần thục <b>${
            WEAPON_FAMILIES[weapon.family]?.label || weapon.family
          }</b> lên Cấp ${afterRank}!`,
          'good'
        );
      }
    },
    [equipped, addLog]
  );

  // Check saved state in localStorage
  useEffect(() => {
    try {
      const raw = localStorage.getItem(SAVE_KEY);
      if (raw) {
        const data = JSON.parse(raw);
        if (data && data.partyIds && data.partyIds.length > 0) {
          setHasSave(true);
          setSaveFloor(data.floor || 1);
        }
      }
    } catch {
      setHasSave(false);
    }
  }, []);

  // Save game progress
  const saveGame = useCallback(() => {
    try {
      const stateToSave = {
        floor,
        partyIds,
        heroRoster,
        equipped,
        inventory,
        gold,
      };
      localStorage.setItem(SAVE_KEY, JSON.stringify(stateToSave));
      setHasSave(true);
      setSaveFloor(floor);
    } catch {}
  }, [floor, partyIds, heroRoster, equipped, inventory, gold]);

  // Load saved run
  const handleContinueSavedRun = () => {
    try {
      const raw = localStorage.getItem(SAVE_KEY);
      if (!raw) return;
      const data = JSON.parse(raw);
      setFloor(data.floor || 1);
      setPartyIds(data.partyIds || ['swordsman', 'tank']);
      if (data.heroRoster) setHeroRoster(data.heroRoster);
      if (data.equipped) setEquipped(data.equipped);
      if (data.inventory) setInventory(data.inventory);
      if (data.gold !== undefined) setGold(data.gold);
      setShopStock(generateShopStock(data.floor || 1));
      setPhase('ready');
      sound.playClick();
      setupFloor(data.floor || 1, data.partyIds || ['swordsman', 'tank'], data.heroRoster || BASE_HEROES);
    } catch {
      setHasSave(false);
    }
  };

  // Start brand new run
  const handleStartNewRun = (starterIds: string[], starterWeapons: Record<string, string>) => {
    roomGenRef.current++;
    const resetRoster = BASE_HEROES.map((h) => ({ ...h, level: 1, exp: 0, weaponMastery: {} }));
    setHeroRoster(resetRoster);
    setPartyIds(starterIds);
    setFloor(1);
    setGold(35);
    setInventory([]);
    setFloorLootFound([]);
    setFloorGoldEarned(0);

    const initialEquipped: Record<string, Record<string, GearItem>> = {};
    for (const heroId of starterIds) {
      const weaponName = starterWeapons[heroId] || 'Kiếm Lò Rèn';
      const template = GEAR_CATALOG.find((g) => g.name === weaponName && g.slot === 'weapon') || GEAR_CATALOG[0];
      const item = createGear(template, 1, 1);
      initialEquipped[heroId] = { weapon: item };
    }
    setEquipped(initialEquipped);
    setShopStock(generateShopStock(1));

    sound.playClick();
    setupFloor(1, starterIds, resetRoster);
  };

  // Setup / Reset current floor
  const setupFloor = (
    targetFloor: number,
    activePartyIds: string[] = partyIds,
    currentRoster: Unit[] = heroRoster
  ) => {
    roomGenRef.current++;
    setRound(1);
    setActiveId(null);
    setPaused(false);
    setOrder([]);
    setTurnIndex(0);
    setMoveTiles([]);
    setTargetTiles([]);
    setBossTelegraph([]);
    setVisualEffects([]);
    setTargetingAction(null);
    setFloorLootFound([]);
    setFloorGoldEarned(0);

    // Wall layout
    const wallChoice = WALL_LAYOUTS[(targetFloor - 1) % WALL_LAYOUTS.length];
    const newWalls = new Set<string>(wallChoice);

    // Terrain preset
    const preset = TERRAIN_PRESETS[(targetFloor - 1) % TERRAIN_PRESETS.length];
    const newTerrain = new Map<string, TerrainTile>();
    for (const [key, type] of preset.terrain) {
      newTerrain.set(key, { type: type as TerrainTile['type'] });
    }

    const portals: Point[] = [];
    for (const [key, tile] of newTerrain.entries()) {
      if (tile.type === 'portal') {
        const [px, py] = key.split(',').map(Number);
        portals.push({ x: px, y: py });
      }
    }
    setPortalPoints(portals);
    setTriggeredTraps(new Set());

    // Validate map connectivity so heroes never get softlocked
    ensureMapConnectivity(newWalls, newTerrain);
    setWalls(newWalls);
    setTerrainMap(newTerrain);

    // Spawns
    const isBoss =
      targetFloor === 10 ||
      (targetFloor >= 4 && Math.random() < (targetFloor % 5 === 0 ? 0.75 : 0.25));
    setFloorBoss(isBoss);

    const partyUnits: Unit[] = [];
    const heroSpawns = [
      { x: 1, y: 2 },
      { x: 1, y: 3 },
      { x: 1, y: 5 },
      { x: 2, y: 4 },
      { x: 2, y: 6 },
    ];

    activePartyIds.forEach((id, idx) => {
      const base = currentRoster.find((h) => h.id === id);
      if (base) {
        const spawn = heroSpawns[idx] || { x: 1, y: 2 + idx };
        partyUnits.push({
          ...base,
          x: spawn.x,
          y: spawn.y,
          hp: base.maxHp,
          mp: base.maxMp,
          acted: false,
          moved: false,
          guard: 0,
          inTransit: false,
        });
      }
    });

    const enemyUnits: Unit[] = [];
    const spawnPoints = [
      { x: 9, y: 2 },
      { x: 10, y: 5 },
      { x: 8, y: 6 },
      { x: 9, y: 6 },
      { x: 7, y: 2 },
      { x: 8, y: 4 },
    ];

    const scale = targetFloor <= 3 ? 0.75 + targetFloor * 0.08 : 0.95 + (targetFloor - 4) * 0.07;
    const enemyCount = targetFloor <= 2 ? 2 : Math.min(5, 2 + Math.floor((targetFloor - 1) / 3));

    for (let i = 0; i < enemyCount; i++) {
      const template = ENEMY_CATALOG[Math.floor(Math.random() * ENEMY_CATALOG.length)];
      const spawn = spawnPoints[i] || { x: 9, y: 3 };
      enemyUnits.push({
        id: `${template.id}-${i}-${Date.now()}`,
        name: template.name,
        role: template.role,
        kind: 'enemy',
        glyph: template.glyph,
        color: template.color,
        x: spawn.x,
        y: spawn.y,
        hp: Math.round(template.hp * scale),
        maxHp: Math.round(template.hp * scale),
        mp: template.ability === 'hex' ? 12 : 0,
        maxMp: template.ability === 'hex' ? 12 : 0,
        atk: Math.round(template.atk * scale),
        matk: template.ability === 'hex' ? 8 + Math.floor(targetFloor / 3) : 0,
        def: template.def + Math.floor((targetFloor - 1) / 5),
        spd: template.spd,
        range: template.range,
        move: template.move,
        level: targetFloor,
        exp: 0,
        acted: false,
        moved: false,
        guard: 0,
        species: template.species || 'human',
        ability: template.ability,
        passiveName: template.passiveName,
        passiveDesc: template.passiveDesc,
        cooldown: 0,
        stun: 0,
        poisonTicks: 0,
      });
    }

    // Add Boss if triggered
    if (isBoss) {
      const bossTemplate =
        targetFloor === 10
          ? BOSS_TEMPLATES.find((b) => b.id === 'minochoco')!
          : BOSS_TEMPLATES[Math.floor(Math.random() * BOSS_TEMPLATES.length)];

      enemyUnits.push({
        id: `boss-${bossTemplate.id}-${Date.now()}`,
        name: bossTemplate.name,
        role: bossTemplate.role,
        kind: 'enemy',
        glyph: bossTemplate.glyph,
        color: bossTemplate.color,
        x: 10,
        y: 3,
        hp: Math.round(bossTemplate.hp * scale),
        maxHp: Math.round(bossTemplate.hp * scale),
        mp: 0,
        maxMp: 0,
        atk: Math.round(bossTemplate.atk * scale),
        matk: 0,
        def: bossTemplate.def + Math.floor((targetFloor - 1) / 6),
        spd: bossTemplate.spd,
        range: bossTemplate.range,
        move: bossTemplate.move,
        level: targetFloor,
        exp: 0,
        acted: false,
        moved: false,
        guard: 0,
        boss: true,
        bossCycle: 0,
        species: bossTemplate.species || 'snake',
        ability: bossTemplate.ability,
        passiveName: bossTemplate.passiveName,
        passiveDesc: bossTemplate.passiveDesc,
        cooldown: 0,
        stun: 0,
        poisonTicks: 0,
      });
    }

    const initialUnits = [...partyUnits, ...enemyUnits];
    setUnits(initialUnits);
    setSelectedHeroId(activePartyIds[0]);
    setSelectedId(activePartyIds[0]);
    setPhase('ready');

    addLog(
      `Đội thám hiểm tiến vào <b>Tầng ${targetFloor}</b>: ${preset.name}${
        isBoss ? ' — ⚠️ CẢNH BÁO BOSS XUẤT HIỆN!' : ''
      }.`,
      isBoss ? 'enemy' : 'good'
    );
  };

  // Build turn order & start combat
  const startCombat = useCallback(() => {
    const alive = units.filter((u) => u.hp > 0);
    const sorted = [...alive].sort((a, b) => {
      const spdDiff = getEffectiveStats(b).spd - getEffectiveStats(a).spd;
      if (spdDiff !== 0) return spdDiff;
      return a.kind === 'hero' ? -1 : 1;
    });

    setOrder(sorted);
    setTurnIndex(0);
    setPhase('playing');
    setPaused(false);
    addLog('Trận đấu bắt đầu! Thứ tự hành động được sắp xếp theo tốc độ (SPD).', 'good');
  }, [units, getEffectiveStats, addLog]);

  // Handle terrain entry on step
  const resolveTerrainStep = useCallback(
    (unit: Unit, newX: number, newY: number) => {
      const key = `${newX},${newY}`;
      const tile = terrainMap.get(key);
      if (!tile) return;

      if (tile.type === 'trap' && !triggeredTraps.has(key)) {
        sound.playTrap();
        setTriggeredTraps((prev) => new Set(prev).add(key));
        unit.hp = Math.max(0, unit.hp - 5);
        addLog(`<b>${unit.name}</b> đạp phải bẫy chông, mất 5 HP!`, 'enemy');
        triggerEffect(unit, unit, 'enemy', 5);
      } else if (tile.type === 'lava') {
        unit.hp = Math.max(0, unit.hp - 4);
        addLog(`<b>${unit.name}</b> băng qua dung nham, bị bỏng 4 HP!`, 'enemy');
        triggerEffect(unit, unit, 'fire', 4);
      } else if (tile.type === 'portal' && portalPoints.length === 2) {
        const dest = portalPoints.find((p) => p.x !== newX || p.y !== newY);
        if (dest && !isOccupied(dest.x, dest.y, units, unit.id)) {
          sound.playMagic();
          unit.animation = {
            fromX: newX,
            fromY: newY,
            toX: dest.x,
            toY: dest.y,
            start: performance.now(),
            duration: 400,
          };
          unit.x = dest.x;
          unit.y = dest.y;
          addLog(`<b>${unit.name}</b> dịch chuyển tức thời qua cổng không gian!`, 'good');
        }
      }
    },
    [terrainMap, triggeredTraps, portalPoints, units, addLog, triggerEffect]
  );

  // Move unit to tile
  const moveUnit = useCallback(
    (unit: Unit, x: number, y: number) => {
      unit.animation = {
        fromX: unit.x,
        fromY: unit.y,
        toX: x,
        toY: y,
        start: performance.now(),
        duration: 300,
      };
      unit.x = x;
      unit.y = y;
      unit.moved = true;
      resolveTerrainStep(unit, x, y);
    },
    [resolveTerrainStep]
  );

  // Roll enemy loot on defeat
  const dropLoot = useCallback(
    (enemy: Unit) => {
      const earnedGold = enemy.boss
        ? 35 + Math.floor(Math.random() * 20)
        : 4 + Math.floor(Math.random() * 6);
      sound.playGold();
      setGold((prev) => prev + earnedGold);
      setFloorGoldEarned((prev) => prev + earnedGold);
      addLog(`Rơi <b>+${earnedGold} ◈ vàng</b> từ ${enemy.name}.`, 'item');

      const dropRate = enemy.boss ? 0.95 : 0.32;
      if (Math.random() <= dropRate) {
        const weights = enemy.boss ? [0, 15, 35, 35, 15] : [55, 28, 12, 4, 1];
        let roll = Math.random() * weights.reduce((a, b) => a + b, 0);
        let rarity = 1;
        for (let i = 0; i < weights.length; i++) {
          roll -= weights[i];
          if (roll <= 0) {
            rarity = i + 1;
            break;
          }
        }
        const template = GEAR_CATALOG[Math.floor(Math.random() * GEAR_CATALOG.length)];
        const item = createGear(template, rarity, floor);
        setInventory((prev) => [item, ...prev.slice(0, 39)]);
        setFloorLootFound((prev) => [item, ...prev]);
        addLog(
          `Tìm thấy trang bị quý: <b>${item.icon} ${item.name}</b> (${'★'.repeat(rarity)})!`,
          'item'
        );
      }
    },
    [floor, createGear, addLog]
  );

  // Award EXP and handle level ups
  const awardExp = useCallback(
    (killer: Unit) => {
      const livingHeroes = units.filter((u) => u.kind === 'hero' && u.hp > 0);
      livingHeroes.forEach((hero) => {
        const gained = hero.id === killer.id ? 20 : 12;
        hero.exp += gained;

        if (hero.exp >= 40) {
          hero.exp -= 40;
          hero.level += 1;
          hero.maxHp += hero.id === 'tank' ? 8 : hero.id === 'swordsman' ? 6 : 4;
          hero.maxMp += hero.id === 'mage' || hero.id === 'cleric' ? 4 : 2;
          hero.atk += hero.id === 'swordsman' || hero.id === 'archer' ? 2 : 1;
          hero.matk += hero.id === 'mage' ? 2 : hero.id === 'cleric' ? 2 : 0;
          hero.def += hero.id === 'tank' ? 2 : 1;
          hero.hp = Math.min(getEffectiveStats(hero).hp, hero.hp + 8);

          sound.playLevelUp();
          addLog(`🎉 <b>${hero.name}</b> đã thăng cấp lên <b>Cấp ${hero.level}</b>!`, 'good');
        }

        // Sync to persistent hero roster
        setHeroRoster((prev) =>
          prev.map((h) =>
            h.id === hero.id
              ? {
                  ...h,
                  level: hero.level,
                  exp: hero.exp,
                  maxHp: hero.maxHp,
                  maxMp: hero.maxMp,
                  atk: hero.atk,
                  matk: hero.matk,
                  def: hero.def,
                  spd: hero.spd,
                }
              : h
          )
        );
      });
    },
    [units, getEffectiveStats, addLog]
  );

  // Screen shake trigger
  const shakeScreen = (intensity: number = 8) => {
    setScreenShake(intensity);
    setTimeout(() => setScreenShake(0), 200);
  };

  // Perform physical / magical attack with rich passives and visual feedback
  const executeAttack = useCallback(
    (attacker: Unit, target: Unit) => {
      gainWeaponMastery(attacker);
      const attEff = getEffectiveStats(attacker);
      const tarEff = getEffectiveStats(target);
      const weapon = equipped[attacker.id]?.weapon;
      const isMagical =
        attacker.kind === 'hero'
          ? weapon?.family === 'staff' ||
            weapon?.family === 'tome' ||
            weapon?.family === 'bell' ||
            (!weapon && (attacker.id === 'mage' || attacker.id === 'cleric'))
          : attacker.species === 'beholder' ||
            attacker.species === 'banshee' ||
            attacker.matk > attacker.atk;

      let basePower = isMagical ? attEff.matk : attEff.atk;
      let isCrit = Math.random() < (weapon?.family === 'dagger' ? 0.35 : 0.15);

      // PASSIVE: Linh (Archer) - Mắt Đại Bàng (hoặc người cầm Cung xa)
      if ((attacker.id === 'archer' || weapon?.family === 'bow') && manhattan(attacker, target) >= 3) {
        if (Math.random() < 0.45) isCrit = true;
        basePower = Math.round(basePower * 1.25);
        triggerEffect(attacker, target, 'arrow', 0, false, '🦅 MẮT ĐẠI BÀNG!');
      }

      // PASSIVE: Bảo (Swordsman) - Kiếm Khí Trảm
      if (attacker.id === 'swordsman' || weapon?.family === 'sword') {
        attacker.swordKiStacks = Math.min(5, (attacker.swordKiStacks || 0) + 1);
        if (target.hp < tarEff.hp * 0.4) {
          basePower = Math.round(basePower * 1.35);
          triggerEffect(attacker, target, 'strike', 0, false, '✦ KIẾM KHÍ TRẢM!');
        }
      }

      // PASSIVE: Miên (Mage) - Cộng Hưởng Hỏa Ngục
      if (attacker.id === 'mage' || weapon?.family === 'staff') {
        attacker.mp = Math.min(attEff.mp, attacker.mp + 1);
        target.burnTicks = 2;
        triggerEffect(attacker, target, 'fire', 0, false, '🔥 THIÊU ĐỐT!');
      }

      // PASSIVE: Kraken (Bạch Tuộc Vực Sâu) - Mực Mù Vực Sâu
      if (attacker.species === 'kraken') {
        target.blindTicks = 2;
        target.spd = Math.max(1, target.spd - 2);
        triggerEffect(attacker, target, 'tentacle', 0, false, '🐙 MỰC MÙ!');
      }

      // PASSIVE: Beholder (Mắt Quỷ Hư Vô) - Nhãn Lực Hư Vô
      if (attacker.species === 'beholder') {
        target.blindTicks = 2;
        target.weakenTicks = 2;
        triggerEffect(attacker, target, 'eye_ray', 0, false, '👁️ PHÂN RÃ!');
      }

      // PASSIVE: Banshee (Oán Linh Tiếng Hú) - Xuyên Giáp Hồn Ma
      if (attacker.species === 'banshee') {
        basePower = Math.round(basePower * 1.15);
        triggerEffect(attacker, target, 'wail', 0, false, '👻 XUYÊN GIÁP!');
      }

      // PASSIVE: Cerberus (Chó 3 Đầu) - 3 Hàm Răng Xé Xác
      if (attacker.species === 'cerberus') {
        basePower = Math.round(basePower * 1.2);
      }

      // PASSIVE: Mimic (Rương Giả) - Nhát Cắn Bất Ngờ
      if (attacker.species === 'mimic') {
        basePower = Math.round(basePower * 1.3);
      }

      const critMult = isCrit ? 1.55 : 1.0;
      let effectiveDef = attacker.species === 'banshee' ? Math.round(tarEff.def * 0.4) : tarEff.def;
      let rawDamage = Math.max(1, Math.round(basePower * critMult - effectiveDef - (target.guard || 0)));

      // PASSIVE: Đạt (Tank) hoặc người mang khiên lớn
      if (target.id === 'tank' || equipped[target.id]?.shield) {
        rawDamage = Math.max(1, Math.round(rawDamage * 0.78));
      }

      // PASSIVE: Đạt (Tank) đứng cạnh đồng đội -> Che chắn bớt 4 sát thương
      if (target.kind === 'hero' && target.id !== 'tank') {
        const tankAlly = units.find((u) => u.id === 'tank' && u.hp > 0 && manhattan(u, target) <= 1);
        if (tankAlly && rawDamage > 4) {
          rawDamage -= 4;
          tankAlly.hp = Math.max(0, tankAlly.hp - 3);
          triggerEffect(tankAlly, target, 'bash', 0, false, '🛡️ ĐẠT ĐỠ HỘ!');
        }
      }

      target.hp = Math.max(0, target.hp - rawDamage);
      target.guard = 0;

      // PASSIVE: Treant (Cổ Thụ) - Vỏ Gai Phản Đòn Cận Chiến
      if (target.species === 'treant' && target.hp > 0 && manhattan(attacker, target) <= 1) {
        attacker.hp = Math.max(0, attacker.hp - 3);
        triggerEffect(target, attacker, 'entangle', 3, false, '🌲 GAI CỔ THỤ!');
        addLog(`🌲 Gai nhọn của <b>${target.name}</b> phản lại 3 sát thương lên ${attacker.name}!`, 'enemy');
      }

      // PASSIVE: Cerberus HP < 50% activates Cuồng Nộ
      if (target.species === 'cerberus' && target.hp > 0 && target.hp < tarEff.hp * 0.5 && !target.rageMode) {
        target.rageMode = true;
        sound.playBossRoar();
        triggerEffect(target, target, 'fire', 0, false, '⚡ CUỒNG NỘ!');
        addLog(`🐺 <b>${target.name}</b> rơi vào trạng thái <b>CUỒNG NỘ</b> (+4 ATK, +2 SPD)!`, 'enemy');
      }

      // PASSIVE: MinoChoco (Boss) - Độc Xà Thượng Cổ phản độc cận chiến
      if (target.species === 'snake' && target.hp > 0 && manhattan(attacker, target) <= 1) {
        const poisonReflect = 3;
        attacker.hp = Math.max(0, attacker.hp - poisonReflect);
        triggerEffect(target, attacker, 'bite', poisonReflect, false, '🐉 PHẢN ĐỘC!');
        addLog(`🐉 Vảy độc của <b>MinoChoco</b> phản lại ${poisonReflect} sát thương lên ${attacker.name}!`, 'enemy');
      }

      // Sound & Dynamic Visual FX based on Weapon / Monster
      if (attacker.kind === 'hero') {
        if (weapon?.family === 'bow' || weapon?.family === 'crossbow') {
          sound.playArrow();
          triggerEffect(attacker, target, 'arrow', rawDamage, isCrit);
        } else if (weapon?.family === 'staff' || weapon?.family === 'tome') {
          sound.playMagic();
          triggerEffect(attacker, target, 'fire', rawDamage, isCrit);
        } else if (weapon?.family === 'bell') {
          sound.playHeal();
          triggerEffect(attacker, target, 'spell', rawDamage, isCrit);
        } else if (weapon?.family === 'hammer' || weapon?.family === 'axe') {
          sound.playShieldBash();
          triggerEffect(attacker, target, 'bash', rawDamage, isCrit);
        } else {
          sound.playSlash();
          triggerEffect(attacker, target, 'strike', rawDamage, isCrit);
        }
      } else {
        // Monster attacks
        if (attacker.species === 'kraken') {
          sound.playShieldBash();
          triggerEffect(attacker, target, 'tentacle', rawDamage, isCrit);
        } else if (attacker.species === 'beholder') {
          sound.playMagic();
          triggerEffect(attacker, target, 'eye_ray', rawDamage, isCrit);
        } else if (attacker.species === 'treant') {
          sound.playShieldBash();
          triggerEffect(attacker, target, 'entangle', rawDamage, isCrit);
        } else if (attacker.species === 'banshee') {
          sound.playMagic();
          triggerEffect(attacker, target, 'wail', rawDamage, isCrit);
        } else if (attacker.species === 'cerberus') {
          sound.playSlash();
          triggerEffect(attacker, target, 'claw3', rawDamage, isCrit);
        } else if (attacker.species === 'bird') {
          sound.playArrow();
          triggerEffect(attacker, target, 'feather', rawDamage, isCrit);
        } else if (attacker.species === 'ash-archer') {
          sound.playArrow();
          triggerEffect(attacker, target, 'arrow', rawDamage, isCrit);
        } else if (attacker.species === 'mimic') {
          sound.playSlash();
          triggerEffect(attacker, target, 'bite', rawDamage, isCrit);
        } else if (attacker.id === 'tank') {
          sound.playShieldBash();
          triggerEffect(attacker, target, 'bash', rawDamage, isCrit);
        } else {
          sound.playSlash();
          triggerEffect(attacker, target, 'strike', rawDamage, isCrit);
        }
      }

      if (isCrit) {
        shakeScreen(7);
      }

      addLog(
        `<b>${attacker.name}</b> tấn công <b>${target.name}</b>, gây <b>${rawDamage}</b> sát thương${
          isCrit ? ' (BẠO KÍCH!)' : ''
        }${target.hp === 0 ? ' · [GỤC NGÃ]' : ''}.`,
        attacker.kind === 'hero' ? 'good' : 'enemy'
      );

      if (target.hp === 0) {
        if (target.kind === 'enemy') {
          dropLoot(target);
          awardExp(attacker);
        }
      }

      attacker.acted = true;
    },
    [gainWeaponMastery, getEffectiveStats, triggerEffect, addLog, dropLoot, awardExp, units]
  );

  // End a unit's turn and advance
  const finishTurn = useCallback(
    (unit: Unit) => {
      unit.acted = true;
      setMoveTiles([]);
      setTargetTiles([]);
      setTargetingAction(null);

      // Check battle end
      const livingHeroes = units.filter((u) => u.kind === 'hero' && u.hp > 0);
      const livingEnemies = units.filter((u) => u.kind === 'enemy' && u.hp > 0);

      if (livingEnemies.length === 0) {
        // All enemies cleared! Start exit sequence
        setPhase('exiting');
        setActiveId(null);
        addLog(
          'Tất cả quái vật đã bị tiêu diệt! Đội hình đang rút lui qua cửa để lên tầng tiếp theo.',
          'good'
        );
        return;
      }

      if (livingHeroes.length === 0) {
        setPhase('lost');
        setGameOverResult('lost');
        sound.playTrap();
        addLog('Đội hình đã thất thủ hoàn toàn! Thử lại căn phòng này.', 'enemy');
        return;
      }

      // Next turn
      setTurnIndex((prev) => prev + 1);
    },
    [units, addLog]
  );

  // Hero AI turn (in auto mode)
  const runHeroAiTurn = useCallback(
    (hero: Unit) => {
      if (hero.hp <= 0 || hero.acted || phase !== 'playing' || paused) return;

      // Poison tick
      if (hero.poisonTicks && hero.poisonTicks > 0) {
        hero.poisonTicks -= 1;
        hero.hp = Math.max(0, hero.hp - 2);
        addLog(`<b>${hero.name}</b> bị trúng độc, mất 2 HP.`, 'enemy');
        if (hero.hp <= 0) {
          finishTurn(hero);
          return;
        }
      }

      const eff = getEffectiveStats(hero);
      const livingEnemies = units.filter((u) => u.kind === 'enemy' && u.hp > 0);
      if (livingEnemies.length === 0) {
        finishTurn(hero);
        return;
      }

      const weapon = equipped[hero.id]?.weapon;

      // 1. Healing Support (Bell or Cleric)
      if ((weapon?.family === 'bell' || (!weapon && hero.id === 'cleric')) && hero.mp >= 4) {
        const woundedAlly = units
          .filter((u) => u.kind === 'hero' && u.hp > 0 && u.hp < getEffectiveStats(u).hp - 5)
          .sort((a, b) => a.hp / getEffectiveStats(a).hp - b.hp / getEffectiveStats(b).hp)[0];

        if (woundedAlly) {
          hero.mp -= 4;
          const healAmount = Math.min(
            15 + eff.matk,
            getEffectiveStats(woundedAlly).hp - woundedAlly.hp
          );
          woundedAlly.hp += healAmount;
          sound.playHeal();
          triggerEffect(hero, woundedAlly, 'heal', -healAmount);
          addLog(
            `<b>${hero.name}</b> thi triển <b>Ánh Bình Minh</b>, hồi phục <b>+${healAmount} HP</b> cho ${woundedAlly.name}!`,
            'good'
          );
          finishTurn(hero);
          return;
        }
      }

      // 2. Escape Boss Danger Zone if standing in telegraph
      const inDanger = bossTelegraph.some((t) => t.x === hero.x && t.y === hero.y);
      if (inDanger) {
        const reachable = getReachableTiles(hero, eff.move, walls, terrainMap, units);
        const safeTile = reachable.find(
          (tile) => !bossTelegraph.some((t) => t.x === tile.x && t.y === tile.y)
        );

        if (safeTile) {
          moveUnit(hero, safeTile.x, safeTile.y);
          addLog(`<b>${hero.name}</b> đã nhanh chóng né khỏi vùng nguy hiểm của Boss!`, 'good');
          finishTurn(hero);
          return;
        } else {
          hero.guard = 4;
          addLog(`<b>${hero.name}</b> không kịp né, dựng thế thủ giảm sát thương.`, 'good');
          finishTurn(hero);
          return;
        }
      }

      // 3. Attack target currently in range
      const inRangeTargets = livingEnemies.filter(
        (e) => manhattan(hero, e) <= eff.range && clearShot(hero, e, walls, terrainMap)
      );

      if (inRangeTargets.length > 0) {
        const target = inRangeTargets.sort((a, b) => a.hp - b.hp)[0];

        // Magic Staff / Tome Skill (Hỏa Ngục / Sấm Sét)
        if ((weapon?.family === 'staff' || weapon?.family === 'tome' || (!weapon && hero.id === 'mage')) && hero.mp >= 4) {
          hero.mp -= 4;
          const spellDmg = Math.max(4, Math.round(eff.matk * 1.55 - target.def));
          target.hp = Math.max(0, target.hp - spellDmg);
          target.burnTicks = 2;
          sound.playMagic();
          shakeScreen(6);
          triggerEffect(hero, target, 'fire', spellDmg, true, '🔥 HỎA NGỤC!');
          addLog(
            `<b>${hero.name}</b> phóng <b>Hỏa Ngục Bộc Phá</b>, thiêu rụi ${target.name} với <b>${spellDmg}</b> sát thương!`,
            'skill'
          );
          if (target.hp === 0) {
            dropLoot(target);
            awardExp(hero);
          }
          finishTurn(hero);
          return;
        }

        // Bow / Crossbow Sniper Skill
        if ((weapon?.family === 'bow' || weapon?.family === 'crossbow') && hero.mp >= 3 && manhattan(hero, target) >= 2) {
          hero.mp -= 3;
          const shotDmg = Math.max(4, Math.round(eff.atk * 1.45 - target.def));
          target.hp = Math.max(0, target.hp - shotDmg);
          sound.playArrow();
          shakeScreen(5);
          triggerEffect(hero, target, 'arrow', shotDmg, true, '🎯 TIỄN XUYÊN TÂM!');
          addLog(
            `<b>${hero.name}</b> kích hoạt <b>Tiễn Xuyên Tâm</b>, bắn thủng ${target.name} gây <b>${shotDmg}</b> sát thương!`,
            'skill'
          );
          if (target.hp === 0) {
            dropLoot(target);
            awardExp(hero);
          }
          finishTurn(hero);
          return;
        }

        // Hammer / Axe Stun Smash Skill
        if ((weapon?.family === 'hammer' || weapon?.family === 'axe') && hero.mp >= 3) {
          hero.mp -= 3;
          const smashDmg = Math.max(4, Math.round(eff.atk * 1.35 - target.def));
          target.hp = Math.max(0, target.hp - smashDmg);
          target.stun = 1;
          sound.playShieldBash();
          shakeScreen(7);
          triggerEffect(hero, target, 'bash', smashDmg, true, '🔨 CHẤN ĐỊA!');
          addLog(
            `<b>${hero.name}</b> vung búa <b>Chấn Địa Trảm</b> gây <b>${smashDmg}</b> sát thương và làm choáng ${target.name}!`,
            'skill'
          );
          if (target.hp === 0) {
            dropLoot(target);
            awardExp(hero);
          }
          finishTurn(hero);
          return;
        }

        // Normal Attack
        executeAttack(hero, target);
        finishTurn(hero);
        return;
      }

      // 4. Move closer towards enemies
      const targetEnemy = livingEnemies.sort((a, b) => manhattan(hero, a) - manhattan(hero, b))[0];
      if (targetEnemy) {
        const path = findPathToAttackRange(hero, targetEnemy, eff.range, walls, terrainMap, units);
        if (path?.step) {
          moveUnit(hero, path.step.x, path.step.y);

          // Check if now in range after moving
          if (
            manhattan(hero, targetEnemy) <= eff.range &&
            clearShot(hero, targetEnemy, walls, terrainMap)
          ) {
            executeAttack(hero, targetEnemy);
            finishTurn(hero);
            return;
          }
        }
      }

      finishTurn(hero);
    },
    [
      phase,
      paused,
      getEffectiveStats,
      units,
      bossTelegraph,
      walls,
      terrainMap,
      moveUnit,
      executeAttack,
      finishTurn,
      triggerEffect,
      addLog,
      dropLoot,
      awardExp,
    ]
  );

  // MinoChoco Boss Special AI Turn
  const runMinochocoBossTurn = useCallback(
    (boss: Unit) => {
      // Execute pending telegraphed skill
      if (boss.pendingBossSkill) {
        const skill = boss.pendingBossSkill;
        const warned = [...bossTelegraph];
        boss.pendingBossSkill = null;
        setBossTelegraph([]);

        const livingHeroes = units.filter((u) => u.kind === 'hero' && u.hp > 0);

        if (skill.type === 'slap') {
          sound.playBossRoar();
          shakeScreen(10);
          const hitHeroes = livingHeroes.filter((h) =>
            warned.some((w) => w.x === h.x && w.y === h.y)
          );
          hitHeroes.forEach((h) => {
            const dmg = Math.max(3, Math.round(boss.atk * 1.2 - getEffectiveStats(h).def * 0.7));
            h.hp = Math.max(0, h.hp - dmg);
            triggerEffect(boss, h, 'enemy', dmg, true);
          });
          addLog(
            `🐉 <b>MinoChoco</b> quất đuôi vả vòng quanh, trúng <b>${hitHeroes.length}</b> đồng đội!`,
            'enemy'
          );
        } else if (skill.type === 'roar') {
          sound.playBossRoar();
          shakeScreen(7);
          livingHeroes.forEach((h) => {
            h.weakenTicks = Math.max(h.weakenTicks || 0, 2);
            triggerEffect(boss, h, 'spell', 0);
          });
          addLog(
            '🐉 <b>MinoChoco</b> gầm vang kinh thiên động địa! Toàn đội bị giảm 2 ATK/MATK trong 2 vòng!',
            'enemy'
          );
        } else if (skill.type === 'bite') {
          const target = units.find((u) => u.id === skill.targetId);
          if (target && target.hp > 0 && manhattan(boss, target) <= 1) {
            sound.playBossRoar();
            shakeScreen(8);
            const dmg = Math.max(4, Math.round(boss.atk * 1.4 - getEffectiveStats(target).def));
            target.hp = Math.max(0, target.hp - dmg);
            target.poisonTicks = 3;
            triggerEffect(boss, target, 'bite', dmg, true);
            addLog(
              `🐉 <b>MinoChoco</b> ngoạm cắn <b>${target.name}</b>, gây <b>${dmg}</b> sát thương và đầu độc 3 lượt!`,
              'enemy'
            );
          } else {
            addLog('🐉 MinoChoco cắn trượt vì mục tiêu đã kịp lùi lại!', 'good');
          }
        }

        finishTurn(boss);
        return;
      }

      // Telegraph next attack
      const livingHeroes = units.filter((u) => u.kind === 'hero' && u.hp > 0);
      if (livingHeroes.length === 0) {
        finishTurn(boss);
        return;
      }

      const cycle = ['slap', 'roar', 'bite'] as const;
      const nextType = cycle[(boss.bossCycle || 0) % cycle.length];
      boss.bossCycle = ((boss.bossCycle || 0) + 1) % cycle.length;

      if (nextType === 'slap') {
        const warned: BossTelegraph[] = [];
        livingHeroes.forEach((h) => {
          if (manhattan(boss, h) <= 1) warned.push({ x: h.x, y: h.y, type: 'slap' });
        });
        if (warned.length === 0) warned.push({ x: boss.x, y: boss.y, type: 'slap' });
        setBossTelegraph(warned);
        boss.pendingBossSkill = { type: 'slap' };
        addLog(
          '⚠️ <b>MinoChoco</b> cuộn mình tụ lực chuẩn bị <b>VẢ VÒNG QUANH</b>! Hãy nhanh chóng di tản khỏi ô màu đỏ!',
          'enemy'
        );
      } else if (nextType === 'roar') {
        const warned: BossTelegraph[] = livingHeroes.map((h) => ({ x: h.x, y: h.y, type: 'roar' }));
        setBossTelegraph(warned);
        boss.pendingBossSkill = { type: 'roar' };
        addLog('⚠️ <b>MinoChoco</b> hít sâu chuẩn bị <b>TIẾNG GẦM SUY NHƯỢC</b>!', 'enemy');
      } else {
        const nearest = livingHeroes.sort((a, b) => manhattan(boss, a) - manhattan(boss, b))[0];
        setBossTelegraph([{ x: nearest.x, y: nearest.y, type: 'bite' }]);
        boss.pendingBossSkill = { type: 'bite', targetId: nearest.id };
        addLog(`⚠️ <b>MinoChoco</b> khóa chặt ${nearest.name}, chuẩn bị <b>CẮN ĐỘC</b>!`, 'enemy');
      }

      finishTurn(boss);
    },
    [bossTelegraph, units, getEffectiveStats, triggerEffect, addLog, finishTurn]
  );

  // Normal Enemy AI turn
  const runEnemyTurn = useCallback(
    (enemy: Unit) => {
      if (enemy.hp <= 0 || enemy.acted || phase !== 'playing' || paused) return;

      // Handle Stun
      if (enemy.stun && enemy.stun > 0) {
        enemy.stun -= 1;
        addLog(`<b>${enemy.name}</b> bị choáng, mất lượt này!`, 'good');
        finishTurn(enemy);
        return;
      }

      // Boss special routing
      if (enemy.species === 'snake') {
        runMinochocoBossTurn(enemy);
        return;
      }

      const livingHeroes = units.filter((u) => u.kind === 'hero' && u.hp > 0);
      if (livingHeroes.length === 0) {
        finishTurn(enemy);
        return;
      }

      const eff = getEffectiveStats(enemy);

      // Slime regeneration
      if (enemy.ability === 'split' && enemy.hp < enemy.maxHp * 0.5 && (!enemy.cooldown || enemy.cooldown <= 0)) {
        const heal = Math.round(enemy.maxHp * 0.25);
        enemy.hp = Math.min(enemy.maxHp, enemy.hp + heal);
        enemy.cooldown = 3;
        triggerEffect(enemy, enemy, 'heal', -heal);
        addLog(`<b>${enemy.name}</b> phân bào tái kết tụ, hồi phục +${heal} HP!`, 'enemy');
        finishTurn(enemy);
        return;
      }

      // Check attack range
      let target = livingHeroes.find(
        (h) => manhattan(enemy, h) <= eff.range && clearShot(enemy, h, walls, terrainMap)
      );

      // If not in range, move closer
      if (!target) {
        const targetHero = livingHeroes.sort((a, b) => manhattan(enemy, a) - manhattan(enemy, b))[0];
        const path = findPathToAttackRange(enemy, targetHero, eff.range, walls, terrainMap, units);
        if (path?.step) {
          moveUnit(enemy, path.step.x, path.step.y);
          if (
            manhattan(enemy, targetHero) <= eff.range &&
            clearShot(enemy, targetHero, walls, terrainMap)
          ) {
            target = targetHero;
          }
        }
      }

      // Execute attack or active skill if target found
      if (target) {
        if (enemy.species === 'banshee') {
          sound.playMagic();
          shakeScreen(6);
          const nearHeroes = livingHeroes.filter((h) => manhattan(enemy, h) <= 2);
          nearHeroes.forEach((h) => {
            const wailDmg = Math.max(3, Math.round(eff.matk * 0.95 - getEffectiveStats(h).def * 0.3));
            h.hp = Math.max(0, h.hp - wailDmg);
            h.mp = Math.max(0, h.mp - 2);
            triggerEffect(enemy, h, 'wail', wailDmg, false, '👻 TIẾNG HÚ!');
          });
          addLog(`👻 <b>${enemy.name}</b> thét lên <b>Tiếng Hú Oán Linh</b>, hút MP và sát thương ${nearHeroes.length} mục tiêu!`, 'enemy');
          finishTurn(enemy);
          return;
        }

        if (enemy.species === 'beholder') {
          sound.playMagic();
          shakeScreen(6);
          const rayDmg = Math.max(4, Math.round(eff.matk * 1.35 - getEffectiveStats(target).def * 0.5));
          target.hp = Math.max(0, target.hp - rayDmg);
          target.blindTicks = 2;
          target.weakenTicks = 2;
          triggerEffect(enemy, target, 'eye_ray', rayDmg, true, '👁️ TIA PHÂN RÃ!');
          addLog(`👁️ <b>${enemy.name}</b> bắn <b>Tia Phân Rã Hư Vô</b>, gây <b>${rayDmg}</b> sát thương và làm mù ${target.name}!`, 'enemy');
          finishTurn(enemy);
          return;
        }

        if (enemy.species === 'treant') {
          sound.playShieldBash();
          const rootDmg = Math.max(3, Math.round(eff.atk * 1.1 - getEffectiveStats(target).def));
          target.hp = Math.max(0, target.hp - rootDmg);
          target.stun = 1;
          triggerEffect(enemy, target, 'entangle', rootDmg, false, '🌲 TRÓI BUỘC!');
          addLog(`🌲 <b>${enemy.name}</b> dùng <b>Rễ Gai Trói Buộc</b> gây ${rootDmg} sát thương và trói chân ${target.name}!`, 'enemy');
          finishTurn(enemy);
          return;
        }

        if (enemy.species === 'kraken') {
          sound.playShieldBash();
          const tentDmg = Math.max(4, Math.round(eff.atk * 1.25 - getEffectiveStats(target).def));
          target.hp = Math.max(0, target.hp - tentDmg);
          target.blindTicks = 2;
          target.spd = Math.max(1, target.spd - 2);
          triggerEffect(enemy, target, 'tentacle', tentDmg, true, '🐙 XÚC TU VỰC SÂU!');
          addLog(`🐙 <b>${enemy.name}</b> quất xúc tu khổng lồ phun mực mù lên ${target.name}!`, 'enemy');
          finishTurn(enemy);
          return;
        }

        executeAttack(enemy, target);
      }

      finishTurn(enemy);
    },
    [
      phase,
      paused,
      units,
      getEffectiveStats,
      walls,
      terrainMap,
      runMinochocoBossTurn,
      moveUnit,
      executeAttack,
      finishTurn,
      triggerEffect,
      addLog,
    ]
  );

  // Turn orchestration scheduler
  useEffect(() => {
    if (phase !== 'playing' || paused) return;

    const aliveUnits = units.filter((u) => u.hp > 0);
    const livingHeroes = aliveUnits.filter((u) => u.kind === 'hero');
    const livingEnemies = aliveUnits.filter((u) => u.kind === 'enemy');

    if (livingEnemies.length === 0) {
      setPhase('exiting');
      setActiveId(null);
      addLog(
        'Tất cả quái vật đã bị tiêu diệt! Đội hình đang rút lui qua cửa để lên tầng tiếp theo.',
        'good'
      );
      return;
    }

    if (livingHeroes.length === 0) {
      setPhase('lost');
      setGameOverResult('lost');
      return;
    }

    // New round if order exhausted
    if (turnIndex >= order.length) {
      setRound((prev) => prev + 1);
      const newOrder = [...aliveUnits].sort((a, b) => {
        const spdDiff = getEffectiveStats(b).spd - getEffectiveStats(a).spd;
        if (spdDiff !== 0) return spdDiff;
        return a.kind === 'hero' ? -1 : 1;
      });
      newOrder.forEach((u) => {
        u.acted = false;
        u.moved = false;
        u.guard = 0;
        if (u.weakenTicks && u.weakenTicks > 0) u.weakenTicks -= 1;
        if (u.blindTicks && u.blindTicks > 0) u.blindTicks -= 1;
        if (u.burnTicks && u.burnTicks > 0) {
          u.burnTicks -= 1;
          u.hp = Math.max(0, u.hp - 3);
          triggerEffect(u, u, 'fire', 3, false, '🔥 BỎNG LỬA!');
        }
      });

      // PASSIVE: An (Cleric) - Hào Quang Ban Phước hồi máu đầu vòng
      const cleric = newOrder.find((u) => u.id === 'cleric' && u.hp > 0);
      if (cleric) {
        const lowestHero = newOrder
          .filter((u) => u.kind === 'hero' && u.hp > 0 && u.hp < getEffectiveStats(u).hp)
          .sort((a, b) => a.hp / getEffectiveStats(a).hp - b.hp / getEffectiveStats(b).hp)[0];
        if (lowestHero) {
          const healAmt = 4;
          lowestHero.hp = Math.min(getEffectiveStats(lowestHero).hp, lowestHero.hp + healAmt);
          sound.playHeal();
          triggerEffect(cleric, lowestHero, 'heal', -healAmt, false, '✨ BAN PHƯỚC!');
          addLog(`✨ <b>Hào Quang Ban Phước</b> của Tu Sĩ hồi +${healAmt} HP cho ${lowestHero.name}.`, 'good');
        }
      }

      setOrder(newOrder);
      setTurnIndex(0);
      return;
    }

    const currentUnit = order[turnIndex];
    if (!currentUnit || currentUnit.hp <= 0 || currentUnit.acted) {
      setTurnIndex((prev) => prev + 1);
      return;
    }

    setActiveId(currentUnit.id);
    currentUnit.moved = false;
    currentUnit.guard = 0;

    const delay = (currentUnit.kind === 'enemy' ? 420 : 480) / PLAYBACK_SPEEDS[speedIndex];
    const gen = roomGenRef.current;

    const timer = setTimeout(() => {
      if (gen !== roomGenRef.current || paused || phase !== 'playing') return;

      if (currentUnit.kind === 'enemy') {
        runEnemyTurn(currentUnit);
      } else {
        if (controlMode === 'auto') {
          runHeroAiTurn(currentUnit);
        } else {
          // Manual mode: Highlight movement tiles and wait for player interaction
          setSelectedId(currentUnit.id);
          setSelectedHeroId(currentUnit.id);
          const reach = getReachableTiles(
            currentUnit,
            getEffectiveStats(currentUnit).move,
            walls,
            terrainMap,
            units
          );
          setMoveTiles(reach);
          setTargetTiles([]);
        }
      }
    }, delay);

    return () => clearTimeout(timer);
  }, [
    phase,
    paused,
    turnIndex,
    order,
    units,
    speedIndex,
    controlMode,
    getEffectiveStats,
    runEnemyTurn,
    runHeroAiTurn,
    walls,
    terrainMap,
    addLog,
  ]);

  // Exiting corridor sequence (auto walks heroes out the door)
  useEffect(() => {
    if (phase !== 'exiting' || paused) return;

    const heroesToExit = units.filter((u) => u.kind === 'hero' && u.hp > 0 && !u.inTransit);
    if (heroesToExit.length === 0) {
      // All heroes have exited successfully!
      sound.playLevelUp();
      setPhase('won');
      setGameOverResult('won');
      saveGame();
      return;
    }

    const cur = heroesToExit[0];
    const gen = roomGenRef.current;
    const delay = 280 / PLAYBACK_SPEEDS[speedIndex];

    const timer = setTimeout(() => {
      if (gen !== roomGenRef.current || paused || phase !== 'exiting') return;

      if (cur.x === EXIT_DOOR.x && cur.y === EXIT_DOOR.y) {
        cur.inTransit = true;
        addLog(`<b>${cur.name}</b> đã bước qua cánh cổng thần kỳ!`, 'good');
        setUnits([...units]);
        return;
      }

      const step = findShortestStep(cur, EXIT_DOOR, walls, terrainMap, units);
      if (step) {
        moveUnit(cur, step.x, step.y);
        if (cur.x === EXIT_DOOR.x && cur.y === EXIT_DOOR.y) {
          cur.inTransit = true;
          addLog(`<b>${cur.name}</b> đã bước qua cánh cổng thần kỳ!`, 'good');
        }
        setUnits([...units]);
      } else {
        // If exact step cannot be found, mark inTransit
        cur.inTransit = true;
        setUnits([...units]);
      }
    }, delay);

    return () => clearTimeout(timer);
  }, [phase, paused, units, speedIndex, walls, terrainMap, moveUnit, addLog, saveGame]);

  // Global Keyboard Shortcuts for Web PC Browsers
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Don't capture when typing in inputs/selects
      const activeTag = (document.activeElement as HTMLElement)?.tagName;
      if (activeTag === 'INPUT' || activeTag === 'SELECT' || activeTag === 'TEXTAREA') return;

      if (e.code === 'Space') {
        e.preventDefault();
        sound.playClick();
        if (phase === 'ready') {
          startCombat();
        } else if (phase === 'playing') {
          setPaused((p) => !p);
        }
      } else if (e.key === '1') {
        setSpeedIndex(0);
      } else if (e.key === '2') {
        setSpeedIndex(1);
      } else if (e.key === '3') {
        setSpeedIndex(2);
      } else if (e.key.toLowerCase() === 'm') {
        const nextMuted = sound.toggleMute();
        setIsMuted(nextMuted);
      } else if (e.key.toLowerCase() === 'a') {
        setControlMode((m) => (m === 'auto' ? 'manual' : 'auto'));
      } else if (e.key.toLowerCase() === 'i' || e.key.toLowerCase() === 'b') {
        setInventoryModalOpen((v) => !v);
      } else if (e.key.toLowerCase() === 't') {
        setTeamModalOpen((v) => !v);
      } else if (e.key.toLowerCase() === 's') {
        setShopModalOpen((v) => !v);
      } else if (e.key === 'Escape') {
        setTeamModalOpen(false);
        setInventoryModalOpen(false);
        setShopModalOpen(false);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [phase, startCombat]);

  // Handle Board Tile Click (Manual control & inspection)
  const handleTileClick = (x: number, y: number) => {
    sound.playClick();
    const clickedUnit = units.find((u) => u.hp > 0 && u.x === x && u.y === y);

    if (clickedUnit) {
      setSelectedId(clickedUnit.id);
      if (clickedUnit.kind === 'hero') {
        setSelectedHeroId(clickedUnit.id);
      }
    }

    if (controlMode !== 'manual' || phase !== 'playing' || !activeId) return;

    const curActive = units.find((u) => u.id === activeId);
    if (!curActive || curActive.kind !== 'hero' || curActive.acted) return;

    // 1. Move to clicked reachable tile
    if (!curActive.moved && moveTiles.some((t) => t.x === x && t.y === y)) {
      moveUnit(curActive, x, y);
      setMoveTiles([]);
      // Highlight targets after move
      const targets = units.filter(
        (u) =>
          u.kind === 'enemy' &&
          u.hp > 0 &&
          manhattan(curActive, u) <= getEffectiveStats(curActive).range &&
          clearShot(curActive, u, walls, terrainMap)
      );
      setTargetTiles(targets.map((t) => ({ x: t.x, y: t.y })));
      setTargetingAction('attack');
      addLog(`<b>${curActive.name}</b> di chuyển đến (${x + 1}, ${y + 1}).`);
      return;
    }

    // 2. Attack clicked target
    if (targetingAction === 'attack' && clickedUnit && clickedUnit.kind === 'enemy') {
      if (targetTiles.some((t) => t.x === x && t.y === y)) {
        executeAttack(curActive, clickedUnit);
        finishTurn(curActive);
      }
    }
  };

  // Manual Attack button clicked
  const handleManualAttack = () => {
    const curActive = units.find((u) => u.id === activeId);
    if (!curActive || curActive.kind !== 'hero' || curActive.acted) return;

    const targets = units.filter(
      (u) =>
        u.kind === 'enemy' &&
        u.hp > 0 &&
        manhattan(curActive, u) <= getEffectiveStats(curActive).range &&
        clearShot(curActive, u, walls, terrainMap)
    );
    setTargetTiles(targets.map((t) => ({ x: t.x, y: t.y })));
    setTargetingAction('attack');
    addLog(`Chọn mục tiêu trong tầm đánh của <b>${curActive.name}</b>.`, 'normal');
  };

  // Manual Skill button clicked (Freeform Weapon Skills)
  const handleManualSkill = () => {
    const curActive = units.find((u) => u.id === activeId);
    if (!curActive || curActive.kind !== 'hero' || curActive.acted) return;

    const weapon = equipped[curActive.id]?.weapon;
    const eff = getEffectiveStats(curActive);

    // 1. Holy Bell Healing Skill
    if (weapon?.family === 'bell' || (!weapon && curActive.id === 'cleric')) {
      if (curActive.mp < 4) {
        addLog(`${curActive.name} không đủ MP để dùng Ánh Bình Minh (cần 4 MP).`, 'normal');
        return;
      }
      const wounded = units
        .filter((u) => u.kind === 'hero' && u.hp > 0)
        .sort((a, b) => a.hp / a.maxHp - b.hp / b.maxHp)[0];
      if (wounded) {
        curActive.mp -= 4;
        const healAmt = Math.min(16 + eff.matk, wounded.maxHp - wounded.hp);
        wounded.hp += healAmt;
        sound.playHeal();
        triggerEffect(curActive, wounded, 'heal', -healAmt, false, '✨ HỒI PHỤC!');
        addLog(
          `<b>${curActive.name}</b> dùng <b>Ánh Bình Minh</b>, hồi +${healAmt} HP cho ${wounded.name}!`,
          'good'
        );
        finishTurn(curActive);
        return;
      }
    }

    // 2. Arcane Staff / Tome Spell Skill
    if (weapon?.family === 'staff' || weapon?.family === 'tome' || (!weapon && curActive.id === 'mage')) {
      if (curActive.mp < 4) {
        addLog(`${curActive.name} không đủ MP để dùng Hỏa Ngục (cần 4 MP).`, 'normal');
        return;
      }
      const enemy = units.filter((u) => u.kind === 'enemy' && u.hp > 0)[0];
      if (enemy) {
        curActive.mp -= 4;
        const dmg = Math.max(4, Math.round(eff.matk * 1.55 - enemy.def));
        enemy.hp = Math.max(0, enemy.hp - dmg);
        enemy.burnTicks = 2;
        sound.playMagic();
        shakeScreen(6);
        triggerEffect(curActive, enemy, 'fire', dmg, true, '🔥 HỎA NGỤC!');
        addLog(`<b>${curActive.name}</b> phóng <b>Hỏa Ngục Bộc Phá</b> thiêu ${enemy.name} với ${dmg} sát thương!`, 'skill');
        if (enemy.hp === 0) {
          dropLoot(enemy);
          awardExp(curActive);
        }
        finishTurn(curActive);
        return;
      }
    }

    // 3. Bow / Crossbow Sniper Skill
    if (weapon?.family === 'bow' || weapon?.family === 'crossbow') {
      if (curActive.mp < 3) {
        addLog(`${curActive.name} không đủ MP để dùng Tiễn Xuyên Tâm (cần 3 MP).`, 'normal');
        return;
      }
      const enemy = units.filter((u) => u.kind === 'enemy' && u.hp > 0)[0];
      if (enemy) {
        curActive.mp -= 3;
        const dmg = Math.max(4, Math.round(eff.atk * 1.45 - enemy.def));
        enemy.hp = Math.max(0, enemy.hp - dmg);
        sound.playArrow();
        shakeScreen(5);
        triggerEffect(curActive, enemy, 'arrow', dmg, true, '🎯 TIỄN XUYÊN TÂM!');
        addLog(`<b>${curActive.name}</b> giương cung bắn <b>Tiễn Xuyên Tâm</b> xuyên qua ${enemy.name} với ${dmg} sát thương!`, 'skill');
        if (enemy.hp === 0) {
          dropLoot(enemy);
          awardExp(curActive);
        }
        finishTurn(curActive);
        return;
      }
    }

    // 4. Hammer / Axe Stun Smash Skill
    if (weapon?.family === 'hammer' || weapon?.family === 'axe') {
      if (curActive.mp < 3) {
        addLog(`${curActive.name} không đủ MP để dùng Chấn Địa Trảm (cần 3 MP).`, 'normal');
        return;
      }
      const enemy = units.filter((u) => u.kind === 'enemy' && u.hp > 0)[0];
      if (enemy) {
        curActive.mp -= 3;
        const dmg = Math.max(4, Math.round(eff.atk * 1.35 - enemy.def));
        enemy.hp = Math.max(0, enemy.hp - dmg);
        enemy.stun = 1;
        sound.playShieldBash();
        shakeScreen(7);
        triggerEffect(curActive, enemy, 'bash', dmg, true, '🔨 CHẤN ĐỊA!');
        addLog(`<b>${curActive.name}</b> vung búa <b>Chấn Địa Trảm</b> gây ${dmg} sát thương và làm choáng ${enemy.name}!`, 'skill');
        if (enemy.hp === 0) {
          dropLoot(enemy);
          awardExp(curActive);
        }
        finishTurn(curActive);
        return;
      }
    }

    // 5. Sword / Dagger Slash Skill
    if (weapon?.family === 'sword' || weapon?.family === 'dagger') {
      if (curActive.mp < 3) {
        addLog(`${curActive.name} không đủ MP để dùng Bá Vương Kiếm Khí (cần 3 MP).`, 'normal');
        return;
      }
      const enemy = units.filter((u) => u.kind === 'enemy' && u.hp > 0)[0];
      if (enemy) {
        curActive.mp -= 3;
        const dmg = Math.max(4, Math.round(eff.atk * 1.5 - enemy.def));
        enemy.hp = Math.max(0, enemy.hp - dmg);
        sound.playSlash();
        shakeScreen(6);
        triggerEffect(curActive, enemy, 'strike', dmg, true, '✦ KIẾM KHÍ!');
        addLog(`<b>${curActive.name}</b> chém <b>Bá Vương Kiếm Khí</b> gây ${dmg} sát thương bộc phát lên ${enemy.name}!`, 'skill');
        if (enemy.hp === 0) {
          dropLoot(enemy);
          awardExp(curActive);
        }
        finishTurn(curActive);
        return;
      }
    }

    // Fallback normal attack
    handleManualAttack();
  };

  // Manual Defend button clicked
  const handleManualDefend = () => {
    const curActive = units.find((u) => u.id === activeId);
    if (!curActive || curActive.kind !== 'hero' || curActive.acted) return;

    curActive.guard = curActive.id === 'tank' ? 5 : 3;
    sound.playShieldBash();
    addLog(`<b>${curActive.name}</b> vào thế phòng ngự (+${curActive.guard} Giáp lượt này).`, 'good');
    finishTurn(curActive);
  };

  // Manual End Turn button clicked
  const handleManualEndTurn = () => {
    const curActive = units.find((u) => u.id === activeId);
    if (!curActive || curActive.kind !== 'hero' || curActive.acted) return;

    addLog(`<b>${curActive.name}</b> kết thúc lượt.`, 'normal');
    finishTurn(curActive);
  };

  // Advance to next floor after victory
  const handleNextFloor = () => {
    setGameOverResult(null);
    const nextF = floor + 1;
    setFloor(nextF);
    setShopStock(generateShopStock(nextF));

    // Potential companion recruit encounter
    const unrecruited = heroRoster.filter((h) => !partyIds.includes(h.id));
    if (partyIds.length < 5 && unrecruited.length > 0 && Math.random() < 0.45) {
      const candidate = unrecruited[Math.floor(Math.random() * unrecruited.length)];
      setRecruitCandidate(candidate);
    } else {
      setupFloor(nextF);
    }
  };

  // Recruit candidate companion
  const handleRecruitAccept = () => {
    if (recruitCandidate) {
      const newParty = [...partyIds, recruitCandidate.id];
      setPartyIds(newParty);
      addLog(`✨ <b>${recruitCandidate.name}</b> đã đồng hành cùng đội leo tháp!`, 'good');
      setRecruitCandidate(null);
      setupFloor(floor, newParty);
    }
  };

  const handleRecruitDecline = () => {
    setRecruitCandidate(null);
    setupFloor(floor);
  };

  // Equip item
  const handleEquipItem = (heroId: string, item: GearItem) => {
    sound.playClick();
    const curSlotItem = equipped[heroId]?.[item.slot];
    const newInventory = inventory.filter((i) => i.id !== item.id);
    if (curSlotItem) {
      newInventory.push(curSlotItem);
    }

    setInventory(newInventory);
    setEquipped((prev) => ({
      ...prev,
      [heroId]: {
        ...(prev[heroId] || {}),
        [item.slot]: item,
      },
    }));

    addLog(`Đã trang bị <b>${item.name}</b> cho ${CLASS_NAMES[heroId] || heroId}.`, 'good');
  };

  // Unequip item
  const handleUnequipItem = (heroId: string, slot: SlotType) => {
    sound.playClick();
    const curSlotItem = equipped[heroId]?.[slot];
    if (!curSlotItem) return;

    setInventory((prev) => [curSlotItem, ...prev]);
    setEquipped((prev) => {
      const updated = { ...(prev[heroId] || {}) };
      delete updated[slot];
      return { ...prev, [heroId]: updated };
    });
  };

  // Sell item
  const handleSellItem = (itemId: string) => {
    const item = inventory.find((i) => i.id === itemId);
    if (!item) return;

    sound.playGold();
    setGold((prev) => prev + item.sellPrice);
    setInventory((prev) => prev.filter((i) => i.id !== itemId));
    addLog(`Đã bán <b>${item.name}</b> nhận được +${item.sellPrice} ◈.`, 'item');
  };

  // Buy item from shop
  const handleBuyItem = (item: GearItem) => {
    const price = item.price || Math.round(item.sellPrice * 1.6);
    if (gold < price) return;

    sound.playGold();
    setGold((prev) => prev - price);
    setShopStock((prev) => prev.filter((i) => i.id !== item.id));
    setInventory((prev) => [item, ...prev]);
    addLog(`Đã mua <b>${item.icon} ${item.name}</b> từ cửa hàng.`, 'item');
  };

  // Current active unit helper
  const curActiveUnit = units.find((u) => u.id === activeId) || null;
  const currentPresetName = TERRAIN_PRESETS[(floor - 1) % TERRAIN_PRESETS.length]?.name || 'Hầm Tháp Cổ';

  // Render Title Screen if in title phase
  if (phase === 'title') {
    return (
      <TitleScreen
        hasSave={hasSave}
        saveFloor={saveFloor}
        onContinue={handleContinueSavedRun}
        onStartNewRun={handleStartNewRun}
      />
    );
  }

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans select-none">
      {/* Top Navigation Bar */}
      <header className="border-b border-slate-800 bg-slate-900/90 backdrop-blur sticky top-0 z-30 px-4 py-2.5 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <button
            onClick={() => {
              saveGame();
              setPhase('title');
            }}
            className="flex items-center gap-2 group text-left"
          >
            <div className="w-8 h-8 rounded-lg bg-emerald-500 text-slate-950 flex items-center justify-center font-cinzel font-black text-sm shadow group-hover:scale-105 transition-transform">
              TD
            </div>
            <div>
              <span className="text-[10px] font-mono uppercase tracking-widest text-emerald-400 block -mb-0.5">
                Tactical RPG
              </span>
              <h1 className="text-sm font-bold font-cinzel tracking-wide text-slate-100 group-hover:text-emerald-300 transition-colors">
                THÁP ĐỒNG HÀNH
              </h1>
            </div>
          </button>
        </div>

        {/* Floor and Meta status */}
        <div className="flex items-center gap-3 font-mono text-xs">
          <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-950 border border-slate-800">
            <Crown className="w-3.5 h-3.5 text-amber-400" />
            <span className="text-slate-400">TẦNG</span>
            <span className="font-bold text-slate-100">{String(floor).padStart(2, '0')}</span>
            {floorBoss && (
              <span className="ml-1 px-1.5 py-0.2 rounded text-[9px] bg-rose-950 text-rose-300 border border-rose-800 font-bold animate-pulse">
                BOSS
              </span>
            )}
          </div>

          <div className="hidden sm:flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-950 border border-slate-800 text-slate-400">
            <span>VÒNG</span>
            <span className="font-bold text-emerald-400">{String(round).padStart(2, '0')}</span>
          </div>

          {/* Quick tab shortcuts */}
          <button
            onClick={() => setTeamModalOpen(true)}
            className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-emerald-300 transition-colors flex items-center gap-1.5 text-xs font-mono"
            title="Quản lý trang bị đội"
          >
            <Shield className="w-3.5 h-3.5" />
            <span className="hidden md:inline">Đội & Giáp</span>
          </button>

          <button
            onClick={() => setShopModalOpen(true)}
            className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-amber-300 transition-colors flex items-center gap-1.5 text-xs font-mono"
            title="Cửa hàng tầng (Phím S)"
          >
            <Store className="w-3.5 h-3.5 text-amber-400" />
            <span className="hidden md:inline">Cửa Hàng</span>
          </button>

          <button
            onClick={toggleFullscreen}
            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-emerald-300 transition-colors text-xs font-mono"
            title={isFullscreen ? 'Thu nhỏ cửa sổ' : 'Toàn màn hình'}
          >
            {isFullscreen ? <Minimize className="w-3.5 h-3.5" /> : <Maximize className="w-3.5 h-3.5" />}
          </button>
        </div>
      </header>

      {/* Main Game Arena */}
      <main className="flex-1 max-w-[1520px] w-full mx-auto p-3 sm:p-4 grid grid-cols-1 lg:grid-cols-12 gap-4 items-start">
        {/* Left Column: Battle Arena & Combat Controls (8 cols on desktop) */}
        <div className="lg:col-span-8 flex flex-col gap-3">
          {/* Room Title & Objective */}
          <div className="flex items-center justify-between px-1">
            <div>
              <h2 className="text-sm sm:text-base font-bold text-slate-200 font-cinzel">
                Phòng Chiến Đấu · {currentPresetName}
              </h2>
              <p className="text-xs text-slate-400 font-mono">
                {phase === 'ready'
                  ? 'Đội hình đã sẵn sàng vào vị trí. Nhấn Bắt Đầu để khai chiến!'
                  : phase === 'exiting'
                  ? 'Quái đã bị dọn sạch. Cả đội đang di chuyển qua cửa để lên tầng tiếp theo.'
                  : paused
                  ? 'Trận đấu đang tạm dừng.'
                  : 'AI tự động tính toán bước đi tối ưu cho cả hai phe.'}
              </p>
            </div>

            <div className="flex items-center gap-2 font-mono text-[11px] text-slate-400">
              <span className="flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                <span className="text-slate-300">{phase === 'ready' ? 'SẴN SÀNG' : 'CHIẾN ĐẤU'}</span>
              </span>
            </div>
          </div>

          {/* Canvas Battlefield */}
          <BattleCanvas
            units={units}
            walls={walls}
            terrainMap={terrainMap}
            triggeredTraps={triggeredTraps}
            bossTelegraph={bossTelegraph}
            visualEffects={visualEffects}
            activeId={activeId}
            selectedId={selectedId}
            moveTiles={moveTiles}
            targetTiles={targetTiles}
            phase={phase}
            onTileClick={handleTileClick}
            getEffectiveStats={getEffectiveStats}
            screenShake={screenShake}
          />

          {/* Action Bar & Controls */}
          <ActionBar
            phase={phase}
            paused={paused}
            activeUnit={curActiveUnit}
            controlMode={controlMode}
            speed={PLAYBACK_SPEEDS[speedIndex]}
            isMuted={isMuted}
            onTogglePlay={() => {
              sound.playClick();
              if (phase === 'ready') {
                startCombat();
              } else {
                setPaused(!paused);
              }
            }}
            onToggleSpeed={() => {
              sound.playClick();
              setSpeedIndex((prev) => (prev + 1) % PLAYBACK_SPEEDS.length);
            }}
            onRestartRoom={() => {
              sound.playClick();
              setupFloor(floor);
            }}
            onToggleMute={() => {
              const muted = sound.toggleMute();
              setIsMuted(muted);
            }}
            onToggleControlMode={() => {
              sound.playClick();
              const nextMode = controlMode === 'auto' ? 'manual' : 'auto';
              setControlMode(nextMode);
              addLog(`Đã chuyển sang chế độ <b>${nextMode === 'auto' ? 'Tự Động' : 'Thủ Công'}</b>.`, 'normal');
            }}
            onManualAttack={handleManualAttack}
            onManualSkill={handleManualSkill}
            onManualDefend={handleManualDefend}
            onManualEndTurn={handleManualEndTurn}
            getEffectiveStats={getEffectiveStats}
          />

          {/* Combat Log Feed */}
          <CombatLog logs={logs} onClear={() => setLogs([])} />
        </div>

        {/* Right Column: Party Sidebar & Inspector (4 cols on desktop) */}
        <div className="lg:col-span-4 flex flex-col gap-3">
          <PartySidebar
            heroes={units.filter((u) => u.kind === 'hero')}
            selectedHeroId={selectedHeroId}
            activeId={activeId}
            equipped={equipped}
            gold={gold}
            inventoryCount={inventory.length}
            onSelectHero={(id) => {
              sound.playClick();
              setSelectedHeroId(id);
              setSelectedId(id);
            }}
            getEffectiveStats={getEffectiveStats}
            onOpenInventory={() => setInventoryModalOpen(true)}
            onOpenTeam={() => setTeamModalOpen(true)}
          />
        </div>
      </main>

      {/* MODALS */}
      {teamModalOpen && (
        <TeamManagerModal
          heroes={units.filter((u) => u.kind === 'hero')}
          equipped={equipped}
          inventory={inventory}
          gold={gold}
          onClose={() => setTeamModalOpen(false)}
          onEquip={handleEquipItem}
          onUnequip={handleUnequipItem}
          getEffectiveStats={getEffectiveStats}
        />
      )}

      {inventoryModalOpen && (
        <InventoryManagerModal
          inventory={inventory}
          heroes={units.filter((u) => u.kind === 'hero')}
          gold={gold}
          onClose={() => setInventoryModalOpen(false)}
          onSellItem={handleSellItem}
          onEquipItem={handleEquipItem}
        />
      )}

      {shopModalOpen && (
        <ShopModal
          stock={shopStock}
          gold={gold}
          floor={floor}
          onClose={() => setShopModalOpen(false)}
          onBuyItem={handleBuyItem}
        />
      )}

      {recruitCandidate && (
        <RecruitModal
          candidate={recruitCandidate}
          onAccept={handleRecruitAccept}
          onDecline={handleRecruitDecline}
        />
      )}

      {gameOverResult && (
        <GameOverModal
          isVictory={gameOverResult === 'won'}
          floor={floor}
          isBoss={floorBoss}
          lootFound={floorLootFound}
          goldEarned={floorGoldEarned}
          onContinue={handleNextFloor}
          onRetry={() => {
            setGameOverResult(null);
            setupFloor(floor);
          }}
        />
      )}
    </div>
  );
}
