# Hầm Ngục Chiến Thuật Đỉnh Cao: Đột Phá Chiều Sâu & Giá Trị Chơi Lại Vô Hạn

Kế hoạch nâng cấp toàn diện trải nghiệm trò chơi nhập vai chiến thuật theo lượt (Turn-based Tactical Dungeon Crawler) với các cơ chế chiến thuật cao cấp: **Đẩy lùi va tường gây Choáng (Knockback & Wall Slam)**, **Combo Nguyên tố**, **Thùng thuốc nổ môi trường (Explosive Barrels)**, lối chơi **Roguelike thuần kỹ năng**, khắc phục triệt để **lỗi tiêu hao MP** và hệ thống **hoạt ảnh chiến đấu Canvas mượt mà**.

---

### User Review & Critical Decisions

> [!IMPORTANT]
> Dưới đây là các quyết định thiết kế then chốt được người chơi lựa chọn nhằm biến tựa game thành một thử thách tư duy chiến thuật đỉnh cao, chơi đi chơi lại không chán:

- **1. Cơ chế Đẩy Lùi (Knockback) & Va Tường (Wall Slam Stun)**:
  - Khi Chiến binh dùng Khiên đẩy hoặc Xạ thủ bắn Tên chấn động, kẻ địch bị văng lùi 1-2 ô.
  - Nếu đường lùi bị chặn bởi Tường, Đá hoặc Quái khác $\rightarrow$ Kẻ địch nhận thêm sát thương va đập và bị **Choáng (Stun - Mất hoàn toàn lượt đi tiếp theo)**.
- **2. Thùng Thuốc Nổ Môi Trường (Explosive Barrels)**:
  - Trên bàn cờ xuất hiện các thùng thuốc nổ màu đỏ rực. Người chơi có thể bắn từ xa bằng cung tiễn, dùng cầu lửa kích nổ, hoặc khéo léo đẩy quái văng vào thùng.
  - Khi nổ, gây sát thương lan diện rộng 3x3 ô xung quanh và có thể kích nổ dây chuyền các thùng lân cận.
- **3. Hệ thống Combo Nguyên Tố (Elemental Synergies)**:
  - **Băng Giá (Freeze)**: Làm chậm hoặc đóng băng kẻ địch. Khi bị giáng đòn sấm sét hoặc búa tạ $\rightarrow$ Kích hoạt hiệu ứng Vỡ Vụn (Shatter - Gây gấp đôi sát thương chí mạng).
  - **Dầu / Hỏa Diễm (Ignite)**: Các đòn đánh lửa thiêu đốt mục tiêu và kích nổ các vệt cháy lan trên lưới.
- **4. Roguelike Thuần Kỹ Năng (Pure Tactical Permadeath)**:
  - Không giữ lại chỉ số cày cuốc sau khi thua cuộc. Mỗi ván đấu là một bảng cờ ngẫu nhiên công bằng, nơi người chơi giành chiến thắng nhờ vào sự sáng tạo trong việc phối hợp địa hình, combo và quản lý năng lượng.
- **5. Khắc phục triệt để lỗi MP & Hoạt ảnh chiến đấu**:
  - Khóa chặt đòn đánh kỹ năng khi MP < chi phí (vô hiệu hóa nút, kiểm tra logic hành động, phát âm thanh từ chối).
  - Hoạt ảnh lướt đòn (lunge) và giật nảy (stagger recoil) cùng nhấp nháy đỏ khi nhận sát thương được vẽ trực tiếp trên Canvas với tốc độ 250ms rõ nét, dễ theo dõi.
  - Hồi phục đầy đủ 100% MP cho cả đội khi bước qua Cổng Dịch Chuyển (Portal) sang tầng mới.

---

### 1. Overview & Core Concept

- **Mục tiêu cốt lõi**: Chuyển đổi từ một game đánh theo lượt đơn giản thành một đấu trường chiến thuật sống động (như *Into the Breach* kết hợp *Divinity: Original Sin*), nơi địa hình và môi trường là vũ khí mạnh nhất của người chơi.
- **Độ sâu chiến thuật nhiều lớp**:
  - *Lớp 1: Quản lý vị trí & Tầm nhìn*: Tận dụng góc khuất, bọc lót đội hình, tránh đứng cạnh quái vật khi dùng phép/bắn cung.
  - *Lớp 2: Kiểm soát cờ (Crowd Control)*: Dồn ép quái vật vào góc tường, đẩy ngã quái vật vào nhau gây choáng kép.
  - *Lớp 3: Tác động môi trường*: Bắn nổ thùng thuốc nổ để giải quyết đám đông quái tinh anh mà không tốn nhiều MP.

---

### 2. User Experience & Visual Design

#### A. Trải nghiệm luồng trận đấu trên bàn cờ chiến thuật
```
┌─────────────────────────────────────────────────────────────┐
│ 1. Quan sát thế trận:                                      │
│    - Quái vật thường, Tinh anh (Lich, Ghost, Shaman)        │
│    - Thùng thuốc nổ đỏ (Barrels) & Tường đá hiểm hóc        │
├─────────────────────────────────────────────────────────────┤
│ 2. Ra quyết định & Kích hoạt:                               │
│    - Pháp sư dùng Cầu Lửa bắn nổ Thùng Thuốc Nổ             │
│      -> Nổ tung 3x3 ô, thiêu rụi bầy quái                   │
│    - Chiến binh lao tới [Lunge anim], Chém đẩy lùi quái      │
│      -> Quái văng đập đầu vào tường đá [Stagger anim + Stun]│
│    - Xạ thủ bắn tỉa kích hoạt Băng tiễn làm chậm Lich        │
├─────────────────────────────────────────────────────────────┤
│ 3. Phản hồi nhịp chiến đấu (250ms mượt mà):                 │
│    - Rung nhẹ màn hình (Screen Shake) khi bom nổ            │
│    - Đốm lửa & tia khói bay tỏa (Floating Particle FX)       │
│    - Icon hiệu ứng trạng thái (Stunned 💫, Frozen ❄️, Fire 🔥)│
├─────────────────────────────────────────────────────────────┤
│ 4. Dọn sạch tầng -> Xuất hiện Cổng Dịch Chuyển Ma Pháp      │
│    - Toàn bộ MP được khôi phục 100%                         │
│    - Tiến vào Tầng tiếp theo (Thử thách & Tinh anh tăng cấp) │
└─────────────────────────────────────────────────────────────┘
```

#### B. Thiết kế thị giác & Biểu tượng
- **Thùng thuốc nổ (Explosive Barrel)**: Thiết kế vẽ vector chi tiết với dải đai sắt, nắp gỗ sồi và biểu tượng ngọn lửa màu cam đỏ nổi bật trên nền sàn ngục tối.
- **Hiệu ứng va tường & Choáng**: Vòng sao xoay trên đầu đơn vị bị choáng, chữ `"STUNNED!"` màu vàng kim nảy lên cùng âm thanh va đập vang dội.
- **Hoạt ảnh đơn vị mượt mà**:
  - Khi tấn công: Đơn vị lướt về phía mục tiêu 25% chiều dài ô, tung chiêu rồi nhẹ nhàng rút về vị trí cũ (250ms ease-out).
  - Khi chịu đòn: Đơn vị co rúm lại, giật lùi nhẹ kèm nhấp nháy đỏ cam rực rỡ và số máu trừ bay lên rõ ràng.

---

### 3. Key Product Decisions & Trade-Offs

- **Quyết định 1: Thùng Thuốc Nổ là đối tượng tương tác độc lập (Interactive Grid Entities)**
  - *Phương án*: Thùng thuốc nổ được coi như một thực thể có HP trên lưới ô (ví dụ 1 HP). Bất kỳ đòn tấn công nào (cận chiến, cung, ma pháp) chạm vào đều kích hoạt sự kiện phát nổ lan 3x3 ô xung quanh.
  - *Lý do*: Tạo ra cơ hội lật kèo ngoạn mục cho người chơi khi rơi vào tình huống bị quái vây hãm.
- **Quyết định 2: Cơ chế Đẩy Lùi dựa trên hình học vector (Geometric Knockback)**
  - *Phương án*: Tính vector đẩy từ vị trí người tấn công tới mục tiêu `dx = sign(target.x - attacker.x), dy = sign(target.y - attacker.y)`. Đẩy mục tiêu đến ô `(target.x + dx, target.y + dy)`. Nếu ô đó là Tường hoặc có Quái/Người khác đứng sẵn $\rightarrow$ Không di chuyển được, kích hoạt **Va Tường (Wall Slam)**: nhận thêm $1.5\times$ sát thương và gán trạng thái `stunnedTurns: 1`.
  - *Lý do*: Đưa tư duy cờ vây / cờ vua chiến thuật vào game, buộc người chơi phải cân nhắc vị trí đứng của mình so với kẻ địch và các bức tường.
- **Quyết định 3: Khắc phục triệt để lỗi tiêu hao MP**
  - *Phương án*:
    1. `ActionBar.tsx`: Nút skill bị vô hiệu hóa `disabled` (màu xám, opacity 40%) kèm ghi chú chi phí MP nếu `unit.mp < cost` hoặc đang hồi chiêu.
    2. `App.tsx`: Ngay khi bấm dùng kỹ năng, kiểm tra `if (activeUnit.mp < skillCost) return`.
    3. Khi đòn đánh trúng mục tiêu, lập tức gọi `deductMp(activeUnit.id, skillCost)`.
    4. Thêm âm thanh Web Audio "Buzz Error" trầm khi người chơi cố gắng bấm nút không khả dụng.

---

### 4. Technical Architecture & Data Strategy

```
┌────────────────────────────────────────────────────────────────────────┐
│                                App.tsx                                 │
│  - units[]: Thêm thuộc tính `isStunned?: boolean`, `elementDebuff`     │
│  - barrels[]: Mảng các thùng thuốc nổ `{ id, x, y, hp }`               │
│  - handleAttack(source, target, isSkill):                               │
│    1. Kiểm tra & Trừ MP nghiêm ngặt                                    │
│    2. Tính toán Sát thương + Combo Nguyên tố                           │
│    3. Xử lý Đẩy lùi (Knockback) -> Kiểm tra Va Tường (Stun)            │
│    4. Kiểm tra nổ Thùng Thuốc Nổ lan truyền                            │
│    5. Kích hoạt hoạt ảnh lunge + hit stagger                           │
└───────────────────────┬────────────────────────────┬───────────────────┘
                        │                            │
                        ▼                            ▼
┌───────────────────────────────────────┐ ┌──────────────────────────────┐
│           BattleCanvas.tsx            │ │        ActionBar.tsx         │
│  - Vẽ đơn vị với combatAnim           │ │  - Hiển thị MP thực tế       │
│    (Lunge offset + Stagger shake)     │ │  - Khóa nút kỹ năng khi cạn  │
│  - Vẽ Thùng Thuốc Nổ vector sắc nét   │ │    năng lượng                │
│  - Hiệu ứng Sóng Nổ & Chấn Động Màn   │ │  - Tooltip giải thích chi phí│
│  - Vẽ vòng xoay Stun 💫 trên đầu      │ │                              │
└───────────────────────────────────────┘ └──────────────────────────────┘
```

#### Chi tiết các file sẽ triển khai:
1. **`src/types/game.ts`**:
   - Thêm trạng thái `isStunned?: boolean`, `statusEffect?: 'freeze' | 'burn' | 'none'`.
   - Thêm kiểu dữ liệu `Barrel`: `{ id: string; x: number; y: number; hp: number }`.
   - Thêm thuộc tính hoạt ảnh chiến đấu: `combatAnim?: { type: 'lunge' | 'hit'; dx: number; dy: number; progress: number; startTime: number }`.
2. **`src/game/constants.ts`**:
   - Định nghĩa quy chuẩn sát thương va đập tường (Wall Slam Damage), bán kính nổ của thùng (Radius 1, 3x3 ô), và chi phí MP chuẩn xác.
3. **`src/components/BattleCanvas.tsx`**:
   - Thêm hàm vẽ Thùng thuốc nổ vector với viền phát sáng nhẹ.
   - Thêm hoạt ảnh lunge đòn đánh (offset di chuyển mượt mà tới mục tiêu) và hit recoil (rung giật + nháy đỏ sáng).
   - Thêm hiệu ứng sóng xung kích hình cầu khi thùng thuốc nổ phát nổ.
4. **`src/App.tsx`**:
   - Tích hợp logic sinh ngẫu nhiên 2–4 thùng thuốc nổ trên mỗi tầng hầm ngục.
   - Tích hợp hàm kiểm tra va tường khi bị đẩy lùi và gán trạng thái Choáng.
   - Siết chặt 100% kiểm tra MP ở cả giao diện và hàm thi triển.
   - Hồi đầy MP cho cả đội khi bước qua cổng sang tầng tiếp theo.
   - Tích hợp âm thanh Web Audio phản hồi (tiếng nổ thùng, tiếng đập tường thình thịch, tiếng choáng, tiếng cạn MP).
