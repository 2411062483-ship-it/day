import React from 'react';
import { Unit, GearItem } from '../types/game';

interface VisualPaperdollProps {
  unit: Unit;
  equipped?: Record<string, GearItem>;
  size?: 'sm' | 'md' | 'lg';
}

export const VisualPaperdoll: React.FC<VisualPaperdollProps> = ({
  unit,
  equipped = {},
  size = 'md',
}) => {
  const weapon = equipped.weapon;
  const shield = equipped.shield;
  const armor = equipped.armor;
  const ring = equipped.ring;

  const skin = unit.skinTone || '#fed7aa';
  const hair = unit.hairColor || '#1e293b';
  const hairStyle = unit.hairStyle || 'short';
  const cloak = unit.cloakColor || unit.color || '#3b82f6';

  const armorFam = armor?.armorFamily || (armor?.name.includes('Giáp') || armor?.name.includes('Thép') ? 'iron' : armor?.name.includes('Choàng') ? 'robe' : armor?.name.includes('Kim') ? 'gold' : 'leather');
  const shieldFam = shield?.shieldFamily || (shield?.name.includes('Aegis') ? 'aegis' : shield?.name.includes('Tròn') ? 'buckler' : 'iron');
  const weaponFam = weapon?.family || 'sword';

  const dim = size === 'sm' ? 44 : size === 'lg' ? 120 : 76;

  return (
    <div
      className="relative flex items-center justify-center rounded-lg bg-gradient-to-b from-slate-900 to-slate-950 border border-slate-700/80 shadow-inner overflow-hidden select-none shrink-0"
      style={{ width: dim, height: dim }}
    >
      <svg
        viewBox="0 0 100 100"
        className="w-full h-full drop-shadow-md"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        {/* Ambient pedestal circle */}
        <ellipse cx="50" cy="85" rx="30" ry="8" fill="rgba(0,0,0,0.4)" />
        <ellipse cx="50" cy="85" rx="20" ry="4" fill="rgba(245, 158, 11, 0.15)" />

        {/* Flowing Cloak / Mantle */}
        <path
          d="M32 42 L68 42 L76 80 L50 86 L24 80 Z"
          fill={cloak}
          stroke="rgba(0,0,0,0.3)"
          strokeWidth="1.5"
        />

        {/* Visual Armor Layer on Torso */}
        {armor ? (
          armorFam === 'iron' ? (
            <g>
              {/* Steel Plate Breastplate */}
              <rect x="34" y="44" width="32" height="32" rx="4" fill="#94a3b8" stroke="#334155" strokeWidth="1.5" />
              {/* Steel Sheen */}
              <path d="M44 46 L47 46 L45 74 L42 74 Z" fill="#f1f5f9" opacity="0.6" />
              {/* Pauldrons (Shoulder guards) */}
              <ellipse cx="30" cy="45" rx="8" ry="6" fill="#64748b" stroke="#334155" strokeWidth="1.2" />
              <ellipse cx="70" cy="45" rx="8" ry="6" fill="#64748b" stroke="#334155" strokeWidth="1.2" />
              {/* Rivets */}
              <circle cx="28" cy="45" r="1.5" fill="#f8fafc" />
              <circle cx="72" cy="45" r="1.5" fill="#f8fafc" />
            </g>
          ) : armorFam === 'robe' ? (
            <g>
              {/* Velvet Wizard Robe */}
              <path d="M33 44 L67 44 L72 82 L28 82 Z" fill="#312e81" stroke="#4338ca" strokeWidth="1.5" />
              {/* Gold Runic Trim */}
              <path d="M50 44 L50 82" stroke="#f59e0b" strokeWidth="2" />
              <path d="M33 44 L50 60 L67 44" stroke="#facc15" strokeWidth="1.5" />
            </g>
          ) : armorFam === 'gold' ? (
            <g>
              {/* Royal Gilded Plate */}
              <rect x="33" y="43" width="34" height="34" rx="4" fill="#f59e0b" stroke="#78350f" strokeWidth="1.5" />
              <ellipse cx="28" cy="44" rx="8" ry="7" fill="#d97706" />
              <ellipse cx="72" cy="44" rx="8" ry="7" fill="#d97706" />
              {/* Center Ruby */}
              <polygon points="50,50 54,55 50,60 46,55" fill="#ef4444" stroke="#fef08a" strokeWidth="1" />
            </g>
          ) : (
            <g>
              {/* Studded Leather Armor */}
              <rect x="35" y="44" width="30" height="31" rx="3" fill="#78350f" stroke="#451a03" strokeWidth="1.5" />
              <line x1="37" y1="48" x2="63" y2="72" stroke="#d97706" strokeWidth="1.8" />
              <circle cx="43" cy="54" r="1.2" fill="#fef08a" />
              <circle cx="57" cy="66" r="1.2" fill="#fef08a" />
            </g>
          )
        ) : (
          <rect x="36" y="44" width="28" height="30" rx="3" fill="#334155" />
        )}

        {/* Head & Skin Tone */}
        <circle cx="50" cy="30" r="14" fill={skin} stroke="rgba(0,0,0,0.15)" strokeWidth="1" />

        {/* Eyes & Expression */}
        <circle cx="45" cy="30" r="1.8" fill="#0f172a" />
        <circle cx="55" cy="30" r="1.8" fill="#0f172a" />

        {/* Hair Styles */}
        {hairStyle === 'spiky' ? (
          <path
            d="M34 30 Q36 14 50 12 Q64 14 66 30 L63 20 L55 24 L50 14 L45 24 L37 20 Z"
            fill={hair}
          />
        ) : hairStyle === 'long' || hairStyle === 'ponytail' ? (
          <g>
            <path d="M34 30 C34 16 66 16 66 30 C66 42 62 48 62 48 L38 48 C38 48 34 42 34 30 Z" fill={hair} />
            {hairStyle === 'ponytail' && (
              <path d="M60 26 Q75 32 72 45" stroke={hair} strokeWidth="5" strokeLinecap="round" />
            )}
          </g>
        ) : hairStyle !== 'bald' ? (
          <path d="M35 30 C35 18 65 18 65 30 L63 26 C57 23 43 23 37 26 Z" fill={hair} />
        ) : null}

        {/* VISUAL SHIELD LAYER (Left Arm) */}
        {shield && (
          shieldFam === 'aegis' ? (
            <g>
              <rect x="14" y="38" width="16" height="36" rx="4" fill="#38bdf8" stroke="#facc15" strokeWidth="2" />
              <line x1="22" y1="42" x2="22" y2="70" stroke="#fef08a" strokeWidth="2.5" />
              <line x1="16" y1="56" x2="28" y2="56" stroke="#fef08a" strokeWidth="2.5" />
            </g>
          ) : shieldFam === 'buckler' ? (
            <g>
              <circle cx="22" cy="54" r="12" fill="#b45309" stroke="#f59e0b" strokeWidth="2" />
              <circle cx="22" cy="54" r="4" fill="#fef3c7" />
            </g>
          ) : (
            <path
              d="M14 42 L30 42 L30 62 L22 72 L14 62 Z"
              fill="#64748b"
              stroke="#e2e8f0"
              strokeWidth="2"
            />
          )
        )}

        {/* VISUAL WEAPON LAYER (Right Hand) */}
        {weapon && (
          weaponFam === 'sword' ? (
            <g>
              <line x1="74" y1="68" x2="88" y2="22" stroke="#e2e8f0" strokeWidth="3.5" strokeLinecap="round" />
              <line x1="68" y1="62" x2="80" y2="58" stroke="#f59e0b" strokeWidth="2.5" />
              <circle cx="73" cy="70" r="2.5" fill="#f59e0b" />
            </g>
          ) : weaponFam === 'axe' ? (
            <g>
              <line x1="75" y1="72" x2="84" y2="26" stroke="#78350f" strokeWidth="3" />
              <path d="M82 28 C92 22 92 42 82 46 Z" fill="#94a3b8" stroke="#334155" strokeWidth="1.5" />
            </g>
          ) : weaponFam === 'hammer' ? (
            <g>
              <line x1="75" y1="72" x2="82" y2="28" stroke="#78350f" strokeWidth="3" />
              <rect x="76" y="24" width="16" height="12" rx="2" fill="#475569" stroke="#1e293b" strokeWidth="1.5" />
            </g>
          ) : weaponFam === 'bow' ? (
            <g>
              <path d="M76 22 Q92 48 76 74" stroke="#d97706" strokeWidth="3" fill="none" />
              <line x1="76" y1="22" x2="76" y2="74" stroke="#f8fafc" strokeWidth="1" />
              <line x1="70" y1="48" x2="84" y2="48" stroke="#4ade80" strokeWidth="2" />
            </g>
          ) : weaponFam === 'crossbow' ? (
            <g>
              <rect x="74" y="38" width="6" height="26" fill="#78350f" />
              <line x1="66" y1="44" x2="88" y2="44" stroke="#64748b" strokeWidth="3" />
            </g>
          ) : weaponFam === 'staff' ? (
            <g>
              <line x1="75" y1="74" x2="85" y2="28" stroke="#78350f" strokeWidth="3" />
              <circle cx="85" cy="26" r="6" fill="#38bdf8" filter="drop-shadow(0 0 4px #0284c7)" />
              <circle cx="85" cy="26" r="3" fill="#f0f9ff" />
            </g>
          ) : weaponFam === 'tome' ? (
            <g>
              <rect x="74" y="42" width="16" height="20" rx="2" fill="#7e22ce" stroke="#f59e0b" strokeWidth="1.5" />
              <line x1="77" y1="48" x2="87" y2="48" stroke="#38bdf8" strokeWidth="1.5" />
              <line x1="77" y1="54" x2="87" y2="54" stroke="#38bdf8" strokeWidth="1.5" />
            </g>
          ) : weaponFam === 'bell' ? (
            <g>
              <path d="M76 44 Q82 36 88 44 L90 56 L74 56 Z" fill="#f59e0b" stroke="#b45309" strokeWidth="1.5" />
              <circle cx="82" cy="58" r="2.5" fill="#fef08a" />
            </g>
          ) : weaponFam === 'dagger' ? (
            <g>
              <line x1="74" y1="64" x2="85" y2="45" stroke="#38bdf8" strokeWidth="2.5" />
              <line x1="68" y1="68" x2="78" y2="52" stroke="#38bdf8" strokeWidth="2.5" />
            </g>
          ) : (
            <g>
              <line x1="72" y1="74" x2="88" y2="18" stroke="#92400e" strokeWidth="2.5" />
              <polygon points="88,14 93,24 83,24" fill="#f1f5f9" stroke="#64748b" strokeWidth="1" />
            </g>
          )
        )}

        {/* VISUAL RING GLOW */}
        {ring && (
          <circle cx="72" cy="62" r="3" fill="#facc15" filter="drop-shadow(0 0 3px #f59e0b)" />
        )}
      </svg>
    </div>
  );
};
