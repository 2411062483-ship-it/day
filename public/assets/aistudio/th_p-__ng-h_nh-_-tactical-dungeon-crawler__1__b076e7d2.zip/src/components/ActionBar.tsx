import React from 'react';
import { Play, Pause, RotateCcw, Volume2, VolumeX, Swords, Shield, Zap, FastForward, UserCheck, Bot } from 'lucide-react';
import { Unit, ControlMode, EffectiveStats, GearItem } from '../types/game';
import { VisualPaperdoll } from './VisualPaperdoll';
import { WEAPON_FAMILIES } from '../game/constants';

interface ActionBarProps {
  phase: string;
  paused: boolean;
  activeUnit: Unit | null;
  controlMode: ControlMode;
  speed: number;
  isMuted: boolean;
  equipped: Record<string, Record<string, GearItem>>;
  onTogglePlay: () => void;
  onToggleSpeed: () => void;
  onRestartRoom: () => void;
  onToggleMute: () => void;
  onToggleControlMode: () => void;
  onManualAttack: () => void;
  onManualSkill: () => void;
  onManualSpecialSkill?: () => void;
  onManualDefend: () => void;
  onManualEndTurn: () => void;
  getEffectiveStats: (unit: Unit) => EffectiveStats;
}

export const ActionBar: React.FC<ActionBarProps> = ({
  phase,
  paused,
  activeUnit,
  controlMode,
  speed,
  isMuted,
  equipped,
  onTogglePlay,
  onToggleSpeed,
  onRestartRoom,
  onToggleMute,
  onToggleControlMode,
  onManualAttack,
  onManualSkill,
  onManualSpecialSkill,
  onManualDefend,
  onManualEndTurn,
  getEffectiveStats,
}) => {
  const isHeroTurn = activeUnit?.kind === 'hero' && !activeUnit.acted && phase === 'playing';
  const eff = activeUnit ? getEffectiveStats(activeUnit) : null;
  const activeGear = activeUnit ? equipped[activeUnit.id] || {} : {};
  const currentWeapon = activeGear.weapon;
  const weaponFam = currentWeapon?.family || 'sword';
  const skillMeta = WEAPON_FAMILIES[weaponFam] || { skillName: 'Kỹ Năng Chiến Đấu', skillDesc: '' };

  // Find any equipped item with a unique Special Skill (Summon, Transform, AoE, Bastion, Petrify)
  const specialItem = activeUnit
    ? Object.values(activeGear).find((i) => i?.specialSkill)
    : null;

  return (
    <div className="bg-[#0b0f19] border-2 border-[#334155] rounded-xl p-3 shadow-2xl flex flex-col gap-2.5">
      {/* Top row: Active Unit Status & Global Command Controls */}
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-[#1e293b] pb-2.5">
        {/* Active Adventurer Display with Miniature Paperdoll */}
        <div className="flex items-center gap-3">
          {activeUnit ? (
            <div className="flex items-center gap-2.5">
              {activeUnit.kind === 'hero' ? (
                <VisualPaperdoll unit={activeUnit} equipped={activeGear} size="sm" />
              ) : (
                <div
                  className="w-10 h-10 rounded-lg flex items-center justify-center font-bold text-base shadow border border-red-500/40"
                  style={{ backgroundColor: activeUnit.color, color: '#090d0b' }}
                >
                  {activeUnit.glyph}
                </div>
              )}
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-bold text-slate-100 text-sm font-cinzel tracking-wide">{activeUnit.name}</span>
                  <span className="text-[10px] font-mono text-amber-400">
                    {activeUnit.title || activeUnit.role}
                  </span>
                  {activeUnit.transformation && (
                    <span className="px-1.5 py-0.2 rounded text-[9px] bg-red-950 text-red-300 border border-red-700 font-mono font-bold animate-pulse">
                      HÓA THÂN ({activeUnit.transformation.turnsRemaining}T)
                    </span>
                  )}
                  {activeUnit.bastionTicks && activeUnit.bastionTicks > 0 ? (
                    <span className="px-1.5 py-0.2 rounded text-[9px] bg-amber-950 text-amber-300 border border-amber-600 font-mono font-bold">
                      BẤT ĐỘNG
                    </span>
                  ) : null}
                  {(activeUnit.isStunned || (activeUnit.stunTicks || 0) > 0) && (
                    <span className="px-1.5 py-0.2 rounded text-[9px] bg-yellow-950 text-yellow-300 border border-yellow-500 font-mono font-bold animate-bounce">
                      CHOÁNG 💫
                    </span>
                  )}
                  {activeUnit.elevation === 1 && (
                    <span className="px-1.5 py-0.2 rounded text-[9px] bg-sky-950 text-sky-300 border border-sky-500 font-mono font-bold">
                      ▲ ĐÀI CAO (+25%)
                    </span>
                  )}
                </div>
                <div className="text-xs text-slate-400 font-mono flex items-center gap-2">
                  <span className="text-emerald-400 font-semibold">HP {activeUnit.hp}/{eff?.hp || activeUnit.maxHp}</span>
                  <span className="text-slate-600">·</span>
                  <span className="text-sky-400 font-semibold">MP {activeUnit.mp}/{eff?.mp || activeUnit.maxMp}</span>
                  <span className="text-slate-600">·</span>
                  <span className="text-amber-300">SPD {eff?.spd || activeUnit.spd}</span>
                  <span className="text-slate-600">·</span>
                  <span className="text-rose-400">DEF {eff?.def || activeUnit.def}</span>
                </div>
              </div>
            </div>
          ) : (
            <div className="flex items-center gap-2 text-slate-400 text-xs font-mono py-1">
              <span className="w-2.5 h-2.5 rounded-full bg-slate-600 animate-pulse" />
              <span>Chờ lệnh xuất kích</span>
            </div>
          )}
        </div>

        {/* Global Controls */}
        <div className="flex items-center gap-2">
          {/* Tactical Mode Toggle (Auto AI vs Manual Control) */}
          <button
            onClick={onToggleControlMode}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-mono font-bold transition-all border ${
              controlMode === 'auto'
                ? 'bg-emerald-950/80 text-emerald-300 border-emerald-600/70 hover:bg-emerald-900/60 shadow-lg shadow-emerald-950/40'
                : 'bg-amber-950/80 text-amber-300 border-amber-600/70 hover:bg-amber-900/60 shadow-lg shadow-amber-950/40'
            }`}
            title="Đổi giữa Tự Động (AI điều khiển) và Thủ Công (Người chơi điều khiển)"
          >
            {controlMode === 'auto' ? <Bot className="w-4 h-4" /> : <UserCheck className="w-4 h-4" />}
            <span>{controlMode === 'auto' ? 'TỰ ĐỘNG (AI)' : 'THỦ CÔNG'}</span>
          </button>

          {/* Speed Toggle */}
          <button
            onClick={onToggleSpeed}
            className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-mono font-bold transition-colors border border-slate-700"
            title="Tốc độ trận đấu"
          >
            <FastForward className="w-3.5 h-3.5 text-amber-400" />
            <span>{speed}x</span>
          </button>

          {/* Sound Toggle */}
          <button
            onClick={onToggleMute}
            className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs transition-colors border border-slate-700"
            title={isMuted ? 'Bật âm thanh' : 'Tắt âm thanh'}
          >
            {isMuted ? <VolumeX className="w-4 h-4 text-rose-400" /> : <Volume2 className="w-4 h-4 text-emerald-400" />}
          </button>

          {/* Restart Room */}
          <button
            onClick={onRestartRoom}
            className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs transition-colors border border-slate-700"
            title="Tái lập phòng chiến"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Main Action Bar */}
      <div className="flex flex-wrap items-center justify-between gap-2.5">
        {/* Play / Pause Primary CTA */}
        <button
          onClick={onTogglePlay}
          disabled={phase === 'won' || phase === 'lost'}
          className={`flex-1 min-w-[130px] flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg font-bold text-xs uppercase tracking-wider transition-all shadow-md ${
            phase === 'ready'
              ? 'bg-gradient-to-r from-amber-500 via-amber-400 to-amber-500 hover:from-amber-400 hover:to-amber-300 text-slate-950 font-black shadow-amber-950/60'
              : paused
              ? 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-emerald-950/60'
              : 'bg-slate-800 hover:bg-slate-700 text-amber-300 border border-amber-600/50'
          }`}
        >
          {phase === 'ready' ? (
            <>
              <Play className="w-4 h-4 fill-current" />
              <span>BẮT ĐẦU CHIẾN ĐẤU</span>
            </>
          ) : paused ? (
            <>
              <Play className="w-4 h-4 fill-current" />
              <span>TIẾP TỤC</span>
            </>
          ) : (
            <>
              <Pause className="w-4 h-4" />
              <span>TẠM DỪNG</span>
            </>
          )}
        </button>

        {/* Manual Action Buttons (Active when player's turn in manual mode) */}
        {controlMode === 'manual' && isHeroTurn && (
          <div className="flex flex-wrap items-center gap-1.5 flex-[2]">
            <button
              onClick={onManualAttack}
              className="px-3 py-2 rounded-lg bg-amber-950/60 hover:bg-amber-900/60 text-amber-300 border border-amber-600/60 text-xs font-bold transition-all shadow flex items-center gap-1"
            >
              <Swords className="w-4 h-4" />
              <span>ĐÁNH</span>
            </button>

            {/* Weapon Skill with STRICT MP & COOLDOWN VALIDATION */}
            {(() => {
              const weaponMp = skillMeta.mpCost || 3;
              const hasMp = activeUnit.mp >= weaponMp;
              const onCooldown = (activeUnit.skillCooldown || 0) > 0;
              const isDisabled = !hasMp || onCooldown;

              return (
                <button
                  onClick={onManualSkill}
                  disabled={isDisabled}
                  className={`px-3 py-2 rounded-lg text-xs font-bold transition-all shadow flex items-center gap-1.5 ${
                    isDisabled
                      ? 'bg-slate-900/80 text-slate-500 border border-slate-800 cursor-not-allowed opacity-50'
                      : 'bg-indigo-950/80 hover:bg-indigo-900 text-indigo-300 border border-indigo-500/80 shadow-indigo-950/50'
                  }`}
                  title={
                    onCooldown
                      ? `Đang hồi chiêu (${activeUnit.skillCooldown} lượt)`
                      : !hasMp
                      ? `Không đủ MP! Cần ${weaponMp} MP (Hiện có ${activeUnit.mp} MP)`
                      : skillMeta.skillDesc
                  }
                >
                  <Zap className="w-4 h-4" />
                  <span className="truncate">{skillMeta.skillName}</span>
                  <span
                    className={`text-[10px] font-mono px-1 py-0.5 rounded ${
                      !hasMp
                        ? 'bg-rose-950/90 text-rose-400 font-bold border border-rose-800'
                        : 'bg-sky-950/80 text-sky-300'
                    }`}
                  >
                    {onCooldown ? `${activeUnit.skillCooldown}T` : `${weaponMp}MP`}
                  </span>
                </button>
              );
            })()}

            {/* Unique Artifact / Weapon Special Skill with STRICT MP & COOLDOWN VALIDATION */}
            {specialItem?.specialSkill && onManualSpecialSkill && (() => {
              const specialMp = specialItem.specialSkillMp || 4;
              const hasMp = activeUnit.mp >= specialMp;
              const onCooldown = (activeUnit.skillCooldown || 0) > 0;
              const isDisabled = !hasMp || onCooldown;

              return (
                <button
                  onClick={onManualSpecialSkill}
                  disabled={isDisabled}
                  className={`px-3 py-2 rounded-lg text-xs font-bold transition-all shadow-lg flex items-center gap-1.5 ${
                    isDisabled
                      ? 'bg-slate-900/80 text-slate-500 border border-slate-800 cursor-not-allowed opacity-50'
                      : 'bg-purple-950 hover:bg-purple-900 text-purple-200 border border-purple-500 shadow-purple-950/60 animate-pulse'
                  }`}
                  title={
                    onCooldown
                      ? `Đang hồi chiêu (${activeUnit.skillCooldown} lượt)`
                      : !hasMp
                      ? `Không đủ MP! Cần ${specialMp} MP (Hiện có ${activeUnit.mp} MP)`
                      : specialItem.specialSkillDesc || specialItem.description
                  }
                >
                  <span>⚡</span>
                  <span className="truncate">{specialItem.specialSkillName || 'Tuyệt Kỹ'}</span>
                  <span
                    className={`text-[10px] font-mono px-1 py-0.5 rounded ${
                      !hasMp
                        ? 'bg-rose-950/90 text-rose-400 font-bold border border-rose-800'
                        : 'bg-purple-900/80 text-purple-200'
                    }`}
                  >
                    {onCooldown ? `${activeUnit.skillCooldown}T` : `${specialMp}MP`}
                  </span>
                </button>
              );
            })()}

            <button
              onClick={onManualDefend}
              className="px-3 py-2 rounded-lg bg-sky-950/60 hover:bg-sky-900/60 text-sky-300 border border-sky-600/60 text-xs font-bold transition-all shadow flex items-center gap-1"
            >
              <Shield className="w-4 h-4" />
              <span>THỦ HỘ</span>
            </button>

            <button
              onClick={onManualEndTurn}
              className="px-2.5 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 text-xs font-bold transition-colors"
            >
              QUA LƯỢT
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
