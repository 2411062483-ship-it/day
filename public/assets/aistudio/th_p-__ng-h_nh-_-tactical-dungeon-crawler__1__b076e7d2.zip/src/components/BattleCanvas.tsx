import React, { useEffect, useRef, useCallback } from 'react';
import { GRID_COLS, GRID_ROWS, EXIT_DOOR } from '../game/constants';
import { Unit, TerrainTile, BossTelegraph, VisualEffect, EffectiveStats, GearItem, DungeonBiome, ExplosiveBarrel } from '../types/game';

interface BattleCanvasProps {
  units: Unit[];
  walls: Set<string>;
  terrainMap: Map<string, TerrainTile>;
  triggeredTraps: Set<string>;
  bossTelegraph: BossTelegraph[];
  visualEffects: VisualEffect[];
  activeId: string | null;
  selectedId: string | null;
  moveTiles: { x: number; y: number }[];
  targetTiles: { x: number; y: number }[];
  phase: string;
  biome: DungeonBiome;
  equipped: Record<string, Record<string, GearItem>>;
  onTileClick: (x: number, y: number) => void;
  getEffectiveStats: (unit: Unit) => EffectiveStats;
  screenShake: number;
  elevations?: Set<string>;
  barrels?: ExplosiveBarrel[];
}

export const BattleCanvas: React.FC<BattleCanvasProps> = ({
  units,
  walls,
  terrainMap,
  triggeredTraps,
  bossTelegraph,
  visualEffects,
  activeId,
  selectedId,
  moveTiles,
  targetTiles,
  phase,
  biome,
  equipped,
  onTileClick,
  getEffectiveStats,
  screenShake,
  elevations = new Set(),
  barrels = [],
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);

  const draw = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const rect = canvas.getBoundingClientRect();
    if (!rect.width || !rect.height) return;

    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const width = Math.floor(rect.width * dpr);
    const height = Math.floor(rect.height * dpr);

    if (canvas.width !== width || canvas.height !== height) {
      canvas.width = width;
      canvas.height = height;
    }

    ctx.save();
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.clearRect(0, 0, width, height);

    // Screen shake
    if (screenShake > 0) {
      const shakeX = (Math.random() - 0.5) * screenShake * dpr;
      const shakeY = (Math.random() - 0.5) * screenShake * dpr;
      ctx.translate(shakeX, shakeY);
    }

    const cellW = width / GRID_COLS;
    const cellH = height / GRID_ROWS;
    const now = performance.now();

    // 1. Draw procedural Dungeon Floor according to Biome
    for (let y = 0; y < GRID_ROWS; y++) {
      for (let x = 0; x < GRID_COLS; x++) {
        const px = x * cellW;
        const py = y * cellH;
        const hash = (x * 13 + y * 29) % 17;

        // 1. Draw procedural Dungeon Floor according to Biome with 3D Cobblestones & Shading
        const alt = (x + y) % 2 === 0;

        if (biome === 'prison') {
          // Prison floor: Heavy granite slabs with iron rivets, drainage grates, and cold steel tint
          ctx.fillStyle = alt ? '#121722' : '#0c1018';
          ctx.fillRect(px, py, cellW, cellH);

          // 4-slab cobblestone pattern within each cell for genuine tactical depth
          const halfW = cellW / 2;
          const halfH = cellH / 2;
          const pavers = [
            { x: px + 1, y: py + 1, w: halfW - 2, h: halfH - 2, tone: (x * 3 + y * 5) % 3 },
            { x: px + halfW + 1, y: py + 1, w: halfW - 2, h: halfH - 2, tone: (x * 5 + y * 2) % 3 },
            { x: px + 1, y: py + halfH + 1, w: halfW - 2, h: halfH - 2, tone: (x * 2 + y * 7) % 3 },
            { x: px + halfW + 1, y: py + halfH + 1, w: halfW - 2, h: halfH - 2, tone: (x * 7 + y * 3) % 3 },
          ];

          pavers.forEach((p) => {
            ctx.fillStyle = p.tone === 0 ? 'rgba(255,255,255,0.025)' : p.tone === 1 ? 'rgba(0,0,0,0.22)' : 'rgba(51, 65, 85, 0.08)';
            ctx.fillRect(p.x, p.y, p.w, p.h);
            // 3D Bevel highlight
            ctx.fillStyle = 'rgba(255, 255, 255, 0.04)';
            ctx.fillRect(p.x, p.y, p.w, 1 * dpr);
            ctx.fillRect(p.x, p.y, 1 * dpr, p.h);
            // 3D Bevel shadow
            ctx.fillStyle = 'rgba(0, 0, 0, 0.35)';
            ctx.fillRect(p.x, p.y + p.h - 1 * dpr, p.w, 1 * dpr);
            ctx.fillRect(p.x + p.w - 1 * dpr, p.y, 1 * dpr, p.h);
          });

          // Mortar boundary
          ctx.strokeStyle = '#1a2230';
          ctx.lineWidth = 1;
          ctx.strokeRect(px + 0.5, py + 0.5, cellW, cellH);

          // Iron rivets on select pavers
          if (hash % 3 === 0) {
            ctx.fillStyle = '#64748b';
            ctx.beginPath();
            ctx.arc(px + 5 * dpr, py + 5 * dpr, 1.6 * dpr, 0, Math.PI * 2);
            ctx.arc(px + cellW - 5 * dpr, py + cellH - 5 * dpr, 1.6 * dpr, 0, Math.PI * 2);
            ctx.fill();
            ctx.fillStyle = '#94a3b8';
            ctx.fillRect(px + 4 * dpr, py + 4 * dpr, 1 * dpr, 1 * dpr);
          }

          // Iron drainage grate on floor
          if (hash === 7) {
            ctx.fillStyle = '#05070a';
            ctx.fillRect(px + cellW * 0.22, py + cellH * 0.22, cellW * 0.56, cellH * 0.56);
            ctx.strokeStyle = '#475569';
            ctx.lineWidth = 1.8 * dpr;
            ctx.strokeRect(px + cellW * 0.22, py + cellH * 0.22, cellW * 0.56, cellH * 0.56);
            for (let i = 1; i <= 3; i++) {
              ctx.beginPath();
              ctx.moveTo(px + cellW * 0.22 + (cellW * 0.56 * i) / 4, py + cellH * 0.22);
              ctx.lineTo(px + cellW * 0.22 + (cellW * 0.56 * i) / 4, py + cellH * 0.78);
              ctx.stroke();
            }
          }
        } else if (biome === 'mossy_ruins') {
          // Mossy ancient flagstone ruins with rich green velvet patches and cracks
          ctx.fillStyle = alt ? '#18241b' : '#131d16';
          ctx.fillRect(px, py, cellW, cellH);

          // Pavers
          const halfW = cellW / 2;
          const halfH = cellH / 2;
          const pavers = [
            { x: px + 1, y: py + 1, w: halfW - 2, h: halfH - 2, tone: (x * 4 + y * 6) % 3 },
            { x: px + halfW + 1, y: py + 1, w: halfW - 2, h: halfH - 2, tone: (x * 6 + y * 3) % 3 },
            { x: px + 1, y: py + halfH + 1, w: halfW - 2, h: halfH - 2, tone: (x * 3 + y * 8) % 3 },
            { x: px + halfW + 1, y: py + halfH + 1, w: halfW - 2, h: halfH - 2, tone: (x * 8 + y * 4) % 3 },
          ];

          pavers.forEach((p) => {
            ctx.fillStyle = p.tone === 0 ? 'rgba(34, 197, 94, 0.04)' : p.tone === 1 ? 'rgba(0,0,0,0.2)' : 'rgba(255, 255, 255, 0.02)';
            ctx.fillRect(p.x, p.y, p.w, p.h);
            ctx.fillStyle = 'rgba(255, 255, 255, 0.035)';
            ctx.fillRect(p.x, p.y, p.w, 1 * dpr);
            ctx.fillRect(p.x, p.y, 1 * dpr, p.h);
          });

          ctx.strokeStyle = '#233827';
          ctx.lineWidth = 1;
          ctx.strokeRect(px + 0.5, py + 0.5, cellW, cellH);

          // Multi-layer moss spots with leafy edges
          if (hash % 2 === 0) {
            ctx.fillStyle = 'rgba(21, 128, 61, 0.35)';
            ctx.beginPath();
            ctx.arc(px + cellW * 0.25, py + cellH * 0.3, cellW * 0.22, 0, Math.PI * 2);
            ctx.fill();
            ctx.fillStyle = 'rgba(34, 197, 94, 0.45)';
            ctx.beginPath();
            ctx.arc(px + cellW * 0.25, py + cellH * 0.3, cellW * 0.14, 0, Math.PI * 2);
            ctx.fill();
            // Tiny blooming spore flower
            ctx.fillStyle = '#facc15';
            ctx.beginPath();
            ctx.arc(px + cellW * 0.22, py + cellH * 0.26, 1.2 * dpr, 0, Math.PI * 2);
            ctx.fill();
          }

          // Fractured stone crack
          if (hash % 3 === 1) {
            ctx.strokeStyle = '#080d09';
            ctx.lineWidth = 1.4 * dpr;
            ctx.beginPath();
            ctx.moveTo(px + cellW * 0.08, py + cellH * 0.75);
            ctx.lineTo(px + cellW * 0.42, py + cellH * 0.45);
            ctx.lineTo(px + cellW * 0.82, py + cellH * 0.65);
            ctx.stroke();
          }
        } else if (biome === 'abyssal_forge') {
          // Abyssal basalt & volcanic obsidian
          ctx.fillStyle = alt ? '#1e1414' : '#140c0c';
          ctx.fillRect(px, py, cellW, cellH);

          ctx.strokeStyle = '#381c1c';
          ctx.lineWidth = 1;
          ctx.strokeRect(px + 0.5, py + 0.5, cellW, cellH);

          // Magma crack lines glowing inside stone
          if (hash % 3 === 0) {
            const glow = 0.4 + Math.sin(now / 350 + x * 2 + y) * 0.25;
            ctx.strokeStyle = `rgba(239, 68, 68, ${glow})`;
            ctx.lineWidth = 1.5 * dpr;
            ctx.beginPath();
            ctx.moveTo(px + cellW * 0.2, py + cellH * 0.8);
            ctx.lineTo(px + cellW * 0.5, py + cellH * 0.4);
            ctx.lineTo(px + cellW * 0.75, py + cellH * 0.2);
            ctx.stroke();
          }
        } else {
          // Crystal Sanctum: Arcane polished marble
          ctx.fillStyle = alt ? '#151e2b' : '#0e1520';
          ctx.fillRect(px, py, cellW, cellH);

          ctx.strokeStyle = '#223247';
          ctx.lineWidth = 1;
          ctx.strokeRect(px + 0.5, py + 0.5, cellW, cellH);

          if (hash % 3 === 0) {
            ctx.fillStyle = 'rgba(56, 189, 248, 0.06)';
            ctx.fillRect(px + 2, py + 2, cellW - 4, cellH - 4);
          }
        }
      }
    }

    // 1b. Central Arcane / Ritual Circle on floor
    const centerFloorX = (GRID_COLS / 2) * cellW;
    const centerFloorY = (GRID_ROWS / 2) * cellH;
    const runeRadius = Math.min(cellW, cellH) * 1.8;
    const pulseAlpha = 0.15 + Math.sin(now / 900) * 0.06;
    ctx.save();
    ctx.strokeStyle = biome === 'abyssal_forge' ? `rgba(239, 68, 68, ${pulseAlpha})` : `rgba(52, 211, 153, ${pulseAlpha})`;
    ctx.lineWidth = 1.8 * dpr;
    ctx.beginPath();
    ctx.arc(centerFloorX, centerFloorY, runeRadius, 0, Math.PI * 2);
    ctx.stroke();
    ctx.strokeStyle = `rgba(245, 158, 11, ${pulseAlpha * 0.8})`;
    ctx.setLineDash([5 * dpr, 6 * dpr]);
    ctx.beginPath();
    ctx.arc(centerFloorX, centerFloorY, runeRadius * 0.72, 0, Math.PI * 2);
    ctx.stroke();
    ctx.setLineDash([]);
    ctx.restore();

    // 1c. Draw High Ground Elevation Platforms (Bậc Thềm Đá Cao)
    for (const key of elevations) {
      const [ex, ey] = key.split(',').map(Number);
      const px = ex * cellW;
      const py = ey * cellH;

      // Elevated granite slab fill with subtle tint
      ctx.fillStyle = biome === 'abyssal_forge' ? '#251515' : biome === 'mossy_ruins' ? '#182b1d' : '#1e293b';
      ctx.fillRect(px + 1, py + 1, cellW - 2, cellH - 2);

      // 3D Cliff Top-Left Light Bevel
      ctx.fillStyle = 'rgba(255, 255, 255, 0.14)';
      ctx.fillRect(px + 1, py + 1, cellW - 2, 2.5 * dpr);
      ctx.fillRect(px + 1, py + 1, 2.5 * dpr, cellH - 2);

      // 3D Cliff Bottom-Right Deep Shadow Edge
      ctx.fillStyle = 'rgba(0, 0, 0, 0.65)';
      ctx.fillRect(px + 1, py + cellH - 3.5 * dpr, cellW - 2, 3.5 * dpr);
      ctx.fillRect(px + cellW - 3.5 * dpr, py + 1, 3.5 * dpr, cellH - 2);

      // Sky-blue border highlight
      ctx.strokeStyle = 'rgba(56, 189, 248, 0.45)';
      ctx.lineWidth = 1 * dpr;
      ctx.strokeRect(px + 2.5, py + 2.5, cellW - 5, cellH - 5);

      // High Ground Tag in corner
      ctx.fillStyle = '#38bdf8';
      ctx.font = `bold ${Math.max(8, Math.floor(cellH * 0.1))}px 'DM Mono', monospace`;
      ctx.textAlign = 'right';
      ctx.fillText('▲ CAO', px + cellW - 4 * dpr, py + 9 * dpr);
    }

    // 2. Draw terrain tiles (Water, Abyss, Bridge, Lava, Trap, Portal, Iron Bars, Altar, Moss)
    for (const [key, tile] of terrainMap.entries()) {
      const [x, y] = key.split(',').map(Number);
      const px = x * cellW;
      const py = y * cellH;

      if (tile.type === 'iron_bars') {
        // SONG SẮT (High-Fidelity 3D Metallic Prison Portcullis Bars)
        // Deep shadow behind the iron gate
        ctx.fillStyle = 'rgba(0, 0, 0, 0.7)';
        ctx.fillRect(px, py, cellW, cellH);

        // Ground opening
        ctx.fillStyle = '#06090e';
        ctx.fillRect(px + 2, py + 2, cellW - 4, cellH - 4);

        // Heavy stone arched lintel
        ctx.fillStyle = '#1e293b';
        ctx.fillRect(px + 2, py + 2, cellW - 4, cellH * 0.18);
        ctx.fillStyle = '#334155';
        ctx.fillRect(px + 2, py + 2, cellW - 4, 1.5 * dpr);

        // Horizontal forged steel brace bands
        ctx.fillStyle = '#334155';
        ctx.fillRect(px + 2, py + cellH * 0.3, cellW - 4, 3.5 * dpr);
        ctx.fillRect(px + 2, py + cellH * 0.7, cellW - 4, 3.5 * dpr);
        ctx.fillStyle = '#64748b';
        ctx.fillRect(px + 2, py + cellH * 0.3, cellW - 4, 1 * dpr);
        ctx.fillRect(px + 2, py + cellH * 0.7, cellW - 4, 1 * dpr);

        // 4 Vertical Heavy Iron Bars with 3D metallic gradient
        for (let i = 1; i <= 4; i++) {
          const barX = px + (cellW * i) / 5;
          // Cast shadow
          ctx.fillStyle = 'rgba(0, 0, 0, 0.55)';
          ctx.fillRect(barX + 2 * dpr, py + 4, 2.5 * dpr, cellH - 8);
          // Dark steel body
          ctx.fillStyle = '#475569';
          ctx.fillRect(barX - 2 * dpr, py + 4, 4 * dpr, cellH - 8);
          // Center silver specular streak
          ctx.fillStyle = '#cbd5e1';
          ctx.fillRect(barX - 0.5 * dpr, py + 4, 1.2 * dpr, cellH - 8);
          // Iron rivets on cross intersections
          ctx.fillStyle = '#f59e0b';
          ctx.fillRect(barX - 2.5 * dpr, py + cellH * 0.3 - 0.5 * dpr, 5 * dpr, 4 * dpr);
          ctx.fillRect(barX - 2.5 * dpr, py + cellH * 0.7 - 0.5 * dpr, 5 * dpr, 4 * dpr);
        }

        // Hanging rusted iron chains dangling from bars
        ctx.strokeStyle = '#78350f';
        ctx.lineWidth = 1.5 * dpr;
        ctx.beginPath();
        ctx.moveTo(px + cellW * 0.3, py + cellH * 0.18);
        ctx.lineTo(px + cellW * 0.32, py + cellH * 0.45);
        ctx.stroke();

        // EERIE LURKING EYES BEHIND IRON BARS!
        const eyeHash = (x * 7 + y * 11) % 4;
        if (eyeHash === 1) {
          const blink = Math.sin(now / 800 + x * 3) > 0.92;
          if (!blink) {
            const eyeX = px + cellW * 0.4;
            const eyeY = py + cellH * 0.52;
            // Red demonic glowing eyes with aura
            ctx.fillStyle = '#ef4444';
            ctx.shadowColor = '#ef4444';
            ctx.shadowBlur = 8 * dpr;
            ctx.beginPath();
            ctx.ellipse(eyeX - 4.5 * dpr, eyeY, 2.2 * dpr, 3 * dpr, 0, 0, Math.PI * 2);
            ctx.ellipse(eyeX + 4.5 * dpr, eyeY, 2.2 * dpr, 3 * dpr, 0, 0, Math.PI * 2);
            ctx.fill();
            ctx.shadowBlur = 0;
            // Slit pupil that tracks
            ctx.fillStyle = '#05070a';
            ctx.fillRect(eyeX - 5 * dpr, eyeY - 2.5 * dpr, 1.2 * dpr, 5 * dpr);
            ctx.fillRect(eyeX + 4 * dpr, eyeY - 2.5 * dpr, 1.2 * dpr, 5 * dpr);
          }
        }
      } else if (tile.type === 'altar') {
        // ĐÀI TẾ THÁNH QUANG (Ancient Altar with Holy Light Beams)
        ctx.fillStyle = '#1e293b';
        ctx.fillRect(px + 4, py + 4, cellW - 8, cellH - 8);

        // Glowing golden / cyan altar ring with pulsing halo
        const altarPulse = 0.65 + Math.sin(now / 400 + x) * 0.35;
        ctx.strokeStyle = `rgba(234, 179, 8, ${altarPulse})`;
        ctx.lineWidth = 2.5 * dpr;
        ctx.strokeRect(px + 6, py + 6, cellW - 12, cellH - 12);

        // Center sacred sun rune
        ctx.fillStyle = '#facc15';
        ctx.shadowColor = '#facc15';
        ctx.shadowBlur = 10 * dpr;
        ctx.beginPath();
        ctx.arc(px + cellW / 2, py + cellH / 2, 6 * dpr, 0, Math.PI * 2);
        ctx.fill();
        ctx.shadowBlur = 0;

        // Radiant sun rays
        ctx.strokeStyle = '#fef08a';
        ctx.lineWidth = 1.5 * dpr;
        ctx.beginPath();
        ctx.moveTo(px + cellW / 2 - 10 * dpr, py + cellH / 2);
        ctx.lineTo(px + cellW / 2 + 10 * dpr, py + cellH / 2);
        ctx.moveTo(px + cellW / 2, py + cellH / 2 - 10 * dpr);
        ctx.lineTo(px + cellW / 2, py + cellH / 2 + 10 * dpr);
        ctx.stroke();

        // Rising holy light motes
        const moteY = py + cellH * 0.8 - ((now / 15 + x * 20) % (cellH * 0.7));
        ctx.fillStyle = '#fef08a';
        ctx.beginPath();
        ctx.arc(px + cellW * 0.5 + Math.sin(now / 200) * 3, moteY, 1.8 * dpr, 0, Math.PI * 2);
        ctx.fill();
      } else if (tile.type === 'moss') {
        // VŨNG RÊU PHONG (Soft Organic Velvet Moss Cushion)
        ctx.fillStyle = '#14532d';
        ctx.fillRect(px + 2, py + 2, cellW - 4, cellH - 4);
        ctx.fillStyle = '#16a34a';
        ctx.beginPath();
        ctx.ellipse(px + cellW * 0.5, py + cellH * 0.5, cellW * 0.38, cellH * 0.35, 0.2, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = '#4ade80';
        ctx.beginPath();
        ctx.arc(px + cellW * 0.35, py + cellH * 0.4, 3.5 * dpr, 0, Math.PI * 2);
        ctx.arc(px + cellW * 0.65, py + cellH * 0.6, 3 * dpr, 0, Math.PI * 2);
        ctx.arc(px + cellW * 0.5, py + cellH * 0.3, 2.5 * dpr, 0, Math.PI * 2);
        ctx.fill();
        // Dew drop gleam
        ctx.fillStyle = '#f0fdf4';
        ctx.beginPath();
        ctx.arc(px + cellW * 0.33, py + cellH * 0.38, 1 * dpr, 0, Math.PI * 2);
        ctx.fill();
      } else if (tile.type === 'water') {
        // Animated Water with Wave Caustics & Specular Reflection
        const wave = Math.sin(now / 320 + x * 0.8 + y) * 3;
        ctx.fillStyle = '#07253b';
        ctx.fillRect(px + 1, py + 1, cellW - 2, cellH - 2);
        ctx.fillStyle = 'rgba(56, 189, 248, 0.5)';
        ctx.fillRect(px + cellW * 0.1, py + cellH * 0.26 + wave, cellW * 0.52, 2.2 * dpr);
        ctx.fillStyle = 'rgba(125, 211, 252, 0.4)';
        ctx.fillRect(px + cellW * 0.42, py + cellH * 0.62 - wave, cellW * 0.48, 2.2 * dpr);
        ctx.strokeStyle = 'rgba(56, 189, 248, 0.4)';
        ctx.lineWidth = 1 * dpr;
        ctx.strokeRect(px + 1, py + 1, cellW - 2, cellH - 2);
      } else if (tile.type === 'abyss') {
        // Starry Cosmic Void Abyss
        ctx.fillStyle = '#020408';
        ctx.fillRect(px + 1, py + 1, cellW - 2, cellH - 2);
        ctx.strokeStyle = 'rgba(99, 102, 241, 0.4)';
        ctx.lineWidth = 2 * dpr;
        ctx.beginPath();
        ctx.moveTo(px + cellW * 0.2, py + cellH * 0.15);
        ctx.lineTo(px + cellW * 0.55, py + cellH * 0.5);
        ctx.lineTo(px + cellW * 0.35, py + cellH * 0.85);
        ctx.stroke();

        // Shimmering Void Dust
        const starPhase = (now / 1200 + x * 2 + y * 5) % 1;
        ctx.fillStyle = `rgba(192, 132, 252, ${0.3 + starPhase * 0.5})`;
        ctx.beginPath();
        ctx.arc(px + cellW * 0.65, py + cellH * 0.35, 1.8 * dpr, 0, Math.PI * 2);
        ctx.fill();

        // Eerie purple void eyes blinking in abyss!
        const abyssBlink = Math.sin(now / 950 + x * 5 + y * 7) > 0.94;
        if (!abyssBlink && (x + y) % 3 === 0) {
          const eyeY = py + cellH * 0.48;
          ctx.fillStyle = '#c084fc';
          ctx.shadowColor = '#a855f7';
          ctx.shadowBlur = 8 * dpr;
          ctx.beginPath();
          ctx.arc(px + cellW * 0.42, eyeY, 2 * dpr, 0, Math.PI * 2);
          ctx.arc(px + cellW * 0.58, eyeY, 2 * dpr, 0, Math.PI * 2);
          ctx.fill();
          ctx.shadowBlur = 0;
        }
      } else if (tile.type === 'bridge') {
        // Aged Wooden Bridge with Iron Spikes
        ctx.fillStyle = '#3b1c09';
        ctx.fillRect(px + 2, py + cellH * 0.12, cellW - 4, cellH * 0.76);
        ctx.fillStyle = '#78350f';
        for (let i = 1; i <= 4; i++) {
          ctx.fillRect(px + (cellW * i) / 5, py + cellH * 0.15, 3.5 * dpr, cellH * 0.7);
        }
        ctx.fillStyle = '#d97706';
        ctx.fillRect(px + 3, py + cellH * 0.14, cellW - 6, 2 * dpr);
        ctx.fillRect(px + 3, py + cellH * 0.82, cellW - 6, 2 * dpr);
        ctx.strokeStyle = '#92400e';
        ctx.lineWidth = 1 * dpr;
        ctx.strokeRect(px + 2, py + cellH * 0.12, cellW - 4, cellH * 0.76);
      } else if (tile.type === 'lava') {
        // Bubbling Molten Lava with Bursting Gold Core
        const pulse = Math.sin(now / 280 + x * 2 + y) * 0.25 + 0.75;
        ctx.fillStyle = '#450a0a';
        ctx.fillRect(px + 1, py + 1, cellW - 2, cellH - 2);
        ctx.fillStyle = `rgba(239, 68, 68, ${pulse})`;
        ctx.fillRect(px + cellW * 0.1, py + cellH * 0.2, cellW * 0.8, cellH * 0.6);
        ctx.fillStyle = '#f97316';
        ctx.fillRect(px + cellW * 0.25, py + cellH * 0.35, cellW * 0.5, cellH * 0.3);
        const bubbleY = py + cellH * 0.5 + Math.sin(now / 200 + x * 4) * 4;
        ctx.fillStyle = '#fef08a';
        ctx.shadowColor = '#f97316';
        ctx.shadowBlur = 8 * dpr;
        ctx.beginPath();
        ctx.arc(px + cellW * 0.5, bubbleY, 3.5 * dpr, 0, Math.PI * 2);
        ctx.fill();
        ctx.shadowBlur = 0;
      } else if (tile.type === 'trap') {
        const triggered = triggeredTraps.has(key);
        ctx.fillStyle = triggered ? '#1c1917' : '#292524';
        ctx.fillRect(px + cellW * 0.12, py + cellH * 0.12, cellW * 0.76, cellH * 0.76);
        ctx.strokeStyle = triggered ? '#78716c' : '#f59e0b';
        ctx.lineWidth = 2 * dpr;
        ctx.strokeRect(px + cellW * 0.12, py + cellH * 0.12, cellW * 0.76, cellH * 0.76);

        // Sharp iron spikes
        ctx.fillStyle = triggered ? '#dc2626' : '#94a3b8';
        for (let s = 0; s < 4; s++) {
          const sx = px + cellW * (0.28 + (s % 2) * 0.44);
          const sy = py + cellH * (0.28 + Math.floor(s / 2) * 0.44);
          ctx.beginPath();
          ctx.moveTo(sx, sy - 4 * dpr);
          ctx.lineTo(sx + 3 * dpr, sy + 3 * dpr);
          ctx.lineTo(sx - 3 * dpr, sy + 3 * dpr);
          ctx.closePath();
          ctx.fill();
        }
      } else if (tile.type === 'portal') {
        // Swirling Arcane Space Vortex
        const angle = (now / 450) % (Math.PI * 2);
        ctx.fillStyle = '#1e1b4b';
        ctx.fillRect(px + cellW * 0.08, py + cellH * 0.08, cellW * 0.84, cellH * 0.84);
        ctx.strokeStyle = '#a855f7';
        ctx.lineWidth = 3 * dpr;
        ctx.shadowColor = '#c084fc';
        ctx.shadowBlur = 10 * dpr;
        ctx.beginPath();
        ctx.ellipse(px + cellW / 2, py + cellH / 2, cellW * 0.34, cellH * 0.4, angle, 0, Math.PI * 2);
        ctx.stroke();
        ctx.shadowBlur = 0;
        ctx.fillStyle = '#e9d5ff';
        ctx.beginPath();
        ctx.arc(px + cellW / 2, py + cellH / 2, 5 * dpr, 0, Math.PI * 2);
        ctx.fill();
      }
    }

    // 3. Highlight Move Tiles
    for (const tile of moveTiles) {
      const px = tile.x * cellW;
      const py = tile.y * cellH;
      ctx.fillStyle = 'rgba(45, 212, 191, 0.28)';
      ctx.fillRect(px + 2, py + 2, cellW - 4, cellH - 4);
      ctx.strokeStyle = '#2dd4bf';
      ctx.lineWidth = 2 * dpr;
      ctx.strokeRect(px + 3, py + 3, cellW - 6, cellH - 6);
    }

    // 4. Highlight Target Tiles
    for (const tile of targetTiles) {
      const px = tile.x * cellW;
      const py = tile.y * cellH;
      ctx.fillStyle = 'rgba(234, 179, 8, 0.32)';
      ctx.fillRect(px + 2, py + 2, cellW - 4, cellH - 4);
      ctx.strokeStyle = '#facc15';
      ctx.lineWidth = 2.5 * dpr;
      ctx.strokeRect(px + 4, py + 4, cellW - 8, cellH - 8);
    }

    // 5. Draw Walls with biome adaptations, moss, cracks, and lurking eyes!
    for (const wall of walls) {
      const [x, y] = wall.split(',').map(Number);
      const px = x * cellW;
      const py = y * cellH;
      const wallHash = (x * 19 + y * 31) % 11;

      // Base wall block
      ctx.fillStyle = biome === 'abyssal_forge' ? '#241414' : biome === 'mossy_ruins' ? '#18241c' : '#1a202c';
      ctx.fillRect(px + 2, py + 2, cellW - 4, cellH - 4);

      // Top coping stone
      ctx.fillStyle = biome === 'abyssal_forge' ? '#3d2424' : biome === 'mossy_ruins' ? '#28382c' : '#2d3748';
      ctx.fillRect(px + 4, py + 4, cellW - 8, cellH * 0.28);
      ctx.fillStyle = 'rgba(255, 255, 255, 0.08)';
      ctx.fillRect(px + 4, py + 4, cellW - 8, 1.5 * dpr);

      // Mortar line
      ctx.strokeStyle = '#0f172a';
      ctx.lineWidth = 1 * dpr;
      ctx.beginPath();
      ctx.moveTo(px + 4, py + cellH * 0.62);
      ctx.lineTo(px + cellW - 4, py + cellH * 0.62);
      ctx.stroke();

      ctx.strokeStyle = '#475569';
      ctx.lineWidth = 1.5 * dpr;
      ctx.strokeRect(px + 2, py + 2, cellW - 4, cellH - 4);

      // TƯỜNG NỨT NẺ (Cracked Walls in ruins / prison)
      if (wallHash % 3 === 0 || biome === 'mossy_ruins') {
        ctx.strokeStyle = '#070a0e';
        ctx.lineWidth = 1.6 * dpr;
        ctx.beginPath();
        ctx.moveTo(px + cellW * 0.3, py + 4);
        ctx.lineTo(px + cellW * 0.45, py + cellH * 0.4);
        ctx.lineTo(px + cellW * 0.35, py + cellH * 0.7);
        ctx.lineTo(px + cellW * 0.6, py + cellH - 4);
        ctx.stroke();
      }

      // RÊU PHỦ TƯỜNG (Creeping moss over wall)
      if (biome === 'mossy_ruins' || wallHash % 4 === 1) {
        ctx.fillStyle = '#15803d';
        ctx.fillRect(px + 4, py + cellH * 0.75, cellW * 0.4, cellH * 0.2);
        ctx.fillStyle = '#22c55e';
        ctx.beginPath();
        ctx.arc(px + cellW * 0.3, py + cellH * 0.75, 3 * dpr, 0, Math.PI * 2);
        ctx.arc(px + cellW * 0.6, py + cellH * 0.3, 2 * dpr, 0, Math.PI * 2);
        ctx.fill();
      }

      // ÁNH MẮT RÌNH RẬP TRONG KẼ NỨT TƯỜNG (Eyes lurking in cracked stone)
      if (wallHash === 5) {
        const blink = Math.sin(now / 700 + x * 4) > 0.93;
        if (!blink) {
          const eyeColor = biome === 'abyssal_forge' ? '#f43f5e' : biome === 'mossy_ruins' ? '#facc15' : '#38bdf8';
          const eyeY = py + cellH * 0.5;
          const eyeX = px + cellW * 0.5;
          ctx.fillStyle = eyeColor;
          ctx.shadowColor = eyeColor;
          ctx.shadowBlur = 6 * dpr;
          ctx.beginPath();
          ctx.arc(eyeX - 4 * dpr, eyeY, 2 * dpr, 0, Math.PI * 2);
          ctx.arc(eyeX + 4 * dpr, eyeY, 2 * dpr, 0, Math.PI * 2);
          ctx.fill();
          ctx.shadowBlur = 0;
          // Slit pupils
          ctx.fillStyle = '#020617';
          ctx.beginPath();
          ctx.arc(eyeX - 4 * dpr, eyeY, 0.9 * dpr, 0, Math.PI * 2);
          ctx.arc(eyeX + 4 * dpr, eyeY, 0.9 * dpr, 0, Math.PI * 2);
          ctx.fill();
        }
      }

      // Torch Sconces with warm dynamic radial light
      if ((x * 11 + y * 17) % 7 === 0) {
        const torchX = px + cellW / 2;
        const torchY = py + cellH * 0.45;
        const flicker = Math.sin(now / 120 + x * 5) * 1.5;

        // Radiant amber-gold light casting onto floor
        const glow = ctx.createRadialGradient(torchX, torchY, 4, torchX, torchY, cellW * 1.6);
        glow.addColorStop(0, 'rgba(251, 146, 60, 0.38)');
        glow.addColorStop(0.4, 'rgba(245, 158, 11, 0.15)');
        glow.addColorStop(1, 'rgba(0, 0, 0, 0)');
        ctx.fillStyle = glow;
        ctx.beginPath();
        ctx.arc(torchX, torchY, cellW * 1.6, 0, Math.PI * 2);
        ctx.fill();

        // Iron bracket & flame
        ctx.fillStyle = '#1c1917';
        ctx.fillRect(torchX - 2 * dpr, torchY, 4 * dpr, 6 * dpr);
        ctx.fillStyle = '#f97316';
        ctx.beginPath();
        ctx.arc(torchX, torchY - 2 * dpr + flicker, 5 * dpr, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = '#fef08a';
        ctx.beginPath();
        ctx.arc(torchX, torchY - 3 * dpr + flicker, 2.8 * dpr, 0, Math.PI * 2);
        ctx.fill();
      }
    }

    // 6. Draw Exit Door
    const exitPx = EXIT_DOOR.x * cellW;
    const exitPy = EXIT_DOOR.y * cellH;
    const isOpen = phase === 'exiting';
    ctx.fillStyle = isOpen ? 'rgba(251, 191, 36, 0.35)' : '#1e2420';
    ctx.fillRect(exitPx + cellW * 0.15, exitPy + cellH * 0.1, cellW * 0.75, cellH * 0.85);
    ctx.strokeStyle = isOpen ? '#fbbf24' : '#78716c';
    ctx.lineWidth = 3 * dpr;
    ctx.strokeRect(exitPx + cellW * 0.2, exitPy + cellH * 0.15, cellW * 0.65, cellH * 0.8);
    ctx.fillStyle = isOpen ? '#fef08a' : '#44403c';
    ctx.fillRect(exitPx + cellW * 0.3, exitPy + cellH * 0.28, cellW * 0.45, cellH * 0.65);
    if (isOpen) {
      ctx.fillStyle = 'rgba(251, 191, 36, 0.4)';
      ctx.fillRect(exitPx, exitPy, cellW, cellH);
      ctx.fillStyle = '#fef08a';
      ctx.font = `bold ${Math.max(9, Math.floor(cellH * 0.14))}px 'DM Mono', monospace`;
      ctx.textAlign = 'center';
      ctx.fillText('LỐI RA', exitPx + cellW / 2, exitPy + cellH * 0.95);
    }

    // 7. Boss Telegraphs
    if (bossTelegraph.length > 0) {
      const pulse = 0.65 + Math.sin(now / 150) * 0.25;
      for (const t of bossTelegraph) {
        const px = t.x * cellW;
        const py = t.y * cellH;
        ctx.fillStyle =
          t.type === 'roar'
            ? `rgba(168, 85, 247, ${pulse * 0.4})`
            : `rgba(239, 68, 68, ${pulse * 0.45})`;
        ctx.fillRect(px + 2, py + 2, cellW - 4, cellH - 4);
        ctx.strokeStyle = t.type === 'roar' ? '#c084fc' : '#ef4444';
        ctx.lineWidth = 3 * dpr;
        ctx.strokeRect(px + 4, py + 4, cellW - 8, cellH - 8);
        ctx.fillStyle = '#fef2f2';
        ctx.font = `bold ${Math.max(10, Math.floor(cellH * 0.14))}px 'DM Mono', monospace`;
        ctx.textAlign = 'center';
        const label = t.type === 'slap' ? 'VUNG QUANH' : t.type === 'bite' ? 'CẮN XÉ' : 'GẦM VANG';
        ctx.fillText(label, px + cellW / 2, py + cellH * 0.3);
      }
    }

    // 7b. Draw Explosive Barrels (Thùng Thuốc Nổ)
    for (const barrel of barrels) {
      if (barrel.hp <= 0) continue;
      const bpx = barrel.x * cellW;
      const bpy = barrel.y * cellH;
      const bcx = bpx + cellW / 2;
      const bcy = bpy + cellH / 2;

      // Drop shadow
      ctx.fillStyle = 'rgba(0, 0, 0, 0.55)';
      ctx.beginPath();
      ctx.ellipse(bcx, bpy + cellH * 0.85, cellW * 0.28, cellH * 0.08, 0, 0, Math.PI * 2);
      ctx.fill();

      // Barrel Body (Oak Staves with Red Danger Tone)
      const barrelGrad = ctx.createLinearGradient(bcx - cellW * 0.24, bcy, bcx + cellW * 0.24, bcy);
      barrelGrad.addColorStop(0, '#7f1d1d');
      barrelGrad.addColorStop(0.3, '#dc2626');
      barrelGrad.addColorStop(0.7, '#b91c1c');
      barrelGrad.addColorStop(1, '#450a0a');
      ctx.fillStyle = barrelGrad;
      ctx.beginPath();
      ctx.roundRect(bcx - cellW * 0.22, bpy + cellH * 0.26, cellW * 0.44, cellH * 0.56, 6 * dpr);
      ctx.fill();

      // Iron Hoops (Top, Middle, Bottom)
      ctx.strokeStyle = '#0f172a';
      ctx.lineWidth = 2.5 * dpr;
      [0.34, 0.54, 0.74].forEach((ratio) => {
        ctx.beginPath();
        ctx.moveTo(bcx - cellW * 0.22, bpy + cellH * ratio);
        ctx.lineTo(bcx + cellW * 0.22, bpy + cellH * ratio);
        ctx.stroke();
      });

      // Yellow/Orange Flame / TNT Hazard Icon
      ctx.fillStyle = '#fef08a';
      ctx.font = `bold ${Math.max(10, Math.floor(cellH * 0.16))}px 'DM Mono', monospace`;
      ctx.textAlign = 'center';
      ctx.fillText('TNT', bcx, bpy + cellH * 0.54);

      // Glowing Fuse spark on top
      const sparkGlow = 0.5 + Math.sin(now / 120) * 0.3;
      ctx.fillStyle = `rgba(250, 204, 21, ${sparkGlow})`;
      ctx.shadowColor = '#f97316';
      ctx.shadowBlur = 8 * dpr;
      ctx.beginPath();
      ctx.arc(bcx, bpy + cellH * 0.24, 2.5 * dpr, 0, Math.PI * 2);
      ctx.fill();
      ctx.shadowBlur = 0;

      // Small HP Indicator Bar above barrel
      const barW = cellW * 0.36;
      const barH = 3 * dpr;
      const barX = bcx - barW / 2;
      const barY = bpy + cellH * 0.16;
      ctx.fillStyle = 'rgba(0, 0, 0, 0.7)';
      ctx.fillRect(barX, barY, barW, barH);
      ctx.fillStyle = '#ef4444';
      ctx.fillRect(barX, barY, (barrel.hp / barrel.maxHp) * barW, barH);
    }

    // 8. Draw Units with Visual Equipment System!
    const livingUnits = units.filter((u) => u.hp > 0 && !u.inTransit);
    for (const unit of livingUnits) {
      let drawX = unit.x;
      let drawY = unit.y;
      if (unit.animation) {
        const elapsed = now - unit.animation.start;
        const progress = Math.min(1, elapsed / unit.animation.duration);
        drawX = unit.animation.fromX + (unit.animation.toX - unit.animation.fromX) * progress;
        drawY = unit.animation.fromY + (unit.animation.toY - unit.animation.fromY) * progress;
        if (progress >= 1) {
          unit.animation = null;
        }
      }

      // Smooth Strike Lunge & Damage Stagger Combat Animations
      let lungeX = 0;
      let lungeY = 0;
      let hitFlash = 0;
      if (unit.combatAnim) {
        const elapsed = now - unit.combatAnim.startTime;
        const progress = Math.min(1, elapsed / unit.combatAnim.duration);
        if (unit.combatAnim.type === 'lunge') {
          // Smooth sinusoidal strike lunge: pushes forward 32% of a tile towards target, then smoothly eases back
          const lungeDist = Math.sin(progress * Math.PI) * 0.32;
          const targetX = unit.combatAnim.targetX ?? unit.x;
          const targetY = unit.combatAnim.targetY ?? unit.y;
          const dx = targetX - unit.x;
          const dy = targetY - unit.y;
          const dist = Math.hypot(dx, dy) || 1;
          lungeX = (dx / dist) * lungeDist;
          lungeY = (dy / dist) * lungeDist;
        } else if (unit.combatAnim.type === 'hit') {
          // Recoil twitch & rapid jitter away from attacker
          const recoilDist = Math.sin(progress * Math.PI * 3) * (1 - progress) * 0.16;
          const fromX = unit.combatAnim.fromX ?? unit.x;
          const fromY = unit.combatAnim.fromY ?? unit.y;
          const dx = unit.x - fromX;
          const dy = unit.y - fromY;
          const dist = Math.hypot(dx, dy) || 1;
          lungeX = (dx / dist) * recoilDist;
          lungeY = (dy / dist) * recoilDist;
          hitFlash = Math.max(0, (1 - progress) * 0.7); // Bright red hit flash
        }
        if (progress >= 1) {
          unit.combatAnim = null;
        }
      }

      const px = (drawX + lungeX) * cellW;
      const py = (drawY + lungeY) * cellH;
      const centerX = px + cellW / 2;
      const centerY = py + cellH / 2;

      // Active / Selected highlight
      if (unit.id === activeId) {
        ctx.strokeStyle = '#a3e635';
        ctx.lineWidth = 2.5 * dpr;
        ctx.strokeRect(px + 3, py + 3, cellW - 6, cellH - 6);
        ctx.fillStyle = '#a3e635';
        ctx.fillRect(px + cellW / 2 - 4 * dpr, py + 2, 8 * dpr, 4 * dpr);
      }
      if (unit.id === selectedId && unit.id !== activeId) {
        ctx.strokeStyle = '#38bdf8';
        ctx.lineWidth = 2 * dpr;
        ctx.setLineDash([4 * dpr, 4 * dpr]);
        ctx.strokeRect(px + 4, py + 4, cellW - 8, cellH - 8);
        ctx.setLineDash([]);
      }

      // Special Combat Auras: Summoning Ring, Immovable Bastion & Transformations
      if (unit.isSummon) {
        // Cyan Runic Summoning Ring below feet
        ctx.strokeStyle = '#34d399';
        ctx.lineWidth = 2 * dpr;
        ctx.beginPath();
        ctx.ellipse(centerX, py + cellH * 0.82, cellW * 0.36, cellH * 0.14, 0, 0, Math.PI * 2);
        ctx.stroke();
      }

      if (unit.bastionTicks && unit.bastionTicks > 0) {
        // Immovable Bastion Shield Barrier
        ctx.strokeStyle = '#f59e0b';
        ctx.lineWidth = 3.5 * dpr;
        ctx.fillStyle = 'rgba(245, 158, 11, 0.2)';
        ctx.beginPath();
        ctx.arc(centerX, centerY, cellW * 0.46, 0, Math.PI * 2);
        ctx.fill();
        ctx.stroke();
        // Spiked crystal points
        for (let i = 0; i < 6; i++) {
          const a = (i * Math.PI) / 3;
          ctx.fillStyle = '#fbbf24';
          ctx.beginPath();
          ctx.arc(centerX + Math.cos(a) * cellW * 0.46, centerY + Math.sin(a) * cellH * 0.46, 3 * dpr, 0, Math.PI * 2);
          ctx.fill();
        }
      }

      if (unit.transformation) {
        // Elemental Transformation Beast Aura
        const auraColor =
          unit.transformation.type === 'werewolf'
            ? 'rgba(239, 68, 68, 0.35)'
            : unit.transformation.type === 'dragon'
            ? 'rgba(249, 115, 22, 0.35)'
            : 'rgba(148, 163, 184, 0.35)';
        ctx.fillStyle = auraColor;
        ctx.beginPath();
        ctx.arc(centerX, centerY, cellW * (0.45 + Math.sin(now / 200) * 0.05), 0, Math.PI * 2);
        ctx.fill();
      }

      if (unit.petrifiedTicks && unit.petrifiedTicks > 0) {
        // Petrified Stone encasement
        ctx.fillStyle = 'rgba(100, 116, 139, 0.5)';
        ctx.beginPath();
        ctx.arc(centerX, centerY, cellW * 0.44, 0, Math.PI * 2);
        ctx.fill();
      }

      // Check equipped gear on this unit
      const unitGear = equipped[unit.id] || {};
      const heldWeapon = unitGear.weapon;
      const heldShield = unitGear.shield;
      const wornArmor = unitGear.armor;

      // Draw Monster species
      if (unit.species === 'snake') {
        const t = now / 400;
        const auraGrad = ctx.createRadialGradient(centerX, centerY, cellW * 0.2, centerX, centerY, cellW * 0.65);
        auraGrad.addColorStop(0, 'rgba(16, 185, 129, 0.25)');
        auraGrad.addColorStop(0.6, 'rgba(5, 150, 105, 0.12)');
        auraGrad.addColorStop(1, 'rgba(5, 150, 105, 0)');
        ctx.fillStyle = auraGrad;
        ctx.beginPath();
        ctx.arc(centerX, centerY, cellW * 0.65, 0, Math.PI * 2);
        ctx.fill();

        const spine = [
          { x: 0.15, y: 0.8 },
          { x: 0.3, y: 0.78 },
          { x: 0.48, y: 0.82 },
          { x: 0.65, y: 0.75 },
          { x: 0.76, y: 0.58 },
          { x: 0.62, y: 0.46 },
          { x: 0.42, y: 0.48 },
          { x: 0.32, y: 0.38 },
          { x: 0.44, y: 0.26 },
          { x: 0.62, y: 0.26 },
        ];

        spine.forEach((pt, i) => {
          const sway = Math.sin(t + i * 0.4) * (cellW * 0.035);
          const segX = px + cellW * pt.x + sway;
          const segY = py + cellH * pt.y;
          const radius = (cellW * (0.16 + (i / spine.length) * 0.12)) / 2;

          ctx.fillStyle = i % 2 === 0 ? '#044e39' : '#065f46';
          ctx.beginPath();
          ctx.arc(segX, segY, radius, 0, Math.PI * 2);
          ctx.fill();

          ctx.strokeStyle = '#d97706';
          ctx.lineWidth = 1.5 * dpr;
          ctx.stroke();

          ctx.fillStyle = '#10b981';
          ctx.beginPath();
          ctx.arc(segX - radius * 0.2, segY - radius * 0.2, radius * 0.4, 0, Math.PI * 2);
          ctx.fill();
        });

        const headX = px + cellW * 0.62 + Math.sin(t + 4) * (cellW * 0.035);
        const headY = py + cellH * 0.26;

        ctx.fillStyle = '#047857';
        ctx.beginPath();
        ctx.ellipse(headX - cellW * 0.08, headY, cellW * 0.2, cellH * 0.26, 0.2, 0, Math.PI * 2);
        ctx.fill();
        ctx.strokeStyle = '#f59e0b';
        ctx.lineWidth = 2 * dpr;
        ctx.stroke();

        ctx.fillStyle = '#10b981';
        ctx.beginPath();
        ctx.ellipse(headX, headY, cellW * 0.18, cellH * 0.14, 0.1, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = '#ef4444';
        ctx.beginPath();
        ctx.ellipse(headX + cellW * 0.06, headY - cellH * 0.04, 3.5 * dpr, 5 * dpr, 0.2, 0, Math.PI * 2);
        ctx.fill();
      } else if (unit.species === 'kraken') {
        const t = now / 350;
        ctx.fillStyle = 'rgba(0, 0, 0, 0.45)';
        ctx.beginPath();
        ctx.ellipse(centerX, py + cellH * 0.85, cellW * 0.35, cellH * 0.08, 0, 0, Math.PI * 2);
        ctx.fill();

        [-1.3, -0.8, -0.3, 0.3, 0.8, 1.3].forEach((ang, idx) => {
          const wave = Math.sin(t + idx * 0.8) * 0.2;
          ctx.strokeStyle = '#7e22ce';
          ctx.lineWidth = 4 * dpr;
          ctx.lineCap = 'round';
          ctx.beginPath();
          ctx.moveTo(centerX, centerY + cellH * 0.1);
          const midX = centerX + Math.cos(ang + wave) * (cellW * 0.3);
          const midY = centerY + cellH * 0.2 + Math.sin(ang + wave) * (cellH * 0.25);
          const tipX = centerX + Math.cos(ang + wave * 1.5) * (cellW * 0.45);
          const tipY = centerY + cellH * 0.3 + Math.sin(ang + wave * 1.5) * (cellH * 0.38);
          ctx.quadraticCurveTo(midX, midY, tipX, tipY);
          ctx.stroke();
        });

        ctx.fillStyle = '#a855f7';
        ctx.beginPath();
        ctx.ellipse(centerX, centerY - cellH * 0.05, cellW * 0.24, cellH * 0.22, 0, 0, Math.PI * 2);
        ctx.fill();
        ctx.strokeStyle = '#c084fc';
        ctx.lineWidth = 1.5 * dpr;
        ctx.stroke();

        ctx.fillStyle = '#38bdf8';
        ctx.beginPath();
        ctx.arc(centerX, centerY - cellH * 0.05, 6 * dpr, 0, Math.PI * 2);
        ctx.fill();
      } else if (unit.species === 'beholder') {
        const t = now / 300;
        const hover = Math.sin(t) * (cellH * 0.05);
        ctx.fillStyle = 'rgba(0, 0, 0, 0.4)';
        ctx.beginPath();
        ctx.ellipse(centerX, py + cellH * 0.88, cellW * 0.25, cellH * 0.07, 0, 0, Math.PI * 2);
        ctx.fill();

        const beholderY = centerY + hover;
        [-2.2, -1.6, -1.0, -0.4, 0.2].forEach((ang, idx) => {
          const sway = Math.sin(t * 1.5 + idx) * 0.15;
          const stalkX = centerX + Math.cos(ang + sway) * (cellW * 0.28);
          const stalkY = beholderY + Math.sin(ang + sway) * (cellH * 0.25);
          ctx.strokeStyle = '#7c3aed';
          ctx.lineWidth = 3 * dpr;
          ctx.beginPath();
          ctx.moveTo(centerX, beholderY);
          ctx.lineTo(stalkX, stalkY);
          ctx.stroke();
          ctx.fillStyle = '#f43f5e';
          ctx.beginPath();
          ctx.arc(stalkX, stalkY, 3 * dpr, 0, Math.PI * 2);
          ctx.fill();
        });

        ctx.fillStyle = '#6d28d9';
        ctx.beginPath();
        ctx.arc(centerX, beholderY, cellW * 0.22, 0, Math.PI * 2);
        ctx.fill();
        ctx.strokeStyle = '#a78bfa';
        ctx.lineWidth = 2 * dpr;
        ctx.stroke();

        ctx.fillStyle = '#fef08a';
        ctx.beginPath();
        ctx.arc(centerX, beholderY, cellW * 0.1, 0, Math.PI * 2);
        ctx.fill();
      } else if (unit.kind === 'enemy') {
        // Monster humanoid / golem / slime / lich / ghost / shaman
        ctx.save();
        if (unit.phasesWalls) {
          // Ghost ethereal transparency & floating hover
          ctx.globalAlpha = 0.82;
          ctx.shadowColor = '#38bdf8';
          ctx.shadowBlur = 10 * dpr;
        }

        ctx.fillStyle = 'rgba(0, 0, 0, 0.45)';
        ctx.beginPath();
        ctx.ellipse(centerX, py + cellH * 0.85, cellW * 0.28, cellH * 0.08, 0, 0, Math.PI * 2);
        ctx.fill();

        // Shaman War Drum Pulse Ring around feet
        if (unit.shamanAura) {
          const drumWave = (now / 400) % 1;
          ctx.strokeStyle = '#e11d48';
          ctx.lineWidth = 1.5 * dpr;
          ctx.beginPath();
          ctx.ellipse(centerX, py + cellH * 0.85, cellW * 0.32 * drumWave, cellH * 0.1 * drumWave, 0, 0, Math.PI * 2);
          ctx.stroke();
        }

        // Magic Ward Hexagonal Glimmer
        if (unit.magicWard) {
          ctx.strokeStyle = '#c084fc';
          ctx.lineWidth = 1.2 * dpr;
          ctx.beginPath();
          for (let i = 0; i < 6; i++) {
            const ha = (i * Math.PI) / 3;
            const hx = centerX + Math.cos(ha) * cellW * 0.28;
            const hy = py + cellH * 0.5 + Math.sin(ha) * cellH * 0.28;
            if (i === 0) ctx.moveTo(hx, hy);
            else ctx.lineTo(hx, hy);
          }
          ctx.closePath();
          ctx.stroke();
        }

        ctx.fillStyle = unit.color;
        ctx.beginPath();
        ctx.roundRect(centerX - cellW * 0.22, py + cellH * 0.35, cellW * 0.44, cellH * 0.45, 6);
        ctx.fill();

        // Monster head & glowing eyes
        ctx.fillStyle = unit.species === 'lich' ? '#e9d5ff' : '#cbd5e1';
        ctx.beginPath();
        ctx.arc(centerX, py + cellH * 0.3, cellW * 0.15, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = unit.species === 'lich' ? '#a855f7' : unit.species === 'ghost' ? '#38bdf8' : '#ef4444';
        ctx.beginPath();
        ctx.arc(centerX - 3 * dpr, py + cellH * 0.3, 2 * dpr, 0, Math.PI * 2);
        ctx.arc(centerX + 3 * dpr, py + cellH * 0.3, 2 * dpr, 0, Math.PI * 2);
        ctx.fill();

        // Glyph in chest / crown
        ctx.fillStyle = '#ffffff';
        ctx.font = `bold ${Math.max(10, Math.floor(cellH * 0.16))}px 'DM Mono', monospace`;
        ctx.textAlign = 'center';
        ctx.fillText(unit.glyph, centerX, py + cellH * 0.65);

        // Rebirth Undying Soul Ankh indicator
        if (unit.canRebirth && !unit.reborn) {
          ctx.fillStyle = '#c084fc';
          ctx.font = `bold ${Math.max(8, Math.floor(cellH * 0.12))}px 'DM Mono', monospace`;
          ctx.fillText('✦ BẤT TỬ', centerX, py + cellH * 0.18);
        }
        ctx.restore();
      } else {
        // HERO ADVENTURER RENDERING WITH FULL VISUAL EQUIPMENT LAYER!
        // 1. Shadow
        ctx.fillStyle = 'rgba(0, 0, 0, 0.45)';
        ctx.beginPath();
        ctx.ellipse(centerX, py + cellH * 0.86, cellW * 0.28, cellH * 0.08, 0, 0, Math.PI * 2);
        ctx.fill();

        // 2. Cloak / Base Garment
        const cloakColor = unit.cloakColor || unit.color;
        ctx.fillStyle = cloakColor;
        ctx.beginPath();
        ctx.moveTo(centerX - cellW * 0.22, py + cellH * 0.4);
        ctx.lineTo(centerX + cellW * 0.22, py + cellH * 0.4);
        ctx.lineTo(centerX + cellW * 0.27, py + cellH * 0.78);
        ctx.lineTo(centerX, py + cellH * 0.83);
        ctx.lineTo(centerX - cellW * 0.27, py + cellH * 0.78);
        ctx.closePath();
        ctx.fill();

        // 3. VISUAL ARMOR LAYER (Mặc hay trang bị gì thì hiện áo đấy!)
        const armorFam = wornArmor?.armorFamily || (wornArmor?.name.includes('Giáp') || wornArmor?.name.includes('Thép') ? 'iron' : wornArmor?.name.includes('Choàng') ? 'robe' : wornArmor?.name.includes('Kim') ? 'gold' : 'leather');

        if (wornArmor) {
          if (armorFam === 'iron') {
            // Polished Steel Breastplate + Pauldrons
            ctx.fillStyle = '#94a3b8';
            ctx.beginPath();
            ctx.roundRect(centerX - cellW * 0.18, py + cellH * 0.42, cellW * 0.36, cellH * 0.32, 4);
            ctx.fill();
            // Metal sheen
            ctx.fillStyle = '#e2e8f0';
            ctx.fillRect(centerX - cellW * 0.08, py + cellH * 0.44, cellW * 0.16, cellH * 0.28);
            // Steel Pauldrons (Shoulder guards)
            ctx.fillStyle = '#64748b';
            ctx.beginPath();
            ctx.ellipse(centerX - cellW * 0.21, py + cellH * 0.44, cellW * 0.08, cellH * 0.09, -0.2, 0, Math.PI * 2);
            ctx.ellipse(centerX + cellW * 0.21, py + cellH * 0.44, cellW * 0.08, cellH * 0.09, 0.2, 0, Math.PI * 2);
            ctx.fill();
            // Rivet details
            ctx.fillStyle = '#cbd5e1';
            ctx.fillRect(centerX - cellW * 0.22, py + cellH * 0.43, 2 * dpr, 2 * dpr);
            ctx.fillRect(centerX + cellW * 0.2, py + cellH * 0.43, 2 * dpr, 2 * dpr);
          } else if (armorFam === 'robe') {
            // Flowing Arcane Robe with mystical runes
            ctx.fillStyle = '#312e81';
            ctx.beginPath();
            ctx.moveTo(centerX - cellW * 0.2, py + cellH * 0.42);
            ctx.lineTo(centerX + cellW * 0.2, py + cellH * 0.42);
            ctx.lineTo(centerX + cellW * 0.24, py + cellH * 0.79);
            ctx.lineTo(centerX - cellW * 0.24, py + cellH * 0.79);
            ctx.closePath();
            ctx.fill();
            // Gold mystic hem
            ctx.strokeStyle = '#f59e0b';
            ctx.lineWidth = 1.5 * dpr;
            ctx.stroke();
            ctx.strokeStyle = '#38bdf8';
            ctx.lineWidth = 1 * dpr;
            ctx.beginPath();
            ctx.moveTo(centerX, py + cellH * 0.44);
            ctx.lineTo(centerX, py + cellH * 0.76);
            ctx.stroke();
          } else if (armorFam === 'gold') {
            // Royal Gilded Dragon Armor
            ctx.fillStyle = '#f59e0b';
            ctx.beginPath();
            ctx.roundRect(centerX - cellW * 0.19, py + cellH * 0.41, cellW * 0.38, cellH * 0.34, 4);
            ctx.fill();
            // Gilded Pauldrons
            ctx.fillStyle = '#d97706';
            ctx.beginPath();
            ctx.ellipse(centerX - cellW * 0.22, py + cellH * 0.43, cellW * 0.09, cellH * 0.1, -0.3, 0, Math.PI * 2);
            ctx.ellipse(centerX + cellW * 0.22, py + cellH * 0.43, cellW * 0.09, cellH * 0.1, 0.3, 0, Math.PI * 2);
            ctx.fill();
            // Ruby crest in center
            ctx.fillStyle = '#ef4444';
            ctx.beginPath();
            ctx.arc(centerX, py + cellH * 0.52, 3 * dpr, 0, Math.PI * 2);
            ctx.fill();
          } else {
            // Studded Hunter Leather
            ctx.fillStyle = '#78350f';
            ctx.beginPath();
            ctx.roundRect(centerX - cellW * 0.17, py + cellH * 0.43, cellW * 0.34, cellH * 0.31, 3);
            ctx.fill();
            // Leather cross-straps
            ctx.strokeStyle = '#d97706';
            ctx.lineWidth = 1.5 * dpr;
            ctx.beginPath();
            ctx.moveTo(centerX - cellW * 0.14, py + cellH * 0.45);
            ctx.lineTo(centerX + cellW * 0.14, py + cellH * 0.7);
            ctx.stroke();
          }
        }

        // 4. Face & Skin Tone
        const skin = unit.skinTone || '#fed7aa';
        ctx.fillStyle = skin;
        ctx.beginPath();
        ctx.arc(centerX, py + cellH * 0.3, cellW * 0.15, 0, Math.PI * 2);
        ctx.fill();

        // 5. Hair Style & Color
        const hairColor = unit.hairColor || '#1e293b';
        const hairStyle = unit.hairStyle || 'short';
        ctx.fillStyle = hairColor;

        if (hairStyle === 'spiky') {
          ctx.beginPath();
          ctx.moveTo(centerX - cellW * 0.17, py + cellH * 0.3);
          ctx.lineTo(centerX - cellW * 0.12, py + cellH * 0.16);
          ctx.lineTo(centerX - cellW * 0.04, py + cellH * 0.22);
          ctx.lineTo(centerX, py + cellH * 0.14);
          ctx.lineTo(centerX + cellW * 0.06, py + cellH * 0.22);
          ctx.lineTo(centerX + cellW * 0.14, py + cellH * 0.16);
          ctx.lineTo(centerX + cellW * 0.17, py + cellH * 0.3);
          ctx.closePath();
          ctx.fill();
        } else if (hairStyle === 'long' || hairStyle === 'ponytail') {
          ctx.beginPath();
          ctx.arc(centerX, py + cellH * 0.26, cellW * 0.16, Math.PI, Math.PI * 2);
          ctx.lineTo(centerX + cellW * 0.18, py + cellH * 0.44);
          ctx.lineTo(centerX + cellW * 0.12, py + cellH * 0.46);
          ctx.lineTo(centerX - cellW * 0.12, py + cellH * 0.46);
          ctx.lineTo(centerX - cellW * 0.18, py + cellH * 0.44);
          ctx.closePath();
          ctx.fill();
        } else if (hairStyle !== 'bald') {
          // Classic short cropped hair
          ctx.beginPath();
          ctx.arc(centerX, py + cellH * 0.26, cellW * 0.16, Math.PI, Math.PI * 2);
          ctx.lineTo(centerX + cellW * 0.14, py + cellH * 0.31);
          ctx.lineTo(centerX - cellW * 0.14, py + cellH * 0.31);
          ctx.closePath();
          ctx.fill();
        }

        // Eyes
        ctx.fillStyle = '#0f172a';
        ctx.beginPath();
        ctx.arc(centerX - 3 * dpr, py + cellH * 0.3, 1.2 * dpr, 0, Math.PI * 2);
        ctx.arc(centerX + 3 * dpr, py + cellH * 0.3, 1.2 * dpr, 0, Math.PI * 2);
        ctx.fill();

        // 6. VISUAL SHIELD LAYER (Strapped to left arm)
        if (heldShield) {
          const shieldX = centerX - cellW * 0.27;
          const shieldY = py + cellH * 0.52;
          const shieldFam = heldShield.shieldFamily || (heldShield.name.includes('Aegis') ? 'aegis' : heldShield.name.includes('Tròn') ? 'buckler' : 'iron');

          if (shieldFam === 'aegis') {
            // Glowing Aegis Tower Shield
            ctx.fillStyle = '#38bdf8';
            ctx.strokeStyle = '#facc15';
            ctx.lineWidth = 2 * dpr;
            ctx.beginPath();
            ctx.roundRect(shieldX - cellW * 0.08, shieldY - cellH * 0.18, cellW * 0.16, cellH * 0.36, 4);
            ctx.fill();
            ctx.stroke();
            // Golden cross
            ctx.fillStyle = '#fef08a';
            ctx.fillRect(shieldX - 1.5 * dpr, shieldY - cellH * 0.14, 3 * dpr, cellH * 0.28);
            ctx.fillRect(shieldX - cellW * 0.06, shieldY - 1.5 * dpr, cellW * 0.12, 3 * dpr);
          } else if (shieldFam === 'buckler') {
            // Bronze Buckler
            ctx.fillStyle = '#b45309';
            ctx.beginPath();
            ctx.arc(shieldX, shieldY, cellW * 0.11, 0, Math.PI * 2);
            ctx.fill();
            ctx.strokeStyle = '#f59e0b';
            ctx.lineWidth = 2 * dpr;
            ctx.stroke();
            ctx.fillStyle = '#fef3c7';
            ctx.beginPath();
            ctx.arc(shieldX, shieldY, 3 * dpr, 0, Math.PI * 2);
            ctx.fill();
          } else {
            // Heater Iron Shield
            ctx.fillStyle = '#64748b';
            ctx.beginPath();
            ctx.moveTo(shieldX - cellW * 0.08, shieldY - cellH * 0.14);
            ctx.lineTo(shieldX + cellW * 0.08, shieldY - cellH * 0.14);
            ctx.lineTo(shieldX + cellW * 0.08, shieldY + cellH * 0.08);
            ctx.lineTo(shieldX, shieldY + cellH * 0.18);
            ctx.lineTo(shieldX - cellW * 0.08, shieldY + cellH * 0.08);
            ctx.closePath();
            ctx.fill();
            ctx.strokeStyle = '#cbd5e1';
            ctx.lineWidth = 1.5 * dpr;
            ctx.stroke();
          }
        }

        // 7. VISUAL WEAPON LAYER (In Right Hand)
        if (heldWeapon) {
          const weaponX = centerX + cellW * 0.24;
          const weaponY = py + cellH * 0.52;
          const fam = heldWeapon.family || 'sword';

          ctx.save();
          if (fam === 'sword') {
            // Silver Steel Sword Blade
            ctx.strokeStyle = '#cbd5e1';
            ctx.lineWidth = 3 * dpr;
            ctx.lineCap = 'round';
            ctx.beginPath();
            ctx.moveTo(weaponX, weaponY + cellH * 0.12);
            ctx.lineTo(weaponX + cellW * 0.12, weaponY - cellH * 0.28);
            ctx.stroke();
            // Golden crossguard
            ctx.strokeStyle = '#f59e0b';
            ctx.lineWidth = 2 * dpr;
            ctx.beginPath();
            ctx.moveTo(weaponX - 4 * dpr, weaponY + cellH * 0.06);
            ctx.lineTo(weaponX + 8 * dpr, weaponY + cellH * 0.02);
            ctx.stroke();
          } else if (fam === 'axe') {
            // Heavy Battleaxe
            ctx.strokeStyle = '#78350f';
            ctx.lineWidth = 2.5 * dpr;
            ctx.beginPath();
            ctx.moveTo(weaponX, weaponY + cellH * 0.15);
            ctx.lineTo(weaponX + cellW * 0.08, weaponY - cellH * 0.25);
            ctx.stroke();
            // Double iron blade head
            ctx.fillStyle = '#94a3b8';
            ctx.beginPath();
            ctx.arc(weaponX + cellW * 0.08, weaponY - cellH * 0.2, cellW * 0.11, -Math.PI * 0.8, Math.PI * 0.3);
            ctx.fill();
          } else if (fam === 'hammer') {
            // Warhammer Head
            ctx.strokeStyle = '#78350f';
            ctx.lineWidth = 2.5 * dpr;
            ctx.beginPath();
            ctx.moveTo(weaponX, weaponY + cellH * 0.15);
            ctx.lineTo(weaponX + cellW * 0.06, weaponY - cellH * 0.22);
            ctx.stroke();
            ctx.fillStyle = '#475569';
            ctx.fillRect(weaponX + cellW * 0.02, weaponY - cellH * 0.28, cellW * 0.14, cellH * 0.12);
          } else if (fam === 'bow') {
            // Recurve Bow
            ctx.strokeStyle = '#d97706';
            ctx.lineWidth = 2.5 * dpr;
            ctx.beginPath();
            ctx.arc(weaponX + cellW * 0.06, weaponY - cellH * 0.05, cellW * 0.18, -1.2, 1.2);
            ctx.stroke();
            // String
            ctx.strokeStyle = '#f1f5f9';
            ctx.lineWidth = 1 * dpr;
            ctx.beginPath();
            ctx.moveTo(weaponX + cellW * 0.06 + Math.cos(-1.2) * (cellW * 0.18), weaponY - cellH * 0.05 + Math.sin(-1.2) * (cellW * 0.18));
            ctx.lineTo(weaponX + cellW * 0.06 + Math.cos(1.2) * (cellW * 0.18), weaponY - cellH * 0.05 + Math.sin(1.2) * (cellW * 0.18));
            ctx.stroke();
          } else if (fam === 'crossbow') {
            // Heavy Crossbow
            ctx.fillStyle = '#78350f';
            ctx.fillRect(weaponX - 2 * dpr, weaponY - cellH * 0.12, 4 * dpr, cellH * 0.25);
            ctx.strokeStyle = '#64748b';
            ctx.lineWidth = 2.5 * dpr;
            ctx.beginPath();
            ctx.moveTo(weaponX - cellW * 0.1, weaponY - cellH * 0.1);
            ctx.lineTo(weaponX + cellW * 0.12, weaponY - cellH * 0.1);
            ctx.stroke();
          } else if (fam === 'dagger') {
            // Dual Daggers
            ctx.strokeStyle = '#38bdf8';
            ctx.lineWidth = 2 * dpr;
            ctx.beginPath();
            ctx.moveTo(weaponX, weaponY);
            ctx.lineTo(weaponX + cellW * 0.1, weaponY - cellH * 0.14);
            ctx.moveTo(weaponX - cellW * 0.05, weaponY + cellH * 0.05);
            ctx.lineTo(weaponX + cellW * 0.05, weaponY - cellH * 0.08);
            ctx.stroke();
          } else if (fam === 'spear') {
            // Long spear
            ctx.strokeStyle = '#92400e';
            ctx.lineWidth = 2 * dpr;
            ctx.beginPath();
            ctx.moveTo(weaponX - cellW * 0.05, weaponY + cellH * 0.2);
            ctx.lineTo(weaponX + cellW * 0.18, weaponY - cellH * 0.35);
            ctx.stroke();
            // Silver Spearhead
            ctx.fillStyle = '#e2e8f0';
            ctx.beginPath();
            ctx.moveTo(weaponX + cellW * 0.18, weaponY - cellH * 0.35);
            ctx.lineTo(weaponX + cellW * 0.22, weaponY - cellH * 0.44);
            ctx.lineTo(weaponX + cellW * 0.26, weaponY - cellH * 0.35);
            ctx.closePath();
            ctx.fill();
          } else if (fam === 'staff') {
            // Staff with glowing magic orb
            ctx.strokeStyle = '#92400e';
            ctx.lineWidth = 2.5 * dpr;
            ctx.beginPath();
            ctx.moveTo(weaponX, weaponY + cellH * 0.2);
            ctx.lineTo(weaponX + cellW * 0.08, weaponY - cellH * 0.3);
            ctx.stroke();
            // Glowing magical crystal orb
            ctx.fillStyle = '#38bdf8';
            ctx.shadowColor = '#38bdf8';
            ctx.shadowBlur = 8 * dpr;
            ctx.beginPath();
            ctx.arc(weaponX + cellW * 0.08, weaponY - cellH * 0.3, 5 * dpr, 0, Math.PI * 2);
            ctx.fill();
            ctx.shadowBlur = 0;
          } else if (fam === 'tome') {
            // Floating Arcane Spellbook
            const floatHover = Math.sin(now / 200) * 3;
            ctx.fillStyle = '#7e22ce';
            ctx.fillRect(weaponX, weaponY - cellH * 0.15 + floatHover, cellW * 0.14, cellH * 0.18);
            ctx.strokeStyle = '#fbbf24';
            ctx.lineWidth = 1 * dpr;
            ctx.strokeRect(weaponX, weaponY - cellH * 0.15 + floatHover, cellW * 0.14, cellH * 0.18);
            // Glowing page text
            ctx.fillStyle = '#38bdf8';
            ctx.fillRect(weaponX + 2 * dpr, weaponY - cellH * 0.1 + floatHover, cellW * 0.1, 2 * dpr);
          } else if (fam === 'bell') {
            // Holy Golden Bell
            ctx.fillStyle = '#f59e0b';
            ctx.beginPath();
            ctx.arc(weaponX + cellW * 0.05, weaponY - cellH * 0.05, 5 * dpr, Math.PI, Math.PI * 2);
            ctx.lineTo(weaponX + cellW * 0.09, weaponY + 4 * dpr);
            ctx.lineTo(weaponX + 2 * dpr, weaponY + 4 * dpr);
            ctx.closePath();
            ctx.fill();
          }
          ctx.restore();
        }

        // 8. VISUAL RING AURA
        if (unitGear.ring) {
          const ringGlow = Math.sin(now / 250) * 0.4 + 0.6;
          ctx.fillStyle = `rgba(250, 204, 21, ${ringGlow})`;
          ctx.beginPath();
          ctx.arc(centerX + cellW * 0.22, py + cellH * 0.58, 2 * dpr, 0, Math.PI * 2);
          ctx.fill();
        }
      }

      // Unit Health Bar
      const eff = getEffectiveStats(unit);
      const barW = unit.boss ? cellW * 0.88 : cellW * 0.72;
      const barH = (unit.boss ? 6 : 5) * dpr;
      const bx = centerX - barW / 2;
      const by = py + cellH * 0.07;

      ctx.fillStyle = '#0f172a';
      ctx.fillRect(bx, by, barW, barH);
      const hpPercent = Math.max(0, Math.min(1, unit.hp / eff.hp));
      ctx.fillStyle =
        unit.kind === 'hero'
          ? hpPercent < 0.3
            ? '#ef4444'
            : '#22c55e'
          : '#f87171';
      ctx.fillRect(bx, by, barW * hpPercent, barH);

      if (unit.guard > 0) {
        ctx.strokeStyle = '#38bdf8';
        ctx.lineWidth = 1.5 * dpr;
        ctx.strokeRect(bx - 1, by - 1, barW + 2, barH + 2);
      }

      // Unit Name
      ctx.fillStyle = unit.kind === 'hero' ? '#f1f5f9' : '#fecaca';
      ctx.font = `bold ${Math.max(9, Math.floor(cellH * 0.12))}px 'DM Mono', monospace`;
      ctx.textAlign = 'center';
      ctx.fillText(unit.name, centerX, py + cellH * 0.96);

      // Status Badges (Stun, Poison, Burn, Petrify, Bastion, Transform, Summon)
      let badgeX = centerX - cellW * 0.38;
      const badgeY = py + cellH * 0.22;
      if (unit.petrifiedTicks && unit.petrifiedTicks > 0) {
        ctx.fillStyle = '#64748b';
        ctx.fillRect(badgeX - 2 * dpr, badgeY - 5 * dpr, 26 * dpr, 10 * dpr);
        ctx.strokeStyle = '#cbd5e1';
        ctx.lineWidth = 1 * dpr;
        ctx.strokeRect(badgeX - 2 * dpr, badgeY - 5 * dpr, 26 * dpr, 10 * dpr);
        ctx.fillStyle = '#f8fafc';
        ctx.font = `bold ${7 * dpr}px 'DM Mono', monospace`;
        ctx.textAlign = 'left';
        ctx.fillText('ĐÁ', badgeX + 3 * dpr, badgeY + 3 * dpr);
        badgeX += 28 * dpr;
      }
      if (unit.bastionTicks && unit.bastionTicks > 0) {
        ctx.fillStyle = '#b45309';
        ctx.fillRect(badgeX - 2 * dpr, badgeY - 5 * dpr, 34 * dpr, 10 * dpr);
        ctx.strokeStyle = '#f59e0b';
        ctx.lineWidth = 1 * dpr;
        ctx.strokeRect(badgeX - 2 * dpr, badgeY - 5 * dpr, 34 * dpr, 10 * dpr);
        ctx.fillStyle = '#fef3c7';
        ctx.font = `bold ${7 * dpr}px 'DM Mono', monospace`;
        ctx.textAlign = 'left';
        ctx.fillText('THỦ KIÊN', badgeX + 1 * dpr, badgeY + 3 * dpr);
        badgeX += 36 * dpr;
      }
      if (unit.transformation) {
        ctx.fillStyle = '#991b1b';
        ctx.fillRect(badgeX - 2 * dpr, badgeY - 5 * dpr, 36 * dpr, 10 * dpr);
        ctx.strokeStyle = '#f87171';
        ctx.lineWidth = 1 * dpr;
        ctx.strokeRect(badgeX - 2 * dpr, badgeY - 5 * dpr, 36 * dpr, 10 * dpr);
        ctx.fillStyle = '#fef2f2';
        ctx.font = `bold ${7 * dpr}px 'DM Mono', monospace`;
        ctx.textAlign = 'left';
        ctx.fillText('HÓA THÂN', badgeX + 1 * dpr, badgeY + 3 * dpr);
        badgeX += 38 * dpr;
      }
      if (unit.isSummon) {
        ctx.fillStyle = '#065f46';
        ctx.fillRect(badgeX - 2 * dpr, badgeY - 5 * dpr, 32 * dpr, 10 * dpr);
        ctx.strokeStyle = '#34d399';
        ctx.lineWidth = 1 * dpr;
        ctx.strokeRect(badgeX - 2 * dpr, badgeY - 5 * dpr, 32 * dpr, 10 * dpr);
        ctx.fillStyle = '#ecfdf5';
        ctx.font = `bold ${7 * dpr}px 'DM Mono', monospace`;
        ctx.textAlign = 'left';
        ctx.fillText('TRIỆU HỒI', badgeX + 1 * dpr, badgeY + 3 * dpr);
        badgeX += 34 * dpr;
      }
      if (unit.stun && unit.stun > 0) {
        ctx.fillStyle = '#facc15';
        ctx.beginPath();
        ctx.arc(badgeX, badgeY, 4 * dpr, 0, Math.PI * 2);
        ctx.fill();
        badgeX += 9 * dpr;
      }
      if (unit.poisonTicks && unit.poisonTicks > 0) {
        ctx.fillStyle = '#a855f7';
        ctx.beginPath();
        ctx.arc(badgeX, badgeY, 4 * dpr, 0, Math.PI * 2);
        ctx.fill();
        badgeX += 9 * dpr;
      }
      if (unit.burnTicks && unit.burnTicks > 0) {
        ctx.fillStyle = '#f97316';
        ctx.beginPath();
        ctx.arc(badgeX, badgeY, 4 * dpr, 0, Math.PI * 2);
        ctx.fill();
        badgeX += 9 * dpr;
      }

      // Red Hit Flash Overlay on Unit
      if (hitFlash > 0) {
        ctx.save();
        ctx.fillStyle = `rgba(239, 68, 68, ${hitFlash})`;
        ctx.beginPath();
        ctx.arc(centerX, centerY, cellW * 0.38, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      }

      // Spinning Stun Stars overhead
      if (unit.isStunned || (unit.stunTicks || 0) > 0 || (unit.stun || 0) > 0) {
        ctx.save();
        const starTime = now / 140;
        for (let i = 0; i < 3; i++) {
          const sa = starTime + (i * Math.PI * 2) / 3;
          const sx = centerX + Math.cos(sa) * (cellW * 0.22);
          const sy = py + cellH * 0.18 + Math.sin(sa) * (cellH * 0.08);
          ctx.fillStyle = '#facc15';
          ctx.beginPath();
          ctx.arc(sx, sy, 2.5 * dpr, 0, Math.PI * 2);
          ctx.fill();
        }
        ctx.fillStyle = '#fef08a';
        ctx.font = `bold ${Math.max(8, Math.floor(cellH * 0.12))}px 'DM Mono', monospace`;
        ctx.textAlign = 'center';
        ctx.fillText('💫 CHOÁNG', centerX, py + cellH * 0.12);
        ctx.restore();
      }

      // Frozen Ice Block Overlay
      if (unit.frozenTicks && unit.frozenTicks > 0) {
        ctx.save();
        ctx.strokeStyle = '#38bdf8';
        ctx.lineWidth = 2 * dpr;
        ctx.fillStyle = 'rgba(56, 189, 248, 0.25)';
        ctx.beginPath();
        ctx.roundRect(px + 4, py + 4, cellW - 8, cellH - 8, 4);
        ctx.fill();
        ctx.stroke();
        ctx.fillStyle = '#e0f2fe';
        ctx.font = `bold ${Math.max(8, Math.floor(cellH * 0.12))}px 'DM Mono', monospace`;
        ctx.textAlign = 'center';
        ctx.fillText('❄ ĐÓNG BĂNG', centerX, py + cellH * 0.14);
        ctx.restore();
      }

      // High Ground Tag badge on unit
      if (unit.elevation === 1) {
        ctx.fillStyle = '#38bdf8';
        ctx.font = `bold ${Math.max(8, Math.floor(cellH * 0.11))}px 'DM Mono', monospace`;
        ctx.textAlign = 'right';
        ctx.fillText('▲', px + cellW - 4 * dpr, py + 12 * dpr);
      }
    }

    // 9. Combat Visual Effects & Floating Damage
    for (const fx of visualEffects) {
      const elapsed = now - fx.start;
      if (elapsed > fx.duration) continue;
      const progress = Math.min(1, elapsed / fx.duration);
      const startX = (fx.fromX + 0.5) * cellW;
      const startY = (fx.fromY + 0.5) * cellH;
      const targetX = (fx.toX + 0.5) * cellW;
      const targetY = (fx.toY + 0.5) * cellH;

      ctx.save();
      if (fx.type === 'stat_up') {
        // Floating Stat Increase Notification
        const floatY = targetY - cellH * (0.3 + progress * 0.4);
        ctx.fillStyle = '#090d16';
        ctx.fillRect(targetX - 55 * dpr, floatY - 10 * dpr, 110 * dpr, 20 * dpr);
        ctx.strokeStyle = fx.color || '#facc15';
        ctx.lineWidth = 1.5 * dpr;
        ctx.strokeRect(targetX - 55 * dpr, floatY - 10 * dpr, 110 * dpr, 20 * dpr);
        ctx.fillStyle = fx.color || '#facc15';
        ctx.font = `bold ${Math.max(10, Math.floor(cellH * 0.16))}px 'DM Mono', monospace`;
        ctx.textAlign = 'center';
        ctx.fillText(fx.floatingText || '+1 ĐIỂM', targetX, floatY + 4 * dpr);
      } else if (fx.type === 'meteor') {
        // Giant Falling Meteor with Flaming Impact Crater
        const dropProgress = Math.min(1, progress * 1.5);
        const curX = targetX - (1 - dropProgress) * (cellW * 0.6);
        const curY = targetY - (1 - dropProgress) * (cellH * 1.8);
        
        // Meteor core
        const grad = ctx.createRadialGradient(curX, curY, 2 * dpr, curX, curY, 18 * dpr);
        grad.addColorStop(0, '#fef08a');
        grad.addColorStop(0.4, '#f97316');
        grad.addColorStop(1, 'rgba(239, 68, 68, 0)');
        ctx.fillStyle = grad;
        ctx.beginPath();
        ctx.arc(curX, curY, 18 * dpr, 0, Math.PI * 2);
        ctx.fill();

        // Impact Shockwave
        if (dropProgress >= 0.8) {
          const impactProg = (dropProgress - 0.8) / 0.2;
          ctx.strokeStyle = '#fb923c';
          ctx.lineWidth = (4 - impactProg * 3) * dpr;
          ctx.beginPath();
          ctx.arc(targetX, targetY, impactProg * cellW * 0.85, 0, Math.PI * 2);
          ctx.stroke();
        }
      } else if (fx.type === 'lightning') {
        // Branching Electrical Lightning Bolt
        ctx.strokeStyle = fx.color || '#38bdf8';
        ctx.lineWidth = 3 * dpr;
        ctx.shadowColor = '#38bdf8';
        ctx.shadowBlur = 12 * dpr;
        ctx.beginPath();
        ctx.moveTo(startX, startY);
        const midX = (startX + targetX) / 2 + (Math.random() - 0.5) * 20 * dpr;
        const midY = (startY + targetY) / 2 + (Math.random() - 0.5) * 20 * dpr;
        ctx.lineTo(midX, midY);
        ctx.lineTo(targetX, targetY);
        ctx.stroke();
        ctx.shadowBlur = 0;
      } else if (fx.type === 'thorns') {
        // Retaliatory Thorns Burst
        ctx.strokeStyle = '#ef4444';
        ctx.lineWidth = 2.5 * dpr;
        for (let a = 0; a < Math.PI * 2; a += Math.PI / 4) {
          const len = (8 + Math.sin(progress * Math.PI) * 16) * dpr;
          ctx.beginPath();
          ctx.moveTo(startX, startY);
          ctx.lineTo(startX + Math.cos(a) * len, startY + Math.sin(a) * len);
          ctx.stroke();
        }
      } else if (fx.type === 'transform') {
        // Swirling Transformation Vortex
        const radius = (cellW * 0.45) * (0.8 + Math.sin(progress * Math.PI * 2) * 0.2);
        ctx.strokeStyle = fx.color || '#ef4444';
        ctx.lineWidth = 3 * dpr;
        ctx.shadowColor = fx.color || '#ef4444';
        ctx.shadowBlur = 10 * dpr;
        ctx.beginPath();
        ctx.arc(targetX, targetY, radius, progress * 4, progress * 4 + Math.PI * 1.5);
        ctx.stroke();
        ctx.shadowBlur = 0;
      } else if (fx.type === 'summon') {
        // Runic Summoning Circle
        ctx.strokeStyle = '#34d399';
        ctx.lineWidth = 2.5 * dpr;
        ctx.beginPath();
        ctx.arc(targetX, targetY, cellW * 0.4 * progress, 0, Math.PI * 2);
        ctx.stroke();
      } else if (fx.type === 'petrify') {
        // Stone beam
        ctx.strokeStyle = '#94a3b8';
        ctx.lineWidth = 4 * dpr;
        ctx.beginPath();
        ctx.moveTo(startX, startY);
        ctx.lineTo(targetX, targetY);
        ctx.stroke();
      } else if (fx.type === 'reborn') {
        // Lich / Undying Fiend Rebirth Shockwave & Soul Ascension
        const ringRadius = cellW * 0.9 * progress;
        ctx.strokeStyle = '#c084fc';
        ctx.lineWidth = (4 - progress * 3) * dpr;
        ctx.shadowColor = '#a855f7';
        ctx.shadowBlur = 15 * dpr;
        ctx.beginPath();
        ctx.arc(targetX, targetY, ringRadius, 0, Math.PI * 2);
        ctx.stroke();

        // Rising Spirit Souls & Frost Shards
        for (let i = 0; i < 8; i++) {
          const angle = (i * Math.PI) / 4;
          const dist = (cellW * 0.35 + Math.sin(progress * Math.PI) * 12) * dpr;
          const px = targetX + Math.cos(angle) * dist;
          const py = targetY + Math.sin(angle) * dist - progress * 28 * dpr;
          ctx.fillStyle = i % 2 === 0 ? '#38bdf8' : '#e9d5ff';
          ctx.beginPath();
          ctx.arc(px, py, (3 - progress * 2) * dpr, 0, Math.PI * 2);
          ctx.fill();
        }
        ctx.shadowBlur = 0;
      } else if (fx.type === 'buff_aura') {
        // Shaman War Drum Soundwaves & Ally Runic Blessing
        const auraProg = (progress * 1.8) % 1;
        ctx.strokeStyle = '#f43f5e';
        ctx.lineWidth = (3 - auraProg * 2) * dpr;
        ctx.beginPath();
        ctx.arc(targetX, targetY, auraProg * cellW * 0.8, 0, Math.PI * 2);
        ctx.stroke();

        ctx.strokeStyle = '#fbbf24';
        ctx.lineWidth = (2 - auraProg * 1.5) * dpr;
        ctx.beginPath();
        ctx.arc(targetX, targetY, ((auraProg + 0.3) % 1) * cellW * 0.6, 0, Math.PI * 2);
        ctx.stroke();
      } else if (fx.type === 'magic_reflect') {
        // Prismatic Hexagonal Spell Reflection Barrier
        const hexSize = cellW * 0.45;
        ctx.strokeStyle = '#38bdf8';
        ctx.lineWidth = 3 * dpr;
        ctx.shadowColor = '#38bdf8';
        ctx.shadowBlur = 10 * dpr;
        ctx.beginPath();
        for (let i = 0; i < 6; i++) {
          const a = (i * Math.PI) / 3;
          const hx = targetX + Math.cos(a) * hexSize;
          const hy = targetY + Math.sin(a) * hexSize;
          if (i === 0) ctx.moveTo(hx, hy);
          else ctx.lineTo(hx, hy);
        }
        ctx.closePath();
        ctx.stroke();
        ctx.shadowBlur = 0;
      } else if (fx.type === 'barrel_explosion') {
        // Massive Barrel TNT Blast: Expanding fiery ring + smoke and flying shrapnel
        const blastRadius = cellW * 1.4 * progress;
        const blastGrad = ctx.createRadialGradient(targetX, targetY, 2 * dpr, targetX, targetY, blastRadius);
        blastGrad.addColorStop(0, '#fef08a');
        blastGrad.addColorStop(0.3, '#f97316');
        blastGrad.addColorStop(0.7, '#dc2626');
        blastGrad.addColorStop(1, 'rgba(69, 10, 10, 0)');
        ctx.fillStyle = blastGrad;
        ctx.beginPath();
        ctx.arc(targetX, targetY, blastRadius, 0, Math.PI * 2);
        ctx.fill();

        // Expanding shockwave ring
        ctx.strokeStyle = '#fef08a';
        ctx.lineWidth = (4 - progress * 3) * dpr;
        ctx.beginPath();
        ctx.arc(targetX, targetY, cellW * 1.6 * progress, 0, Math.PI * 2);
        ctx.stroke();

        // Flying wood shrapnel particles
        for (let i = 0; i < 8; i++) {
          const a = (i * Math.PI) / 4 + progress * 2;
          const dist = cellW * (0.3 + progress * 0.9);
          const px = targetX + Math.cos(a) * dist;
          const py = targetY + Math.sin(a) * dist;
          ctx.fillStyle = '#78350f';
          ctx.fillRect(px - 3 * dpr, py - 3 * dpr, 6 * dpr, 6 * dpr);
        }
      } else if (fx.type === 'wall_slam') {
        // Wall Impact Fracture Lines & Heavy Dust Shockwave
        ctx.strokeStyle = '#f59e0b';
        ctx.lineWidth = 3.5 * dpr;
        ctx.shadowColor = '#f59e0b';
        ctx.shadowBlur = 8 * dpr;
        for (let i = 0; i < 6; i++) {
          const a = (i * Math.PI) / 3;
          const dist = (8 + progress * cellW * 0.45) * dpr;
          ctx.beginPath();
          ctx.moveTo(targetX, targetY);
          ctx.lineTo(targetX + Math.cos(a) * dist, targetY + Math.sin(a) * dist);
          ctx.stroke();
        }
        ctx.shadowBlur = 0;
      } else if (fx.type === 'shatter') {
        // Ice Shatter Crystal Splinters
        ctx.fillStyle = '#38bdf8';
        ctx.strokeStyle = '#e0f2fe';
        ctx.lineWidth = 1.5 * dpr;
        for (let i = 0; i < 8; i++) {
          const a = (i * Math.PI) / 4;
          const dist = cellW * (0.2 + progress * 0.7);
          const px = targetX + Math.cos(a) * dist;
          const py = targetY + Math.sin(a) * dist;
          ctx.beginPath();
          ctx.moveTo(px, py - 4 * dpr);
          ctx.lineTo(px + 4 * dpr, py);
          ctx.lineTo(px, py + 4 * dpr);
          ctx.lineTo(px - 4 * dpr, py);
          ctx.closePath();
          ctx.fill();
          ctx.stroke();
        }
      } else if (fx.type === 'claw3') {
        // 3 Parallel Savage Beast Claw Tears
        ctx.strokeStyle = '#ef4444';
        ctx.lineWidth = 3 * dpr;
        ctx.lineCap = 'round';
        const offsets = [-8 * dpr, 0, 8 * dpr];
        offsets.forEach((off) => {
          ctx.beginPath();
          ctx.moveTo(targetX - 16 * dpr + off, targetY - 14 * dpr * progress);
          ctx.lineTo(targetX + 16 * dpr + off, targetY + 14 * dpr * progress);
          ctx.stroke();
        });
      } else if (fx.type === 'bash') {
        // Crushing Hammer Impact: Stone Fissure Ground Cracks & Shockwave
        ctx.strokeStyle = '#d97706';
        ctx.lineWidth = (3.5 - progress * 2) * dpr;
        ctx.lineCap = 'round';
        // Branching ground fissures in 4 directions
        const branches = [
          [0, -1],
          [1, 0],
          [0, 1],
          [-1, 0],
          [0.7, 0.7],
          [-0.7, -0.7],
        ];
        branches.forEach(([dx, dy]) => {
          ctx.beginPath();
          ctx.moveTo(targetX, targetY);
          const midX = targetX + dx * cellW * 0.25 * progress + (Math.sin(dx * 4) * 5 * dpr);
          const midY = targetY + dy * cellH * 0.25 * progress + (Math.cos(dy * 4) * 5 * dpr);
          const endX = targetX + dx * cellW * 0.48 * progress;
          const endY = targetY + dy * cellH * 0.48 * progress;
          ctx.lineTo(midX, midY);
          ctx.lineTo(endX, endY);
          ctx.stroke();
        });
        // Dust shockwave ring
        ctx.strokeStyle = '#a8a29e';
        ctx.lineWidth = 2 * dpr;
        ctx.beginPath();
        ctx.arc(targetX, targetY, progress * cellW * 0.55, 0, Math.PI * 2);
        ctx.stroke();
      } else if (fx.type === 'strike') {
        // High-Velocity Curved Crescent Blade Slash Wave
        const angle = Math.atan2(targetY - startY, targetX - startX);
        const slashRadius = cellW * 0.42;
        const swingAngle = angle - Math.PI * 0.45 + progress * Math.PI * 0.9;

        ctx.save();
        ctx.translate(targetX, targetY);
        // Crescent Blade Trail
        ctx.strokeStyle = fx.color || '#f8fafc';
        ctx.lineWidth = (4 - progress * 2.5) * dpr;
        ctx.lineCap = 'round';
        ctx.shadowColor = fx.color || '#38bdf8';
        ctx.shadowBlur = 8 * dpr;
        ctx.beginPath();
        ctx.arc(0, 0, slashRadius, swingAngle - 0.55, swingAngle + 0.55);
        ctx.stroke();

        // White-hot blade inner core
        ctx.strokeStyle = '#ffffff';
        ctx.lineWidth = 1.5 * dpr;
        ctx.beginPath();
        ctx.arc(0, 0, slashRadius, swingAngle - 0.25, swingAngle + 0.25);
        ctx.stroke();

        // Hit Sparks Burst along edge
        if (progress > 0.4) {
          ctx.fillStyle = '#fef08a';
          for (let s = 0; s < 4; s++) {
            const spDist = slashRadius + (s * 4 + 2) * dpr;
            const spAngle = swingAngle + (s - 1.5) * 0.25;
            ctx.fillRect(Math.cos(spAngle) * spDist, Math.sin(spAngle) * spDist, 2.5 * dpr, 2.5 * dpr);
          }
        }
        ctx.restore();
      } else if (fx.type === 'arrow') {
        // Drawn Wooden Arrow with Steel Broadhead, Fletching & Speed Streak
        const curX = startX + (targetX - startX) * progress;
        const curY = startY + (targetY - startY) * progress;
        const angle = Math.atan2(targetY - startY, targetX - startX);
        const arrowLen = 22 * dpr;

        ctx.save();
        ctx.translate(curX, curY);
        ctx.rotate(angle);

        // Motion Speed Trail
        ctx.strokeStyle = 'rgba(248, 250, 252, 0.4)';
        ctx.lineWidth = 1.5 * dpr;
        ctx.beginPath();
        ctx.moveTo(-arrowLen * 1.5, 0);
        ctx.lineTo(-arrowLen * 0.5, 0);
        ctx.stroke();

        // Wooden Arrow Shaft
        ctx.strokeStyle = '#78350f';
        ctx.lineWidth = 2 * dpr;
        ctx.beginPath();
        ctx.moveTo(-arrowLen, 0);
        ctx.lineTo(0, 0);
        ctx.stroke();

        // Steel Broadhead (Triangle Tip)
        ctx.fillStyle = '#f8fafc';
        ctx.beginPath();
        ctx.moveTo(5 * dpr, 0);
        ctx.lineTo(-2 * dpr, -3.5 * dpr);
        ctx.lineTo(-2 * dpr, 3.5 * dpr);
        ctx.closePath();
        ctx.fill();

        // Crimson/White Feather Fletchings
        ctx.strokeStyle = '#ef4444';
        ctx.lineWidth = 1.8 * dpr;
        ctx.beginPath();
        ctx.moveTo(-arrowLen + 4 * dpr, -3 * dpr);
        ctx.lineTo(-arrowLen, 0);
        ctx.lineTo(-arrowLen + 4 * dpr, 3 * dpr);
        ctx.stroke();

        ctx.restore();
      } else if (fx.type === 'fire') {
        // Billowing Fireball Comet with Swirling Embers
        const curX = startX + (targetX - startX) * progress;
        const curY = startY + (targetY - startY) * progress;
        const angle = Math.atan2(targetY - startY, targetX - startX);

        ctx.save();
        ctx.translate(curX, curY);
        ctx.rotate(angle);

        // Trailing Flame Tongue
        const flameGrad = ctx.createRadialGradient(0, 0, 1 * dpr, 0, 0, 12 * dpr);
        flameGrad.addColorStop(0, '#ffffff');
        flameGrad.addColorStop(0.3, '#fef08a');
        flameGrad.addColorStop(0.7, '#f97316');
        flameGrad.addColorStop(1, 'rgba(220, 38, 38, 0)');

        ctx.fillStyle = flameGrad;
        ctx.beginPath();
        ctx.moveTo(8 * dpr, 0);
        ctx.quadraticCurveTo(-4 * dpr, -8 * dpr, -16 * dpr, 0);
        ctx.quadraticCurveTo(-4 * dpr, 8 * dpr, 8 * dpr, 0);
        ctx.fill();

        // Swirling embers trailing behind
        ctx.fillStyle = '#fed7aa';
        for (let e = 1; e <= 3; e++) {
          const embX = -14 * dpr - e * 5 * dpr;
          const embY = Math.sin(progress * 15 + e) * 4 * dpr;
          ctx.beginPath();
          ctx.arc(embX, embY, (2.5 - e * 0.5) * dpr, 0, Math.PI * 2);
          ctx.fill();
        }
        ctx.restore();

        // Impact Fiery Nova on arrival
        if (progress > 0.6) {
          const fireProg = (progress - 0.6) / 0.4;
          ctx.strokeStyle = '#f97316';
          ctx.lineWidth = (3 - fireProg * 2) * dpr;
          ctx.beginPath();
          ctx.arc(targetX, targetY, fireProg * cellW * 0.5, 0, Math.PI * 2);
          ctx.stroke();
        }
      } else {
        // Projectile / Arcane Magic Beam
        const curX = startX + (targetX - startX) * progress;
        const curY = startY + (targetY - startY) * progress;
        ctx.strokeStyle = fx.color;
        ctx.lineWidth = 3 * dpr;
        ctx.beginPath();
        ctx.moveTo(startX, startY);
        ctx.lineTo(curX, curY);
        ctx.stroke();

        // Pulsing Arcane Halo
        ctx.strokeStyle = fx.color;
        ctx.lineWidth = 1.5 * dpr;
        ctx.beginPath();
        ctx.arc(curX, curY, (6 + Math.sin(progress * 10) * 2) * dpr, 0, Math.PI * 2);
        ctx.stroke();

        if (progress > 0.5) {
          const ringProg = (progress - 0.5) / 0.5;
          ctx.strokeStyle = fx.color;
          ctx.lineWidth = 2 * dpr;
          ctx.beginPath();
          ctx.arc(targetX, targetY, ringProg * cellW * 0.45, 0, Math.PI * 2);
          ctx.stroke();
        }
      }

      if (fx.floatingText) {
          const floatY = targetY - cellH * (0.35 + progress * 0.35);
          ctx.fillStyle = '#0f172a';
          ctx.fillRect(targetX - 45 * dpr, floatY - 9 * dpr, 90 * dpr, 18 * dpr);
          ctx.strokeStyle = fx.color;
          ctx.lineWidth = 1 * dpr;
          ctx.strokeRect(targetX - 45 * dpr, floatY - 9 * dpr, 90 * dpr, 18 * dpr);
          ctx.fillStyle = fx.color;
          ctx.font = `bold ${Math.max(10, Math.floor(cellH * 0.16))}px 'DM Mono', monospace`;
          ctx.textAlign = 'center';
          ctx.fillText(fx.floatingText, targetX, floatY + 4 * dpr);
        }

        if (fx.damage !== 0) {
          const floatY = targetY - cellH * (0.15 + progress * 0.28);
          ctx.fillStyle = fx.damage < 0 ? '#4ade80' : fx.isCrit ? '#fbbf24' : '#ffffff';
          ctx.font = `bold ${Math.max(12, Math.floor(cellH * (fx.isCrit ? 0.26 : 0.2)))}px 'DM Mono', monospace`;
          ctx.textAlign = 'center';
          const text = fx.damage < 0 ? `+${Math.abs(fx.damage)}` : `-${fx.damage}`;
          ctx.fillText(text, targetX, floatY);
        }
      ctx.restore();
    }

    // 10. Atmospheric Dungeon Dust Motes & Ambient Vignette
    // Floating air motes / sparks
    const moteCount = 14;
    for (let i = 0; i < moteCount; i++) {
      const moteTime = (now / 1800 + i * 0.17) % 1;
      const moteX = ((i * 137.5) % width) + Math.sin(now / 900 + i) * (15 * dpr);
      const moteY = height - moteTime * height;
      const moteAlpha = Math.sin(moteTime * Math.PI) * (biome === 'abyssal_forge' ? 0.35 : 0.22);
      ctx.fillStyle = biome === 'abyssal_forge' ? `rgba(249, 115, 22, ${moteAlpha})` : `rgba(254, 240, 138, ${moteAlpha})`;
      ctx.beginPath();
      ctx.arc(moteX, moteY, (1 + (i % 2) * 0.8) * dpr, 0, Math.PI * 2);
      ctx.fill();
    }

    // Cinematic Dark Vignette around edges
    const vignette = ctx.createRadialGradient(
      width / 2,
      height / 2,
      Math.min(width, height) * 0.45,
      width / 2,
      height / 2,
      Math.max(width, height) * 0.72
    );
    vignette.addColorStop(0, 'rgba(0, 0, 0, 0)');
    vignette.addColorStop(0.7, 'rgba(3, 7, 18, 0.2)');
    vignette.addColorStop(1, 'rgba(2, 6, 23, 0.65)');
    ctx.fillStyle = vignette;
    ctx.fillRect(0, 0, width, height);

    ctx.restore();
  }, [
    units,
    walls,
    terrainMap,
    triggeredTraps,
    bossTelegraph,
    visualEffects,
    activeId,
    selectedId,
    moveTiles,
    targetTiles,
    phase,
    biome,
    equipped,
    getEffectiveStats,
    screenShake,
    elevations,
    barrels,
  ]);

  useEffect(() => {
    let animationId: number;
    const loop = () => {
      draw();
      animationId = requestAnimationFrame(loop);
    };
    animationId = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(animationId);
  }, [draw]);

  const handlePointerDown = (clientX: number, clientY: number) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const clickX = clientX - rect.left;
    const clickY = clientY - rect.top;
    const tileX = Math.floor((clickX / rect.width) * GRID_COLS);
    const tileY = Math.floor((clickY / rect.height) * GRID_ROWS);
    if (tileX >= 0 && tileX < GRID_COLS && tileY >= 0 && tileY < GRID_ROWS) {
      onTileClick(tileX, tileY);
    }
  };

  const handleClick = (e: React.MouseEvent<HTMLCanvasElement>) => {
    handlePointerDown(e.clientX, e.clientY);
  };

  const handleTouchEnd = (e: React.TouchEvent<HTMLCanvasElement>) => {
    if (e.changedTouches.length > 0) {
      const touch = e.changedTouches[0];
      handlePointerDown(touch.clientX, touch.clientY);
    }
  };

  return (
    <div
      ref={containerRef}
      className="relative w-full aspect-[1.78] max-h-[560px] bg-[#070a0f] rounded-xl overflow-hidden shadow-2xl border-2 border-[#334155]/80 select-none ring-1 ring-black/80"
    >
      <canvas
        ref={canvasRef}
        onClick={handleClick}
        onTouchEnd={handleTouchEnd}
        className="w-full h-full block cursor-pointer touch-none"
      />
    </div>
  );
};
