import React from 'react';
import { GearItem, GearTemplate, SlotType, WeaponFamily, ArmorFamily, ShieldFamily } from '../types/game';
import { RARITY_COLORS } from '../game/constants';

interface WeaponIconArtProps {
  item?: GearItem | GearTemplate | null;
  family?: WeaponFamily | ArmorFamily | ShieldFamily | string | null;
  slot?: SlotType;
  name?: string;
  rarity?: number;
  size?: number | 'sm' | 'md' | 'lg' | 'xl';
  className?: string;
  showRarityGlow?: boolean;
}

export const WeaponIconArt: React.FC<WeaponIconArtProps> = ({
  item,
  family: propFamily,
  slot: propSlot,
  name: propName,
  rarity = (item && 'rarity' in item && typeof item.rarity === 'number' ? item.rarity : 1),
  size = 32,
  className = '',
  showRarityGlow = true,
}) => {
  const family = propFamily || item?.family || item?.armorFamily || item?.shieldFamily || 'sword';
  const slot = propSlot || item?.slot || 'weapon';
  const name = (propName || item?.name || '').toLowerCase();

  // Resolve pixel size
  let px = 32;
  if (typeof size === 'number') {
    px = size;
  } else if (size === 'sm') {
    px = 20;
  } else if (size === 'md') {
    px = 28;
  } else if (size === 'lg') {
    px = 38;
  } else if (size === 'xl') {
    px = 48;
  }

  const rarityColor = RARITY_COLORS[Math.min(5, Math.max(0, rarity - 1))] || '#94a3b8';

  // Render SVG based on slot, family, and specific weapon names
  const renderArt = () => {
    // 1. RINGS & ACCESSORIES
    if (slot === 'ring') {
      if (name.includes('medusa')) {
        // Medusa Serpent Ring
        return (
          <svg viewBox="0 0 64 64" className="w-full h-full drop-shadow">
            <defs>
              <linearGradient id="medusaBand" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#10b981" />
                <stop offset="50%" stopColor="#059669" />
                <stop offset="100%" stopColor="#064e3b" />
              </linearGradient>
              <radialGradient id="medusaEye" cx="50%" cy="50%" r="50%">
                <stop offset="0%" stopColor="#a7f3d0" />
                <stop offset="60%" stopColor="#10b981" />
                <stop offset="100%" stopColor="#047857" />
              </radialGradient>
            </defs>
            {/* Outer Snake Coils */}
            <circle cx="32" cy="32" r="22" stroke="url(#medusaBand)" strokeWidth="6" fill="none" />
            <circle cx="32" cy="32" r="14" stroke="#0f172a" strokeWidth="2" fill="#042f2e" />
            {/* Serpent Scales & Head */}
            <path d="M 32 10 Q 40 8 45 15 Q 40 20 32 17 Z" fill="#34d399" />
            <circle cx="38" cy="14" r="1.5" fill="#fef08a" />
            <path d="M 32 54 Q 24 56 19 49 Q 24 44 32 47 Z" fill="#059669" />
            {/* Center Glowing Gem Eye */}
            <polygon points="32,22 40,32 32,42 24,32" fill="url(#medusaEye)" stroke="#ecfdf5" strokeWidth="1" />
            <ellipse cx="32" cy="32" rx="2" ry="5" fill="#022c22" />
          </svg>
        );
      }
      if (name.includes('gai') || name.includes('thorns') || name.includes('huyết')) {
        // Bramble Thorns / Blood Ring
        return (
          <svg viewBox="0 0 64 64" className="w-full h-full drop-shadow">
            <circle cx="32" cy="32" r="22" stroke="#450a0a" strokeWidth="6" fill="none" />
            {/* Spikes branching out */}
            <path d="M 32 10 L 32 4 M 54 32 L 60 32 M 32 54 L 32 60 M 10 32 L 4 32 M 48 16 L 53 11 M 48 48 L 53 53 M 16 48 L 11 53 M 16 16 L 11 11" stroke="#dc2626" strokeWidth="3" strokeLinecap="round" />
            {/* Blood Ruby */}
            <polygon points="32,20 42,32 32,44 22,32" fill="#ef4444" stroke="#fee2e2" strokeWidth="1" />
            <circle cx="32" cy="32" r="3" fill="#ffffff" opacity="0.6" />
          </svg>
        );
      }
      if (name.includes('hư không') || name.includes('void')) {
        // Void Event Horizon Ring
        return (
          <svg viewBox="0 0 64 64" className="w-full h-full drop-shadow">
            <circle cx="32" cy="32" r="23" stroke="#581c87" strokeWidth="5" fill="none" />
            <circle cx="32" cy="32" r="15" fill="#090514" stroke="#a855f7" strokeWidth="2" strokeDasharray="4 2" />
            <circle cx="32" cy="32" r="7" fill="#3b0764" />
            <circle cx="32" cy="32" r="3" fill="#ffffff" />
            <path d="M 22 18 Q 32 12 42 18" stroke="#c084fc" strokeWidth="2" fill="none" />
            <path d="M 22 46 Q 32 52 42 46" stroke="#c084fc" strokeWidth="2" fill="none" />
          </svg>
        );
      }
      // Standard Enchanted Ring
      return (
        <svg viewBox="0 0 64 64" className="w-full h-full drop-shadow">
          <circle cx="32" cy="34" r="20" stroke="#f59e0b" strokeWidth="6" fill="none" />
          <circle cx="32" cy="34" r="15" stroke="#78350f" strokeWidth="1.5" fill="none" />
          {/* Beveled Gem Mount */}
          <path d="M 24 16 L 40 16 L 44 24 L 20 24 Z" fill="#d97706" />
          {/* Faceted Blue/Gold Sapphire Diamond */}
          <polygon points="32,10 42,20 32,28 22,20" fill="#38bdf8" stroke="#e0f2fe" strokeWidth="1" />
          <polygon points="32,10 32,28 22,20" fill="#0284c7" />
          <polygon points="32,10 42,20 32,28" fill="#bae6fd" opacity="0.7" />
        </svg>
      );
    }

    // 2. SHIELDS
    if (slot === 'shield' || family === 'buckler' || family === 'aegis') {
      if (name.includes('kiên cố') || name.includes('aegis') || name.includes('bất hoại') || name.includes('long vảy')) {
        // High-Tier Aegis / Bastion Kite Shield
        return (
          <svg viewBox="0 0 64 64" className="w-full h-full drop-shadow">
            <defs>
              <linearGradient id="shieldPlate" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#475569" />
                <stop offset="50%" stopColor="#1e293b" />
                <stop offset="100%" stopColor="#0f172a" />
              </linearGradient>
            </defs>
            {/* Kite Shield Body */}
            <path d="M 12 12 Q 32 8 52 12 L 50 36 Q 46 54 32 60 Q 18 54 14 36 Z" fill="url(#shieldPlate)" stroke="#f59e0b" strokeWidth="3" />
            <path d="M 18 16 Q 32 13 46 16 L 44 34 Q 41 48 32 53 Q 23 48 20 34 Z" fill="none" stroke="#94a3b8" strokeWidth="1.5" />
            {/* Golden Boss Emblem */}
            <circle cx="32" cy="28" r="8" fill="#f59e0b" stroke="#fef08a" strokeWidth="1.5" />
            <polygon points="32,22 35,28 32,34 29,28" fill="#78350f" />
            {/* Studs */}
            <circle cx="16" cy="16" r="1.5" fill="#fef08a" />
            <circle cx="48" cy="16" r="1.5" fill="#fef08a" />
            <circle cx="32" cy="54" r="1.5" fill="#fef08a" />
          </svg>
        );
      }
      // Round Studded Buckler Shield
      return (
        <svg viewBox="0 0 64 64" className="w-full h-full drop-shadow">
          <circle cx="32" cy="32" r="26" fill="#334155" stroke="#94a3b8" strokeWidth="3" />
          <circle cx="32" cy="32" r="21" fill="#1e293b" stroke="#0f172a" strokeWidth="2" />
          {/* Iron cross reinforcement */}
          <path d="M 12 32 L 52 32 M 32 12 L 32 52" stroke="#64748b" strokeWidth="3" />
          {/* Central heavy spike boss */}
          <circle cx="32" cy="32" r="9" fill="#e2e8f0" stroke="#475569" strokeWidth="2" />
          <polygon points="32,25 37,32 32,39 27,32" fill="#0f172a" />
        </svg>
      );
    }

    // 3. ARMOR
    if (slot === 'armor') {
      if (family === 'robe' || name.includes('pháp') || name.includes('áo choàng')) {
        // Archmage Mystical Robe
        return (
          <svg viewBox="0 0 64 64" className="w-full h-full drop-shadow">
            <path d="M 22 10 L 42 10 L 52 24 L 46 28 L 40 22 L 44 56 L 20 56 L 24 22 L 18 28 L 12 24 Z" fill="#312e81" stroke="#818cf8" strokeWidth="2" />
            <path d="M 28 10 L 32 26 L 36 10" stroke="#facc15" strokeWidth="1.5" fill="none" />
            <circle cx="32" cy="28" r="4" fill="#6366f1" stroke="#e0e7ff" strokeWidth="1" />
            {/* Gold trim hem */}
            <path d="M 20 52 L 44 52" stroke="#facc15" strokeWidth="2.5" />
          </svg>
        );
      }
      // Steel / Dragon Plate Cuirass
      return (
        <svg viewBox="0 0 64 64" className="w-full h-full drop-shadow">
          <path d="M 20 12 L 32 8 L 44 12 L 50 20 L 46 34 L 42 54 L 22 54 L 18 34 L 14 20 Z" fill="#334155" stroke="#cbd5e1" strokeWidth="2.5" />
          <path d="M 32 8 L 32 54" stroke="#0f172a" strokeWidth="2" />
          <path d="M 22 26 Q 32 32 42 26" stroke="#94a3b8" strokeWidth="2" fill="none" />
          <path d="M 22 38 Q 32 44 42 38" stroke="#94a3b8" strokeWidth="2" fill="none" />
          {/* Pauldrons / Gorget */}
          <path d="M 24 12 Q 32 18 40 12" stroke="#f59e0b" strokeWidth="2" fill="none" />
        </svg>
      );
    }

    // 4. WEAPONS
    // (a) Special: Dragon Sword / Katana / Muramasa
    if (name.includes('muramasa') || name.includes('huyết nguyệt kiếm') || (family === 'sword' && name.includes('thần kiếm'))) {
      // Blood Katana Muramasa
      return (
        <svg viewBox="0 0 64 64" className="w-full h-full drop-shadow">
          <defs>
            <linearGradient id="muraBlade" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#fca5a5" />
              <stop offset="40%" stopColor="#dc2626" />
              <stop offset="100%" stopColor="#450a0a" />
            </linearGradient>
          </defs>
          {/* Curved katana blade */}
          <path d="M 48 8 C 42 20 30 36 18 46 L 15 43 C 27 33 39 17 45 6 Z" fill="url(#muraBlade)" stroke="#fee2e2" strokeWidth="1" />
          {/* Sharp Edge Hamon line */}
          <path d="M 45 7 C 39 19 28 35 16 45" stroke="#fecaca" strokeWidth="1.2" strokeLinecap="round" />
          {/* Tsuba Guard */}
          <ellipse cx="17" cy="44" rx="5" ry="3" fill="#f59e0b" stroke="#78350f" strokeWidth="1" transform="rotate(-40 17 44)" />
          {/* Tsuka Handle */}
          <path d="M 16 45 L 8 55 L 11 58 L 19 48 Z" fill="#18181b" stroke="#dc2626" strokeWidth="1" />
          {/* Blood aura sparks */}
          <circle cx="42" cy="14" r="1.5" fill="#ef4444" />
          <circle cx="34" cy="25" r="1.2" fill="#ef4444" />
        </svg>
      );
    }

    if (name.includes('long thần') || name.includes('dragon') || name.includes('long')) {
      // Draconic Greatsword with Flaming Core
      return (
        <svg viewBox="0 0 64 64" className="w-full h-full drop-shadow">
          <defs>
            <linearGradient id="dragonFlame" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#fef08a" />
              <stop offset="50%" stopColor="#f97316" />
              <stop offset="100%" stopColor="#b91c1c" />
            </linearGradient>
          </defs>
          {/* Blade */}
          <polygon points="54,10 40,24 38,20 28,30 26,26 18,34 26,42 34,34 30,32 40,22 36,20 50,6" fill="url(#dragonFlame)" stroke="#fed7aa" strokeWidth="1" />
          <line x1="52" y1="8" x2="22" y2="38" stroke="#ffffff" strokeWidth="1.2" />
          {/* Dragon Claw Crossguard */}
          <path d="M 16 32 Q 22 40 12 46 M 24 24 Q 32 32 38 22" stroke="#ea580c" strokeWidth="3" strokeLinecap="round" />
          {/* Hilt & Pommel */}
          <line x1="20" y1="40" x2="8" y2="52" stroke="#78350f" strokeWidth="4" strokeLinecap="round" />
          <circle cx="7" cy="53" r="3" fill="#ea580c" stroke="#fef08a" strokeWidth="1" />
        </svg>
      );
    }

    // (b) Axes
    if (family === 'axe') {
      return (
        <svg viewBox="0 0 64 64" className="w-full h-full drop-shadow">
          <defs>
            <linearGradient id="axeSteel" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#f1f5f9" />
              <stop offset="50%" stopColor="#94a3b8" />
              <stop offset="100%" stopColor="#334155" />
            </linearGradient>
          </defs>
          {/* Wood Haft */}
          <line x1="12" y1="56" x2="52" y2="16" stroke="#78350f" strokeWidth="5" strokeLinecap="round" />
          <line x1="12" y1="56" x2="52" y2="16" stroke="#451a03" strokeWidth="2" strokeDasharray="3 4" strokeLinecap="round" />
          {/* Crescent Axe Blade */}
          <path d="M 40 14 C 48 4 58 8 58 20 C 58 32 48 38 38 28 L 44 22 Z" fill="url(#axeSteel)" stroke="#e2e8f0" strokeWidth="1.5" />
          {/* Back Spike Hook */}
          <polygon points="34,22 24,18 30,26" fill="#64748b" stroke="#cbd5e1" strokeWidth="1" />
          {/* Binding bands */}
          <rect x="36" y="20" width="6" height="5" fill="#f59e0b" transform="rotate(-45 39 22)" />
        </svg>
      );
    }

    // (c) Hammers & Maces
    if (family === 'hammer') {
      return (
        <svg viewBox="0 0 64 64" className="w-full h-full drop-shadow">
          {/* Shaft */}
          <line x1="14" y1="54" x2="46" y2="22" stroke="#78350f" strokeWidth="5" strokeLinecap="round" />
          <line x1="18" y1="50" x2="26" y2="42" stroke="#d97706" strokeWidth="6" strokeLinecap="round" />
          {/* Heavy Dwarf Hammer Head */}
          <g transform="rotate(-45 44 20)">
            <rect x="32" y="8" width="24" height="24" rx="4" fill="#334155" stroke="#94a3b8" strokeWidth="2.5" />
            <rect x="36" y="12" width="16" height="16" rx="2" fill="#1e293b" />
            {/* Rune carving */}
            <path d="M 44 14 L 44 26 M 38 18 L 50 22" stroke="#38bdf8" strokeWidth="2" strokeLinecap="round" />
            {/* Side impact spikes */}
            <polygon points="28,20 32,15 32,25" fill="#e2e8f0" />
            <polygon points="60,20 56,15 56,25" fill="#e2e8f0" />
          </g>
        </svg>
      );
    }

    // (d) Bows & Crossbows
    if (family === 'bow' || family === 'crossbow') {
      return (
        <svg viewBox="0 0 64 64" className="w-full h-full drop-shadow">
          {/* Recurve Bow Curve */}
          <path d="M 14 16 C 24 10 44 12 54 28 C 42 38 28 48 16 54" fill="none" stroke="#b45309" strokeWidth="3.5" strokeLinecap="round" />
          <path d="M 14 16 C 22 12 40 14 50 28 C 38 38 26 48 16 54" fill="none" stroke="#d97706" strokeWidth="1.5" />
          {/* Taut String */}
          <line x1="14" y1="16" x2="16" y2="54" stroke="#f1f5f9" strokeWidth="1.2" strokeDasharray="1 1" />
          {/* Loaded Arrow */}
          <line x1="12" y1="36" x2="48" y2="36" stroke="#475569" strokeWidth="2" />
          {/* Steel Broadhead */}
          <polygon points="54,36 46,31 46,41" fill="#f8fafc" stroke="#64748b" strokeWidth="1" />
          {/* Feather fletchings */}
          <path d="M 12 36 L 16 32 M 12 36 L 16 40" stroke="#f43f5e" strokeWidth="2.5" strokeLinecap="round" />
        </svg>
      );
    }

    // (e) Staves & Wands
    if (family === 'staff') {
      return (
        <svg viewBox="0 0 64 64" className="w-full h-full drop-shadow">
          <defs>
            <radialGradient id="staffOrb" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="#fef08a" />
              <stop offset="40%" stopColor="#f97316" />
              <stop offset="100%" stopColor="#991b1b" />
            </radialGradient>
          </defs>
          {/* Gnarled Wood Shaft */}
          <line x1="14" y1="56" x2="46" y2="24" stroke="#5c2c16" strokeWidth="4.5" strokeLinecap="round" />
          <line x1="22" y1="48" x2="28" y2="42" stroke="#d97706" strokeWidth="5.5" strokeLinecap="round" />
          {/* Gold Prongs Holding Crystal */}
          <path d="M 42 28 C 44 20 48 18 52 14" stroke="#f59e0b" strokeWidth="2.5" fill="none" strokeLinecap="round" />
          <path d="M 48 24 C 54 22 56 16 54 10" stroke="#f59e0b" strokeWidth="2.5" fill="none" strokeLinecap="round" />
          {/* Glowing Arcane Crystal Orb */}
          <circle cx="50" cy="14" r="8" fill="url(#staffOrb)" stroke="#fed7aa" strokeWidth="1.5" />
          <ellipse cx="48" cy="12" rx="2" ry="4" fill="#ffffff" opacity="0.7" />
          {/* Sparkles */}
          <circle cx="58" cy="10" r="1.5" fill="#fef08a" />
          <circle cx="44" cy="6" r="1.2" fill="#fef08a" />
        </svg>
      );
    }

    // (f) Tomes & Grimoires
    if (family === 'tome') {
      return (
        <svg viewBox="0 0 64 64" className="w-full h-full drop-shadow">
          {/* Leather Book Cover */}
          <rect x="14" y="12" width="36" height="42" rx="3" fill="#311042" stroke="#7e22ce" strokeWidth="2" />
          {/* Book Spine */}
          <rect x="14" y="12" width="7" height="42" rx="1" fill="#1e082b" stroke="#a855f7" strokeWidth="1" />
          {/* Gold Corner Guards */}
          <polygon points="44,12 50,12 50,18" fill="#f59e0b" />
          <polygon points="44,54 50,54 50,48" fill="#f59e0b" />
          {/* Arcane Mystic Eye Sigil */}
          <ellipse cx="34" cy="33" rx="10" ry="6" fill="none" stroke="#c084fc" strokeWidth="1.8" />
          <circle cx="34" cy="33" r="3.5" fill="#38bdf8" stroke="#ffffff" strokeWidth="1" />
          <path d="M 28 33 L 40 33" stroke="#e9d5ff" strokeWidth="1" />
        </svg>
      );
    }

    // (g) Bells of Light & Healing
    if (family === 'bell') {
      return (
        <svg viewBox="0 0 64 64" className="w-full h-full drop-shadow">
          {/* Bell Crown / Handle */}
          <path d="M 28 14 C 28 8 36 8 36 14" fill="none" stroke="#f59e0b" strokeWidth="3" />
          {/* Golden Bell Body */}
          <path d="M 26 18 C 26 26 20 38 16 44 L 48 44 C 44 38 38 26 38 18 Z" fill="#d97706" stroke="#fef08a" strokeWidth="2" />
          <ellipse cx="32" cy="44" rx="16" ry="5" fill="#78350f" stroke="#f59e0b" strokeWidth="2" />
          {/* Clapper / Sound beads */}
          <circle cx="32" cy="49" r="3" fill="#fef08a" />
          {/* Holy Light Rays */}
          <line x1="32" y1="6" x2="32" y2="2" stroke="#38bdf8" strokeWidth="2" strokeLinecap="round" />
          <line x1="20" y1="8" x2="16" y2="4" stroke="#38bdf8" strokeWidth="2" strokeLinecap="round" />
          <line x1="44" y1="8" x2="48" y2="4" stroke="#38bdf8" strokeWidth="2" strokeLinecap="round" />
        </svg>
      );
    }

    // (h) Daggers
    if (family === 'dagger') {
      return (
        <svg viewBox="0 0 64 64" className="w-full h-full drop-shadow">
          {/* Curved Kris/Dagger Blade */}
          <polygon points="50,14 42,20 38,18 28,28 24,34 30,40 36,36 46,26 44,22" fill="#64748b" stroke="#cbd5e1" strokeWidth="1.5" />
          <line x1="48" y1="16" x2="28" y2="36" stroke="#10b981" strokeWidth="1.5" />
          {/* Guard */}
          <path d="M 22 30 L 34 42" stroke="#d97706" strokeWidth="3" strokeLinecap="round" />
          {/* Handle */}
          <line x1="26" y1="38" x2="14" y2="50" stroke="#1e293b" strokeWidth="4" strokeLinecap="round" />
          <circle cx="12" cy="52" r="3" fill="#d97706" />
        </svg>
      );
    }

    // (i) Default: Standard Steel Sword / Broadsword
    return (
      <svg viewBox="0 0 64 64" className="w-full h-full drop-shadow">
        <defs>
          <linearGradient id="swordSteel" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#ffffff" />
            <stop offset="50%" stopColor="#94a3b8" />
            <stop offset="100%" stopColor="#334155" />
          </linearGradient>
        </defs>
        {/* Steel Blade */}
        <polygon points="52,12 48,16 26,38 22,34 44,12" fill="url(#swordSteel)" stroke="#f1f5f9" strokeWidth="1" />
        <polygon points="52,12 26,38 23,37 49,11" fill="#cbd5e1" />
        {/* Center Fuller Ridge */}
        <line x1="50" y1="14" x2="26" y2="38" stroke="#475569" strokeWidth="1" />
        {/* Brass Crossguard */}
        <path d="M 18 30 L 32 44" stroke="#f59e0b" strokeWidth="3.5" strokeLinecap="round" />
        <circle cx="25" cy="37" r="2" fill="#dc2626" />
        {/* Leather Grip */}
        <line x1="23" y1="39" x2="13" y2="49" stroke="#78350f" strokeWidth="3.5" strokeLinecap="round" />
        {/* Pommel */}
        <circle cx="11" cy="51" r="3.5" fill="#f59e0b" stroke="#78350f" strokeWidth="1" />
      </svg>
    );
  };

  return (
    <div
      className={`relative inline-flex items-center justify-center rounded-lg select-none shrink-0 overflow-hidden ${className}`}
      style={{
        width: px,
        height: px,
        minWidth: px,
        minHeight: px,
        backgroundColor: '#070b14',
        border: `1.5px solid ${showRarityGlow ? rarityColor + 'aa' : '#334155'}`,
        boxShadow: showRarityGlow ? `0 0 8px ${rarityColor}33` : 'none',
      }}
      title={`${item?.name || name} (${slot})`}
    >
      <div className="w-[82%] h-[82%] flex items-center justify-center">
        {renderArt()}
      </div>
    </div>
  );
};
